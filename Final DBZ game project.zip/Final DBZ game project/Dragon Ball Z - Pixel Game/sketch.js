/*
> Extension < 

1. Add advanced graphics
Adding graphical detail with the use of simple shapes is a tough initiative with the use of commands such as "rect();", "ellipse();" and "triangle();" though they can be used for simple depth detail. In the case of other detail, commands such as "image();" regarding image formats such as png and jpeg would be used to create higher detailed scenes.
Of course, I didn't want to go with High-resolution images as they would take a longer time to load within the Preload function and be copied and set within the scene using the setup and draw function.
When adding my images these steps were taken:

function Preload()
{
	Image_Name = loadImage(assets/Image.png);
};

function Setup()
{
	*note this can be done in either setup or draw function

	image(Image Name, x, y, width, height);
};

In the conclusion of my choice and development of my game, I've chosen to decrease the image asset file amount by reducing the use of  High-resolution images within the 3 or 4 levels in my game but still being able to show the high use of graphics within my game.

//The bits I found difficult
I found that each image had to be adjusted according to the scene and different levels, they had to be scaled and placed individually, the more unique the Image and its purpose was the more time consuming and harder it was to implement.
Simple shapes were also used in a complex manner to create 3D illusions such as the canyons and menu screens.

//The skills I've learned
I have acquired the ability to implement detail regarding different scenes not only in the form of level-building but UI interactions with the use of graphics aswell as implementing those graphics in a fully satisfactory way.

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

2. Add Sound
The sound was an interesting piece of detail in my game it was also a tough prospect of implementing in different phases of my game. I wanted large or long music files to be able to play. During my development I found this to be difficult, nonetheless, I managed to break past this flaw. My game includes 3 - 4 different music pieces that go well with my game, they switch randomly and repeat themselves continuously so there is no break in immersion (Awkward long silences).
Of course, figuring out their implementation wasn't easy, research had to be done on this matter to understand the bugs I had encountered.
Steps such as this were taken:

function Preload()
{
    Sound_Name = loadSound(assets/Song.mp3); //Load the file
	Sound NamesetVolume(0.5); //Set the Volume
};

function Setup()
{
    *note this can be done in either setup or draw function

*Sounds can only play after an event such as a keyPress, mouseClick or an argument that leads to an event.

   	Sound_Name.play(); //Play sound once
	Sound_Name.loop(); //Repeat sound infinitely
	Sound_Name.stop(); //Stop sound
};

//The bits I found difficult
Implementing sounds within my game was difficult, I had to find a workaround where I could tell the program that I would like to play a sound after a key was pressed. So when I wanted a sound played at a specific time, I needed to code in an argument that a button that has not been physically pressed by the user was pressed. Therefore this was almost an instantaneous action by the game.

//The skills I've learned
I've learned how to successfully play, loop and stop sounds instantaneously with the use of triggers that is not noticeable by the user.

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

3.Create platforms
Creating platforms with the use of factory patterns was a fairly simple process. Being able to create a temporary or permanent space within an array where the game character would have collision detection.

In a trial, I used a simple shape to identify the collision and with further success, I managed to create a system where platforms would be a key factor, when for eg. falling down a canyon, a platform would spawn underneath the game character.
This feature was acting firstly as a temporary feature but soon I was able to make permanent platforms.
This is a similer design:

function createPlatforms(x, y, length)
{
//Variables for the platform
    var p = {
        x: x,
        y: y,
        length: length,
//What will be drawn or shown
        draw: function()
        {
            	image(x,y);
        }
       else
       {
       	image(x,y);
       }
       },
        //Function adjusts the collision
        checkContact: function(gc_x, gc_y)
        {
            if(gc_x > this.x && gc_x < this.x + this.length)
            {
                var d = this.y - gc_y;
                if (d >= 0 && d < 5) 
                {
                    return true;
                }
            }
            return false;
        }
    }
    return p;
}

//Stored in a platform array eg. platforms = [];

//The bits I found difficult
Platforms became a problem when it came to different levels. Platforms had to be saved in different arrays for the sake of different level designs. Another problem was that there was one array that worked on all levels (Temporary spawning platforms). The temporary spawning of platforms was fixed by not clearing the array before another platform was created when the character died. A further problem was that when the game character would jump on the platform they were unable to move as they were not on the ground a further argument had to be made to treat the platform as a "Ground area/movable area".

//The skills I've learned
The skills I've gained from this is the ability to understand and modify platforms in such a way that allows the character to traverse the level with more complexity and even use platforms and collision to the characters advantage or limitation.

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

4. Create Enemies
Enemy creation was an interesting type of collision detection, the function was meant to place enemies in a scene and let them move around the game world within a specific range. When the character would come in contact, the character would reset the game. I found that resetting the game was a harsh consequence as everything would be reset to the default value. So I took another approach. I wanted the game character to be pushed a fair amount of distance away from the enemy without a full reset of values besides the loss of life, as well as make the playable character invulnerable for a small brief moment. Then there was another problem, their speed depending on the game difficulty. I had to make adjustments to the enemies depending on the difficulty and the type of level.
The code is similar to the following:

function Enemy(x, y, range)
{
    this.x = x;
    this.y = y;
    this.range = random(300,900);   
    this.currentX = x;
    this.currentY = y;
    this.inc = 1;
    //Depending on the difficulty the speed of enemies change
    this.update = function()
    {
        this.currentX+= this.inc;
        
        if(this.currentX >= this.x + this.range)
        {
            if (Difficulty[0])
            {
                this.inc = -0.5;
            }
            
            if (Difficulty[1])
            {
                this.inc = -0.8;
            }
            
            if (Difficulty[2])
            {
                this.inc = -1;
            }
        }
        
        else if(this.currentX < this.x)
        {
            if (Difficulty[0])
            {
                this.inc = 0.5;
            }
            
            if (Difficulty[1])
            {
                this.inc = 0.8;
            }
            
            if (Difficulty[2])
            {
                this.inc = 1;
            }
        }
    }
 //The enemy is adjusted with the speed and is drawn
    this.drawEnemy = function()
    {
        this.update();
        fill(255,0,0);
        
        if (enemies[0])
        {
            if (this.inc == -0.5 || this.inc == -0.8|| this.inc == -1)
            {
                image(Enemy[0],this.currentX-25, this.y-100 ,110,120);
            }
            else
            {
                image(Enemy[1],this.currentX-25, this.y-100 ,110,120);
            }
        } 
    }
//This sets the contact that each enemy will have 
    this.checkContact = function(gc_x, gc_y)
    {
        var d = dist(gc_x, gc_y,this.currentX,this.y)
        
        if(d < 20)
        {
            return true;
        }
        return false;
    }
};

//The bits I found difficult
I found to make two identical enemies were possible but the problem came when I wanted a variation of enemies. One different enemy in a location and another different enemy by another location. The challenge also came when a different enemy had to be on a different level. so I had to create independent draw functions for each enemy functioning under the same constructor with the same collision detection value.

//The skills I've learned
I learned how to make independently different enemies using a constructor.
as well as assigning them to different levels and how they interact with the game character.
I've also further learned how to modify different values and variables within the constructor so the enemies move dependant on difficulty and range.

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

- Copy your game project code into this file
- for the p5.Sound library look here https://p5js.org/reference/#/libraries/p5.sound
- for finding cool sounds perhaps look here
https://freesound.org/

*/

/////////////////////////////////Variables//////////////////////////////////

var gameChar_x;         //x coord of game character
var gameChar_y;         //y coord of game character
var floorPos_y;         //x coord of game character
var scrollPos;          //Variable for scrolling
var gameChar_world_x;   //This is the global x coord of the scene

var isLeft;         //left variable of the character
var isRight;        //right variable of the character
var isFalling;      //falling variable of the character
var isPlummeting;   //plummeting variable of the character (use in contact of canyon)

var clouds;         //cloud array variable
var mountains;      //mountain array variable
var trees_x;        //tree array variable
var canyons;        //canyon array variable
var collectablesDB; //Collectable Dragon ball array variable

var game_score = 0;         //This is a variable counter for energy
var Dragon_ball_Counter;    //This is a variable counter for Dragon balls collected
var Zeni_coins_counter = 0; //This is a variable counter for coins collected
var Gem_counter = 0;        //This is a variable counter for gems collected

//These are chests that reward energy and coins
var Red_chest_counter;
var Blue_chest_counter;
var Yellow_chest_counter;

// The Health variable
var lives;

var jumpSound; //jump sound varible *Default code

var GameStart; //Game start variable for when a game starts.

var platforms; //The platform variable array
var Enemies;   //The enemy variable array

// Used to trigger a sound when game over or other
var GO; //Game over variable
var LC; //Level complete variable

var Shenron_sum;    //Actively stores a value
var Candy_rush;     //Buu wanted candy so I gave it to him.
var Time_score;     //Sets and stores timer
var Gregory_char;   //Variable to store the charcater gregory

//Stores the number of tokens for the character
var Beerus_Tokens;  
var Master_Roshi_Tokens;
var Hercule_Tokens;

var DBZ_game_song; //This stores the constantly looped songs during gameplay
var isDead;        //Stores wether the game character is dead

//Some random variables *literally. These help to randomly choose backgrounds and songs
var r1;
var r2;
var r3;

//Wish variables
var Shenron;
var Wishes;         // When a player collects all the dragon balls this is set to true
var jump_Wish;      //Jump wish variable activates if set to true
var lives_Wish;     //Infinite health wish variable activates if set to true
var money_Wish;     //Infinite zeni wish variable activates if set to true
var loading = false; //Loading variable* mainly for show, when a game resets this is set to true.

//Levels Completed variables
///Level completion code
var Namek_Complete = false;
var Earth_Complete = false;
var King_Kai_World_Complete = false;

//Pause menu
var Pause_Menu;

//Carry over variables
var CarryZeni = 0;      // Coin is carryed over
var CarryEnergy = 0;    // Energy is carryed over
var CarryGems = 0;      // Gems is carryed over

////////////////////////////Pre-load function///////////////////////////////
function preload()
{
    soundFormats('mp3','wav'); //Sets the sound formats used.
    
    //load your sounds here
    
    //Dragon Ball Z Looped Music
    DBZ_game_Menu_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - CHA-LA HEAD-CHA-LA (Orchestral) ( 256kbps cbr ).mp3');
    
    DBZ_game_Namek_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - Prologue I ( 256kbps cbr ).mp3');
    
    DBZ_game_Earth_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - CHA-LA HEAD-CHA-LA (Variation) ( 256kbps cbr ).mp3');
    
    DBZ_game_Kai_song =  loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - Prologue II ( 256kbps cbr ).mp3');
    
    DBZ_game_Extra_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - NEW HERO TOUJOU ( 256kbps cbr ).mp3');
    
    // Dragon Ball Z Level complete sound
    Level_Complete_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - Subtitle I ( 256kbps cbr ).mp3');
    
    // Dragon Ball Z Level complete sound
    Game_Over_song = loadSound('Sound_assets/Dragon Ball Z_ Kakarot OST - Subtitle II ( 256kbps cbr ).mp3');
    
    // Other Sounds
    jumpSound = loadSound('Sound_assets/jump.wav');                 //Load Jump sound
    collectCoinSound = loadSound('Sound_assets/collect4.wav');      //Load Coin sound
    collectDBSound = loadSound('Sound_assets/collect5.wav');        //Load Drgaon Ball sound
    collectGemSound = loadSound('Sound_assets/telephone.wav');      //Load Gem sound
    collectHeartSound = loadSound('Sound_assets/plop.wav');         //Load Heart sound
    collectCandySound = loadSound('Sound_assets/collect1.wav');     //Load Candy sound
    collectTokenSound = loadSound('Sound_assets/computeron.wav');   //Load Token sound
    collectChestSound = loadSound('Sound_assets/Powerup.wav');      //Load Chest sound
    clickSound = loadSound('Sound_assets/hop.wav'); 
    enemyHitsound = loadSound('Sound_assets/hit1.wav'); 
    
    
    // Sets the volume for each sound file
    jumpSound.setVolume(0.1);
    collectCoinSound.setVolume(0.1);
    collectDBSound.setVolume(0.1);
    collectGemSound.setVolume(0.1);
    collectCandySound.setVolume(0.1);
    DBZ_game_Menu_song.setVolume(0.4);
    DBZ_game_Namek_song.setVolume(0.4);
    DBZ_game_Earth_song.setVolume(0.4);
    DBZ_game_Kai_song.setVolume(0.4);
    DBZ_game_Extra_song.setVolume(0.4);
    Level_Complete_song.setVolume(0.3);
    Game_Over_song.setVolume(0.3);
    collectTokenSound.setVolume(0.1);
    collectChestSound.setVolume(0.1);
    clickSound.setVolume(0.5);
    enemyHitsound.setVolume(0.1);
    
    ////
    //Gifs *I was experimenting with gifs but I decided not to had them
    ////
    
    ////
    //Animations
    //Fusion Dance animation
    Fusion = [F1 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 1.png'),
             F2 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 2.png'),
             F3 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 3.png'),
             F4 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 4.png'),
             F5 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 5.png'),
             F6 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 6.png'),
             F7 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 7.png'),
             F8 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 8.png'),
             F9 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 9.png'),
             F10 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 10.png'),
             F11 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 11.png'),
             F12 = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Fusion 12.png')];
    
    ////Mouse Cursor
    Mouse_cursor = loadImage("Image_assets/Background/Cursor.png");
    
    //Pause menu
    //Element with the Pause menu
    Side_Border_01 = loadImage("Image_assets/Background/Left Border.png");
    Side_Border_02 = loadImage("Image_assets/Background/Right Border.png");
    Goku_Menu_01 = loadImage("Image_assets/Background/Goku Menu 01.png");
    Goku_Menu_02 = loadImage("Image_assets/Background/Goku Menu 02.png");
    Goku_Menu_03 = loadImage("Image_assets/Background/Goku Menu 03.png");
    Characters_Menu_img = loadImage("Image_assets/Background/DBZ characters.jpg");
    Items_Menu_img = loadImage("Image_assets/Background/DBZ items.jpg");
    Controls_Menu_img = loadImage("Image_assets/Background/DBZ control.png");
    Extras_Menu_img = loadImage("Image_assets/Background/DBZ Extra.png");
    Extras_Menu_01_img = loadImage("Image_assets/Background/DBZ Extra 01.png");
    Char_Border = loadImage("Image_assets/Background/DBZ character border.png");
    Goku_Nimbus = loadImage("Image_assets/Background/Goku on Nimbus.png");
    Char_flames = loadImage("Image_assets/Background/Flames.png");
    Pause_Menu_DB = loadImage("Image_assets/Background/DBZ Menu DB.png");
    
    DBZ_menu_img = [loadImage("Image_assets/Background/DBZ Super.png"),
                    loadImage("Image_assets/Background/DBZ 1.jpg"),
                    loadImage("Image_assets/Background/Dragon Ball Z kai.jpg"),
                    loadImage("Image_assets/Background/DBZ 2.jpg"),
                    loadImage("Image_assets/Background/DBZ 3.jpg")];
    
    DBZ_logo = loadImage('Image_assets/Background/Dragon Ball z logo.png');
    
    Shenron_button_img = loadImage('Image_assets/Background/Shenron Button.png');
    
    Shenron_img = loadImage('Image_assets/Extra Characters/Shenron/Shenron.png');
    
    Shenron_Dragon_Stand = loadImage('Image_assets/Background/Shenron Dragon Stand v1.png');
    
    Shenron_wishes = loadImage('Image_assets/Background/Shenron Wishes.png');
    
    //
    Level_Complete = loadImage('Image_assets/Background/Level Complete.png');
    Game_Over = loadImage('Image_assets/Background/Game Over.jpg');
    
    
    //Background images
    Background = [
        loadImage('Image_assets/Background/tilesetOpenGameBackground.png'),
        loadImage('Image_assets/Background/namekSky.png'),
        loadImage('Image_assets/Background/Elder Kai sky.png')];
    
    Ground = [Earth_Ground = loadImage('Image_assets/Background/Green Grass Ground.png'),
              Namek_Ground = loadImage('Image_assets/Background/Blue Grass Ground.png'),
              King_Kai_Ground = loadImage('Image_assets/Background/Light Green Grass Ground.png')];
    
    Planet_Namek_Background = loadImage('Image_assets/Background/Planet Namek Background.png');
    Planet_Earth_Background = loadImage('Image_assets/Background/Planet Earth Background.png');
    Planet_King_Kai_Background = loadImage('Image_assets/Background/Planet King Kai Background.png');
    
    Menu_Selection_Namek = loadImage('Image_assets/Background/Cutscene Backgrounds Namek.png');
    Menu_Selection_Earth = loadImage('Image_assets/Background/Cutscene Backgrounds Earth.png');
    Menu_Selection_King_Kai_World = loadImage('Image_assets/Background/Cutscene Backgrounds King Kai World.png');
    
    //Trees
    Earth_Tree = loadImage('Image_assets/Background/Earth tree.png');
    King_Kai_Tree = loadImage('Image_assets/Background/King Kai tree.png');
    
    //Mountains
    Mountains = [
        Mountain_1 = loadImage('Image_assets/Background/Desert rock large.png'),
        Mountain_2 = loadImage('Image_assets/Background/Desert rock medium.png'),
        Mountain_3 = loadImage('Image_assets/Background/Desert rock small.png'),
        Mountain_4 = loadImage('Image_assets/Background/Natural rock large.png'),
        Mountain_5 = loadImage('Image_assets/Background/Natural rock medium.png'),
        Mountain_6 = loadImage('Image_assets/Background/Natural rock small.png')];
    
    //Other Rocks
    Rocks = [
        Rock_1 = loadImage('Image_assets/Background/Rock 1.png'),
        Rock_2 = loadImage('Image_assets/Background/Rock 2.png'),
        Rock_3 = loadImage('Image_assets/Background/Rock 3.png'),
        Rock_4 = loadImage('Image_assets/Background/Rock 4.png'),
        Rock_5 = loadImage('Image_assets/Background/Rock 5.png'),
        Rock_6 = loadImage('Image_assets/Background/Rock 6.png'),
        Rock_7 = loadImage('Image_assets/Background/Rock 7.png'),
        Rock_8 = loadImage('Image_assets/Background/Rock 8.png')];
    
    
    //Clouds
    Clouds = [
        Cloud_small_img = 
        loadImage('Image_assets/Background/Small Cloud.png'),
        
        Cloud_small_bulky_img = 
        loadImage('Image_assets/Background/Small Bulky Cloud.png'),
        
        Cloud_medium_img = 
        loadImage('Image_assets/Background/Medium Cloud.png'),
        
        Cloud_large_img = 
        loadImage('Image_assets/Background/Large Cloud.png'),
        
        Cloud_large_bulky_img = 
        loadImage('Image_assets/Background/Large Bulky Cloud.png'),
        
        Cloud_large_bulky_yellow_img = 
        loadImage('Image_assets/Background/Large Bulky Cloud Yellow.png'),
        
        Cloud_medium_yellow_img = 
        loadImage('Image_assets/Background/Medium Cloud Yellow.png')];
    
    //CC ship
    capsule_corp_ship = loadImage('Image_assets/Background/capsule corp ship.png');
    
    //Goku's House
    Gokus_house = loadImage("Image_assets/Background/Goku's House.png");
    
    //Frieza Ship
    Frieza_ship = loadImage('Image_assets/Background/Frieza Ship 1.png');
    
    //Collectables
    //Dragon balls
    Dragon_balls_img = [loadImage('Image_assets/Background/1 star db.png'),
                        loadImage('Image_assets/Background/2 star db.png'),
                        loadImage('Image_assets/Background/3 star db.png'),
                        loadImage('Image_assets/Background/4 star db.png'),
                        loadImage('Image_assets/Background/5 star db.png'),
                        loadImage('Image_assets/Background/6 star db.png'),
                        loadImage('Image_assets/Background/7 star db.png')];
    
    DBZ_symbol_img =loadImage
    ('Image_assets/Background/Dragon_Ball_Z_logo.png');
    
    DBZ_symbol_pixel_img =loadImage
    ('Image_assets/Background/Z logo.png');
    
    //Zeni Coins
    Zeni_coins_img = [loadImage('Image_assets/Background/Coin.png')];
    
    //Gems
    Gem_img = [loadImage('Image_assets/Background/Gem.png')];
    
    //Candy
    Candy_img = [loadImage('Image_assets/Background/Triangle Candy.png'),
                loadImage('Image_assets/Background/Hexagon Candy.png'),
                loadImage('Image_assets/Background/Octagon Candy.png'),
                loadImage('Image_assets/Background/Diamond Candy.png'),
                loadImage('Image_assets/Background/Droplet Candy.png'),
                loadImage('Image_assets/Background/Round Candy.png')];
    
    //Hearts
    Hearts_img = [loadImage('Image_assets/Background/Heart Pixel.png')];

    /////////////////////////////Characters images//////////////////////////////
    
    // Goku Character
    Goku_img = loadImage('Image_assets/Playable Characters/Goku/Goku sprite large.png');
    
    Goku_rad_img = loadImage('Image_assets/Playable Characters/Goku/Goku sprite large round.png');
    
    Goku_token = loadImage('Image_assets/Playable Characters/Goku/Goku sprite.png');
    
    Goku_Portrait = loadImage('Image_assets/Playable Characters/Goku/Goku Portrait.png');
                         
    Goku = [Goku_Standing = loadImage('Image_assets/Playable Characters/Goku/Goku Standing left.png'), 
            Goku_Standing = loadImage('Image_assets/Playable Characters/Goku/Goku Standing right.png'),
            Goku_flying = loadImage('Image_assets/Playable Characters/Goku/Goku flying left.png'),
            Goku_flying = loadImage('Image_assets/Playable Characters/Goku/Goku flying right.png'), 
            Goku_falling = loadImage('Image_assets/Playable Characters/Goku/Goku falling left.png'), 
            Goku_falling = loadImage('Image_assets/Playable Characters/Goku/Goku falling right.png')];
    
    // Krillin Character
    Krillin_img = loadImage('Image_assets/Playable Characters/Krillin/Krillin sprite large.png');
    
    Krillin_rad_img = loadImage('Image_assets/Playable Characters/Krillin/Krillin sprite large round.png');
    
    Krillin_token = loadImage('Image_assets/Playable Characters/Krillin/Krillin sprite.png');
    
    Krillin_Portrait = loadImage('Image_assets/Playable Characters/Krillin/Krillin Portrait.png');
                         
    Krillin = [
        Krillin_Standing = loadImage('Image_assets/Playable Characters/Krillin/Krillin Standing left.png'), 
        Krillin_Standing = loadImage('Image_assets/Playable Characters/Krillin/Krillin Standing right.png'),
        Krillin_flying = loadImage('Image_assets/Playable Characters/Krillin/Krillin flying left.png'),
        Krillin_flying = loadImage('Image_assets/Playable Characters/Krillin/Krillin flying right.png'), 
        Krillin_falling = loadImage('Image_assets/Playable Characters/Krillin/Krillin falling left.png'), 
        Krillin_falling = loadImage('Image_assets/Playable Characters/Krillin/Krillin falling right.png')];
    
    // Majin Buu Character
    Majin_Buu_img = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu sprite large.png');
    
    Majin_Buu_rad_img = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu sprite large round.png');
    
    Majin_Buu_token = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu sprite.png');
    
    Majin_Buu_Portrait = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu Portrait.png');
                         
    Majin_Buu = [
        Majin_Buu_Standing = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu Standing left.png'), 
        Majin_Buu_Standing = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu Standing right.png'),
        Majin_Buu_flying = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu flying left.png'),
        Majin_Buu_flying = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu flying right.png'), 
        Majin_Buu_falling = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu falling left.png'), 
        Majin_Buu_falling = loadImage('Image_assets/Playable Characters/Majin Buu/Majin Buu falling right.png')];
    
    // Vegeta Character
    Vegeta_img = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta sprite large.png');
    
    Vegeta_rad_img = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta sprite large round.png');
    
    Vegeta_token = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta sprite.png');
    
    Vegeta_Portrait = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta Portrait.png');
                         
    Vegeta = [
        Vegeta_Standing = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta Standing left.png'), 
        Vegeta_Standing = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta Standing right.png'),
        Vegeta_flying = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta flying left.png'),
        Vegeta_flying = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta flying right.png'), 
        Vegeta_falling = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta falling left.png'), 
        Vegeta_falling = loadImage('Image_assets/Playable Characters/Vegeta/Vegeta falling right.png')];
    
    // Android 18 Character
    Android_18_img = loadImage('Image_assets/Playable Characters/Android 18/Android 18 sprite large.png');
    
    Android_18_rad_img = loadImage('Image_assets/Playable Characters/Android 18/Android 18 sprite large round.png');
    
    Android_18_token = loadImage('Image_assets/Playable Characters/Android 18/Android 18 sprite.png');
    
    Android_18_Portrait = loadImage('Image_assets/Playable Characters/Android 18/Android 18 Portrait.png');
                         
    Android_18 = [
        Android_18_Standing = loadImage('Image_assets/Playable Characters/Android 18/Android 18 Standing left.png'), 
        Android_18_Standing = loadImage('Image_assets/Playable Characters/Android 18/Android 18 Standing right.png'),
        Android_18_flying = loadImage('Image_assets/Playable Characters/Android 18/Android 18 flying left.png'),
        Android_18_flying = loadImage('Image_assets/Playable Characters/Android 18/Android 18 flying right.png'), 
        Android_18_falling = loadImage('Image_assets/Playable Characters/Android 18/Android 18 falling left.png'), 
        Android_18_falling = loadImage('Image_assets/Playable Characters/Android 18/Android 18 falling right.png')];
    
    // Piccolo Character
    Piccolo_img = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo sprite large.png');
    
    Piccolo_rad_img = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo sprite large round.png');
    
    Piccolo_token = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo sprite.png');
    
    Piccolo_Portrait = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo Portrait.png');
                         
    Piccolo = [
        Piccolo_Standing = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo Standing left.png'), 
        Piccolo_Standing = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo Standing right.png'),
        Piccolo_flying = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo flying left.png'),
        Piccolo_flying = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo flying right.png'), 
        Piccolo_falling = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo falling left.png'), 
        Piccolo_falling = loadImage('Image_assets/Playable Characters/Piccolo/Piccolo falling right.png')];
    
    // Gohan Character
    Gohan_img = loadImage('Image_assets/Playable Characters/Gohan/Gohan sprite large.png');
    
    Gohan_rad_img = loadImage('Image_assets/Playable Characters/Gohan/Gohan sprite large round.png');
    
    Gohan_token = loadImage('Image_assets/Playable Characters/Gohan/Gohan sprite.png');
    
    Gohan_Portrait = loadImage('Image_assets/Playable Characters/Gohan/Gohan Portrait.png');
                         
    Gohan = [
        Gohan_Standing = loadImage('Image_assets/Playable Characters/Gohan/Gohan Standing left.png'), 
        Gohan_Standing = loadImage('Image_assets/Playable Characters/Gohan/Gohan Standing right.png'),
        Gohan_flying = loadImage('Image_assets/Playable Characters/Gohan/Gohan flying left.png'),
        Gohan_flying = loadImage('Image_assets/Playable Characters/Gohan/Gohan flying right.png'), 
        Gohan_falling = loadImage('Image_assets/Playable Characters/Gohan/Gohan falling left.png'), 
        Gohan_falling = loadImage('Image_assets/Playable Characters/Gohan/Gohan falling right.png')];
    
    // Gotenks Character
    Gotenks_img = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks sprite large.png');
    
    Gotenks_rad_img = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks sprite large round.png');
    
    Gotenks_token = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks sprite.png');
    
    Gotenks_Portrait = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Portrait.png');
                         
    Gotenks = [
        Gotenks_Standing = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Standing left.png'), 
        Gotenks_Standing = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks Standing right.png'),
        Gotenks_flying = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks flying left.png'),
        Gotenks_flying = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks flying right.png'), 
        Gotenks_falling = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks falling left.png'), 
        Gotenks_falling = loadImage('Image_assets/Playable Characters/Gotenks/Gotenks falling right.png')];
    
    // Beerus Character
    Beerus_img = loadImage('Image_assets/Playable Characters/Beerus/Beerus sprite large.png');
    
    Beerus_rad_img = loadImage('Image_assets/Playable Characters/Beerus/Beerus sprite large round.png');
    
    Beerus_token = loadImage('Image_assets/Playable Characters/Beerus/Beerus sprite.png');
    
    Beerus_Portrait = loadImage('Image_assets/Playable Characters/Beerus/Beerus Portrait.png');
                         
    Beerus = [
        Beerus_Standing = loadImage('Image_assets/Playable Characters/Beerus/Beerus Standing left.png'), 
        Beerus_Standing = loadImage('Image_assets/Playable Characters/Beerus/Beerus Standing right.png'),
        Beerus_flying = loadImage('Image_assets/Playable Characters/Beerus/Beerus flying left.png'),
        Beerus_flying = loadImage('Image_assets/Playable Characters/Beerus/Beerus flying right.png'), 
        Beerus_falling = loadImage('Image_assets/Playable Characters/Beerus/Beerus falling left.png'), 
        Beerus_falling = loadImage('Image_assets/Playable Characters/Beerus/Beerus falling right.png')];
    
    // Master Roshi Character
    Master_Roshi_img = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi sprite large.png');
    
    Master_Roshi_rad_img = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi sprite large round.png');
    
    Master_Roshi_token = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi sprite.png');
    
    Master_Roshi_Portrait = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi Portrait.png');
                         
    Master_Roshi = [
        Master_Roshi_Standing = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi Standing left.png'), 
        Master_Roshi_Standing = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi Standing right.png'),
        Master_Roshi_flying = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi flying left.png'),
        Master_Roshi_flying = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi flying right.png'), 
        Master_Roshi_falling = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi falling left.png'), 
        Master_Roshi_falling = loadImage('Image_assets/Playable Characters/Master Roshi/Master Roshi falling right.png')];
    
    // Hercule Character
    Hercule_img = loadImage('Image_assets/Playable Characters/Hercule/Hercule sprite large.png');
    
    Hercule_rad_img = loadImage('Image_assets/Playable Characters/Hercule/Hercule sprite large round.png');
    
    Hercule_token = loadImage('Image_assets/Playable Characters/Hercule/Hercule sprite.png');
    
    Hercule_Portrait = loadImage('Image_assets/Playable Characters/Hercule/Hercule Portrait.png');
                         
    Hercule = [
        Hercule_Standing = loadImage('Image_assets/Playable Characters/Hercule/Hercule Standing left.png'), 
        Hercule_Standing = loadImage('Image_assets/Playable Characters/Hercule/Hercule Standing right.png'),
        Hercule_flying = loadImage('Image_assets/Playable Characters/Hercule/Hercule flying left.png'),
        Hercule_flying = loadImage('Image_assets/Playable Characters/Hercule/Hercule flying right.png'), 
        Hercule_falling = loadImage('Image_assets/Playable Characters/Hercule/Hercule falling left.png'), 
        Hercule_falling = loadImage('Image_assets/Playable Characters/Hercule/Hercule falling right.png')];
   
    //////////////Extra Characters
    //Kame Chicken
    KameChicken = [
        KameChicken_left = loadImage('Image_assets/Background/kame Chicken left.png'),
        KameChicken_right = loadImage('Image_assets/Background/kame Chicken right.png')];
    
    DR_B_img = loadImage('Image_assets/Background/Dr B.png');
    Dende_img = loadImage('Image_assets/Background/Dende.png');
    Yamcha_img = loadImage('Image_assets/Extra Characters/Yamcha.png');
    Tien_img = loadImage('Image_assets/Extra Characters/Tien.png');
    Chiatzu_img= loadImage('Image_assets/Extra Characters/Chiatzu.png');
    Android16_img = loadImage('Image_assets/Extra Characters/Android 16.png');
    Android17_img = loadImage('Image_assets/Extra Characters/Android 17.png');
    

    //Enemy characters
    
    //Dodoria
    Dodoria = [
    Dodoria_left = loadImage('Image_assets/Enemy Characters/Dodoria/Dodoria left.png'),
    Dodoria_right = loadImage('Image_assets/Enemy Characters/Dodoria/Dodoria right.png')];
    
    //Zarbon
    Zarbon = [
    Zarbon_left = loadImage('Image_assets/Enemy Characters/Zarbon/Zarbon left.png'),
    Zarbon_right = loadImage('Image_assets/Enemy Characters/Zarbon/Zarbon right.png')];
    
    //Frieza
    Frieza = [
    Frieza_left = loadImage('Image_assets/Enemy Characters/Frieza/Frieza left.png'),
    Frieza_right = loadImage('Image_assets/Enemy Characters/Frieza/Frieza right.png')];
    
    //Ginyu
    Ginyu = [
    Ginyu_left = loadImage('Image_assets/Enemy Characters/Ginyu/Ginyu left.png'),
    Ginyu_right = loadImage('Image_assets/Enemy Characters/Ginyu/Ginyu right.png')];
    
    //Gregory
    Gregory = loadImage('Image_assets/Extra Characters/Gregory/Gregory.png');
    
    //Cell Perfect
    Cell = [
    Cell_left = loadImage('Image_assets/Enemy Characters/Cell (Perfect)/Cell (Perfect) left.png'),
    Cell_right = loadImage('Image_assets/Enemy Characters/Cell (Perfect)/Cell (Perfect) right.png')];
    
    //SuperBuu
    Super_Buu = [
    Super_Buu_left = loadImage('Image_assets/Enemy Characters/Super Buu/Super Buu left.png'),
    Super_Buu_right = loadImage('Image_assets/Enemy Characters/Super Buu/Super Buu right.png')];
    
    ///////Dragon radar
    
    //Dragon Radar
    Radar = [loadImage('Image_assets/Background/Dragon Radar.png')];
    
    //other characters
    DR_Brief_img = loadImage('Image_assets/Background/Dr.Brief.png');  
    Bulma_Radar_img = loadImage('Image_assets/Background/Bulma Radar Profile.png');
    Krillin_Radar_img = loadImage('Image_assets/Background/Krillin Radar Profile.png');
    Goku_Radar_img = loadImage('Image_assets/Background/Goku Radar Profile.png');
    Vegeta_Radar_img = loadImage('Image_assets/Background/Vegeta Radar Profile.png');
    Majin_Buu_Radar_img = loadImage('Image_assets/Background/Majin Buu Radar Profile.png');
    Dende_Radar_img = loadImage('Image_assets/Background/Dende Radar Profile.png');
    King_Kai_Radar_img = loadImage('Image_assets/Background/King Kai Radar Profile.png');
    Tomb_Stone_img = loadImage('Image_assets/Background/TombStone.png');  
    
    //Planets
    Planet_namek= loadImage('Image_assets/Background/DBZ Planet Namek.png');
    Planet_earth= loadImage('Image_assets/Background/DBZ Planet Earth.png');
    Planet_king_kai= loadImage('Image_assets/Background/DBZ King Kai world.png');
    
    //arrow keys
    Right_arrow_Key = loadImage('Image_assets/Background/Right arrow key.png');
    Left_arrow_Key = loadImage('Image_assets/Background/Left arrow key.png');
    Space_Key = loadImage('Image_assets/Background/Space key.png');
    Left_click = loadImage('Image_assets/Background/Left click.png');
    Pause_Key = loadImage('Image_assets/Background/DBZ Pause Menu.png');
    Keyboard = loadImage('Image_assets/Background/DBZ keyboard.png');
    
    //Tips Screen
    Speech_bubble01 = loadImage('Image_assets/Background/Speech bubble.png');
    Dialogue_box_right = loadImage('Image_assets/Background/Dialogue box.png');
    Dialogue_box_left = loadImage('Image_assets/Background/Dialogue box - Copy.png');
    
    //Chests
    Red_chest = loadImage('Image_assets/Background/ChestRed.png');
    Blue_chest = loadImage('Image_assets/Background/ChestBlue.png');
    Yellow_chest = loadImage('Image_assets/Background/ChestYellow.png');
    
    Credit_Background = [CB_1 = loadImage('Image_assets/Background/Ending Art 1.png'),
                         CB_2 = loadImage('Image_assets/Background/Ending Art 2.png'),
                         CB_3 = loadImage('Image_assets/Background/Ending Art 3.png'),
                         CB_4 = loadImage('Image_assets/Background/Ending Art 4.png'),
                         CB_5 = loadImage('Image_assets/Background/Ending Art 5.png')];
}

///////////////////////////////Setup function///////////////////////////////

function setup()
{   
//Nothing is affected here after Level complete
    
    createCanvas(1024,576);
    
    floorPos_y = (height * 3) / 4;
  
    // Start game function
    startGame();
   
    // Lives for Character
    lives = 5; // I added extra lives.
}

///////////////////////////////Draw function///////////////////////////////

function draw() 
{   
    drawFont();
    
    if (GameStart)
    {   
        frameRate(60);
        CarryOverData();
        
        backGround();
        
        BackgroundScenery();
        
        ///////////////////////////////////
        push();
        translate(scrollPos, 0);
        ///////////////////////////////////
        // Draw clouds.
        drawClouds();

        // Draw mountains.
        drawMountains();

        // Draw trees.
        drawTrees();
        
        // Draw grounds
        drawGround();

        // Draw canyons.
        for (var i = 0; i < canyons.length; i++) 
        {
            drawCanyon(canyons[i]);
            checkCanyon(canyons[i]);
        }
        
        //Render Flag Pole. Moved Here for artistic purposes
        renderFlagpole(); 
        
        if (flagpole.isReached == false)
        {
          checkFlagpole();
        } 

        // Draw collectable items.
        //Draw Dragon balls
        if (Planets[0].Namek || Planets[3].Default)
        {
            for (var i = 0; i < collectablesDBNamek.length; i++) 
            {   
                if (Shenron_sum < 1)
                {
                    if (collectablesDBNamek[i].isFound == false) 
                    {
                        drawDBNamekCollectable(collectablesDBNamek[i]);
                        checkDBNamekCollectable(collectablesDBNamek[i]);
                    }
                }
            }
        }
        
        if (Planets[1].Earth)
        {
            for (var i = 0; i < collectablesDBEarth.length; i++) 
            {
                if (Shenron_sum < 1)
                {
                    if (collectablesDBEarth[i].isFound == false) 
                    {
                        drawDBEarthCollectable(collectablesDBEarth[i]);
                        checkDBEarthCollectable(collectablesDBEarth[i]);
                    }
                }
            }
        }
        
        //Draw Zeni
        if (Planets[0].Namek || Planets[3].Default)
        {    
            for (var i = 0; i < collectableZeni.length; i++) 
            {
                if (collectableZeni[i].isFound == false) 
                {
                    drawZeniCollectable(collectableZeni[i]);
                    checkZeniCollectable(collectableZeni[i]);
                }
            }   
        }
        
        if (Planets[1].Earth)
        {
            for (var i = 12; i < collectableZeni.length; i++) 
            {
                if (collectableZeni[i].isFound == false) 
                {
                    drawZeniCollectable(collectableZeni[i]);
                    checkZeniCollectable(collectableZeni[i]);
                }
            }
        }
        
        if (Planets[2].King_Kai_World)
        {
            for (var i = 12; i < collectableZeni.length; i++) 
            {
                if (collectableZeni[i].isFound == false) 
                {
                    drawZeniCollectable(collectableZeni[i]);
                    checkZeniCollectable(collectableZeni[i]);
                }
            } 
        }
        
        //Draw Gem
        if (Planets[0].Namek || Planets[3].Default)
        {
            for (var i = 0; i < 3; i++) 
            {
                if (collectableGem[i].isFound == false) 
                {
                    drawGemCollectable(collectableGem[i]);
                    checkGemCollectable(collectableGem[i]);
                }
            }
        }
        
        if (Planets[1].Earth)
        {
            for (var i = 4; i < collectableGem.length; i++) 
            {
                if (collectableGem[i].isFound == false) 
                {
                    drawGemCollectable(collectableGem[i]);
                    checkGemCollectable(collectableGem[i]);
                }
            }
        }
        
        if (Planets[2].King_Kai_World)
        {
            for (var i = 4; i < collectableGem.length; i++) 
            {
                if (collectableGem[i].isFound == false) 
                {
                    drawGemCollectable(collectableGem[i]);
                    checkGemCollectable(collectableGem[i]);
                }
            }
        }
        
        //Draw Heart
        for (var i = 0; i < collectableHearts.length; i++) 
        {
            if (collectableHearts[i].isFound == false) 
            {
                drawHeartCollectable(collectableHearts[i]);
                checkHeartCollectable(collectableHearts[i]);
            }
        }
        
        //Draw Candy
        if (game_characters[2].Majin_Buu && Candy_rush == true)
        {
            for (var i = 0; i < collectableCandy.length; i++) 
            {
                if (collectableCandy[i].isFound == false) 
                {
                    drawCandyCollectable(collectableCandy[i]);
                    checkCandyCollectable(collectableCandy[i]);
                }
            }  
        }

        //Platforms
        if (Planets[0].Namek || Planets[3].Default)
        {
            for (var i = 0; i < platformsNamekDef.length ; i++)
            {
                platformsNamekDef[i].draw();
            }
        }
        
        if (Planets[1].Earth)
        {
            for (var i = 0; i < platformsEarth.length; i++)
            {
                platformsEarth[i].draw();
            }
        }
        
        if (Planets[2].King_Kai_World)
        {
            for (var i = 0; i < platformsKKW.length; i++)
            {
                platformsKKW[i].draw();
            }
        }
        
        //Draw Tokens
        for (var i = 0; i < collectableBeerus.length; i++) 
        {
            if (collectableBeerus[i].isFound == false) 
            {
                drawTokens(collectableBeerus[i]);
                checkBeerusToken(collectableBeerus[i]);
            }
            
            if (collectableMasterRoshi[i].isFound == false) 
            { 
                drawTokens(collectableMasterRoshi[i]);
                checkMasterRoshiToken(collectableMasterRoshi[i]);
            }
            
            if (collectableHercule[i].isFound == false) 
            { 
                drawTokens(collectableHercule[i]);
                checkHerculeToken(collectableHercule[i]);
            }
        }
        
        //Draw Chests
        for (var i = 0; i < collectableChestRed.length; i++) 
        {
            if (collectableChestRed[i].isFound == false) 
            {
                drawChest(collectableChestRed[i]);
                checkChestRed(collectableChestRed[i]);
            }
            
            if (collectableChestBlue[i].isFound == false) 
            {
                drawChest(collectableChestBlue[i]);
                checkChestBlue(collectableChestBlue[i]);
            }
            
            if (collectableChestYellow[i].isFound == false) 
            {
                drawChest(collectableChestYellow[i]);
                checkChestYellow(collectableChestYellow[i]);
            }
        }
        
        ////////////////////////////Draw Enemies///////////////////////////
        if (Planets[0].Namek || Planets[3].Default)
        {
            //Enemies
            // Dodoria
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[0].drawDodoria();

                var isContact = enemies[0].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }

            // Zarbon
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[1].drawZarbon();

                var isContact = enemies[1].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }

            // Frieza
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[2].drawFrieza();

                var isContact = enemies[2].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }
            
            // Ginyu
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[3].drawGinyu();

                var isContact = enemies[3].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }
        }
        
        if (Planets[2].King_Kai_World && Gregory_char)
        {
            // Gregory
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[4].drawGregory();

                var isContact = enemies[4].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    Gregory_char = false;
                    enemyHitsound.play();
                }
            }
        }
        
        if (Planets[1].Earth)
        {
            // Super Buu
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[5].drawSuperBuu();

                var isContact = enemies[5].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }
        }
        
        if (Planets[1].Earth)
        {
            // Cell
            for(var i = 0; i < enemies.length; i++)
            {
                enemies[6].drawCell();

                var isContact = enemies[6].checkContact(gameChar_world_x, gameChar_y);

                if(isContact)
                {
                    lives -=1;
                    enemyHitsound.play();

                    if (lives > 0)
                    {
                        gameChar_x = width/2;
                        GameStart = true;
                        break;
                    }
                }
            }
        }

        ///////////////////////////////////
        pop();
        ///////////////////////////////////

        ///////////////////////////Character Draw///////////////////////////////
        // Draw game characters.
        if (lives == 0 || lives < 0)
        {
            lives = 0;
            isDead = true;
            image(Tomb_Stone_img,
                  gameChar_x-33,
                  gameChar_y-90,
                  100, 100);
            
            game_characters[10].Hercule = false;
            game_characters[9].Master_Roshi = false;
            game_characters[8].Beerus = false;
            game_characters[7].Gotenks = false;
            game_characters[6].Gohan = false;
            game_characters[5].Piccolo = false;
            game_characters[4].Android_18 = false;
            game_characters[3].Vegeta = false;
            game_characters[1].Krillin = false;
            game_characters[0].Goku = false;
            game_characters[2].Majin_Buu = false;
        }
        
        else if (game_characters[0].Goku)
        {
            drawGameCharGoku(); 
        }
 
        else if (game_characters[1].Krillin)
        {
            drawGameCharKrillin(); 
        }
        
        else if (game_characters[2].Majin_Buu)
        {
            drawGameCharMajinBuu(); 
        }
        
        else if (game_characters[3].Vegeta)
        {
            drawGameCharVegeta(); 
        }
        
        else if (game_characters[4].Android_18)
        {
            drawGameCharAndroid18(); 
        }
        
        else if (game_characters[5].Piccolo)
        {
            drawGameCharPiccolo(); 
        }
        
        else if (game_characters[6].Gohan)
        {
            drawGameCharGohan(); 
        }
        
        else if (game_characters[7].Gotenks)
        {
            drawGameCharGotenks();   
        }
        
        else if (game_characters[8].Beerus)
        {
            drawGameCharBeerus();   
        }
        
        else if (game_characters[9].Master_Roshi)
        {
            drawGameCharMasterRoshi();   
        }
        
        else if (game_characters[10].Hercule)
        {
            drawGameCharHercule();   
        }
        
        else
        {
            strokeWeight(1);
            drawGameChar();   
        }        
        
        ///////////////////////////////////
        push();
        translate(scrollPos, 0);
        ///////////////////////////////////
    
        //Extra Background characters
        extraCharacters();
        
        ///////////////////////////////////
        pop();
        ///////////////////////////////////
        
        ///////////////////////////Lives Decrementer/////////////////////////////
        // This is the lives decrementer
        checkPlayerDie();
        
        ///////////////////////////Dragon Radar//////////////////////////////////
        checkRadar();
        
        ///////////////////////////////Character Type////////////////////////////
        //Character Type
        charType();
        
        //////////////////////////////Game Counters//////////////////////////////
        //Game Counter
        gameCounters();
        
        //////////////////////////Tips///////////////////////////////////////////
        
        if (Pause_Menu == false)
        {
            Tips_Screen();
        }
        
        ////////////////////////////Token User interface/////////////////////////
        
        if (Wishes == false)
        {
            userInterfacetokens();
        }
        
        ///////////////////////////Pause menu////////////////////////////////
        if (isDead)
        {
            enemyHitsound.stop();
        }
        
        else
        {
            Shenron_Mods();
            
            if (Pause_Menu)
            {
                PauseMenu();
            } 
            
            ///////////////////////////Character menu////////////////////////////////
            if (charM)
            {
                charMenu();
            }

            ///////////////////////////loot menu////////////////////////////////
            if (lootM)
            {
                lootMenu();
            }
            
            ///////////////////////////controls menu////////////////////////////////
            if (controlsM)
            {
                ControlsMenu();
            }
            ///////////////////////////Extras menu////////////////////////////////
            if (extrasM)
            {
                ExtrasMenu();
            }
        }
        
        /////////////////////////////////////

        //Game over/level complete code
        //Game over code
        if (lives < 1) 
        {
            checkGAME_OVER();
              
            if (GO == true)
            {
                GAME_OVER();

                if(flagpole.isReached == false &&
                   keyCode == 13)
                {
                    lives = 5;
                    startGame();
                    GameStart = false;
                } 
            }
        }    
        
        //Level Complete code
        if (flagpole.isReached)
        {
            checkLEVEL_COMPLETE();
            
            if (LC == true)
            {
                LEVEL_COMPLETE();

                if(flagpole.isReached && 
                   lives > 0 && 
                   keyCode == 13)
                {
                    lives = 5;
                    flagpole.isReached = false;
                    startGame();
                    GameStart = false;
                }
            } 
        }
        
        else
        {
            checkFlagpole();
        }

        ////////////////////////////////Game Logic////////////////////////////////

        // Logic to make the game character move or the background scroll.
        if (isDead || GameStart == false)
        {
            //Nothing should work here besides sound.stop
            enemyHitsound.stop();
        }
        
        else
        {
            if (isLeft) 
            {
                if (gameChar_x > width * 0.4) 
                {
                    gameChar_x -= 5;
                } 
                else 
                {
                    scrollPos += 5;
                }
            }

            if (isRight) 
            {
                if (gameChar_x < width * 0.6) 
                {
                    gameChar_x += 5;
                } 
                else 
                {
                    scrollPos -= 5; // negative for moving against the background
                }
            }
        }

        // Logic to make the game character rise and fall.
        if (gameChar_y < floorPos_y) 
        {
            var isContact = false;
            
            if (Planets[0].Namek || 
                Planets[3].Default )
            {   
                for(var i = 0; i < platformsNamekDef.length; i++)
                {
                if(platformsNamekDef[i].checkContactNamekDef(gameChar_world_x, gameChar_y))
                    {
                        isContact = true;
                        isFalling = false;
                        break;
                    }
                } 
            }
            
            if (Planets[1].Earth)
            {
                for(var i = 0; i < platformsEarth.length; i++)
                {
                    if(platformsEarth[i].checkContactEarth(gameChar_world_x, gameChar_y))
                    {
                        isContact = true;
                        isFalling = false;
                        break;
                    }
                }
            }
            
            if (Planets[2].King_Kai_World)
            {
                for(var i = 0; i < platformsKKW.length; i++)
                {
                    if(platformsKKW[i].checkContactKKW(gameChar_world_x, gameChar_y))
                    {
                        isContact = true;
                        isFalling = false;
                        break;
                    }
                }
            }
            
            if (isContact == false)
            {
                gameChar_y =  gameChar_y + 5 ;
                isFalling = true;
            }
        }

        else 
        {
            isFalling = false;
        }

        // Update real position of gameChar for collision detection.
        gameChar_world_x = gameChar_x - scrollPos;
        
        //Mouse cursor function
        Mouse_Cursor();
    }
    
    else 
    {
        if (loading)
        {
           startScreen();
           Mouse_Cursor(); 
        }
        
        else
        {
            loadingScreen();
        }
    }
}
/////////////////////////////Key control functions///////////////////////////

function keyPressed() 
{
    if (isDead || 
        GameStart == false || 
        Pause_Menu || 
        flagpole.isReached)
    {
        //Nothing should Happen here
    }
    
    else
    {
        //Move character right or left
        if (keyCode == 37) 
        {
            //Left arrow pressed
            isLeft = true;
        } 
        else if (keyCode == 39) 
        {
            //Right arrow pressed
            isRight = true;
        }
        
        if (keyCode == 49)
        {
            Pause_Menu = true;
        }

        //Make character jump
        if (keyCode == 32 && 
            gameChar_y == floorPos_y && 
            isFalling == false ||
           keyCode == 32 && 
            isFalling == false && 
            isPlummeting == false) 
        {
            
            if(Planets[2].King_Kai_World)
            {
                gameChar_y -= 80;    
            }
            else
            {
                gameChar_y -= 110;
            }
            
            if (game_characters[0].Goku || 
                game_characters[6].Gohan || 
                game_characters[7].Gotenks ||
                game_characters[8].Beerus)
            {
                gameChar_y -= 140;
            }

            else if (game_characters[1].Krillin ||
                game_characters[4].Android_18 ||
                game_characters[9].Master_Roshi)
            {
                gameChar_y -= 120;
            }

            else if (game_characters[2].Majin_Buu)
            {
                gameChar_y -= 135;
            }

            else if (game_characters[3].Vegeta)
            {
                gameChar_y -= 150;
            }

            else if (game_characters[5].Piccolo)
            {
                gameChar_y -= 145;
            }
            
            else if (jump_Wish)
            {
                gameChar_y -=180 ;   
            }

            jumpSound.play();
        }
    }
}

function keyReleased() 
{
    if (keyCode == 37) 
    {
    //Left arrow released
    isLeft = false;
    } 
    else if (keyCode == 39) 
    {
    //Right arrow released
    isRight = false;
    }
}

// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.
function drawGameChar() 
{
    // draw game character
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 
             25, 20);

        fill(0, 0, 255);
        triangle(gameChar_x-12,
                 gameChar_y-27,
                 gameChar_x-12,
                 gameChar_y-15,
                 gameChar_x+8,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 
                45, 45);

        stroke(0); //mouth
        line(gameChar_x-20,
             gameChar_y-35,
             gameChar_x-10,
             gameChar_y-35);

        fill(0); //eyes
        rect(gameChar_x-13,
             gameChar_y-50, 
             5, 10);

        fill(0);
        stroke(0);
        ellipse(gameChar_x-4,
                gameChar_y-17, 
                4, 4);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        stroke(255 ,255, 255);
        strokeWeight(3);
        point(gameChar_x-4,
              gameChar_y-17);

        strokeWeight(1);
        noStroke();
        fill(255, 249, 204); //Hands
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-30, 
                5,5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-15,
                5, 5);
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 25,20);

        fill(0, 0, 255);
        triangle(gameChar_x-10,
                 gameChar_y-27,
                 gameChar_x+13,
                 gameChar_y-15, 
                 gameChar_x+13,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 
                45, 45);

        stroke(0); //mouth
        line(gameChar_x+10,
             gameChar_y-35,
             gameChar_x+20,
             gameChar_y-35);

        fill(0); //eyes
        rect(gameChar_x+8,
             gameChar_y-50, 
             5, 10);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        fill(255, 249, 204); //Hands
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-15, 5,5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-30, 
                5, 5);
    }

    else if(isLeft)
    {
        // add your walking left code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 
             25, 20);

        fill(0, 0, 255);
        triangle(gameChar_x-12,
                 gameChar_y-27,
                 gameChar_x-12,
                 gameChar_y-15,
                 gameChar_x+8,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 
                45, 45);

        stroke(0); //mouth
        line(gameChar_x-20,
             gameChar_y-35,
             gameChar_x-10,
             gameChar_y-35);

        fill(0,0,0); //eyes
        rect(gameChar_x-13,
             gameChar_y-50, 
             5, 10);

        fill(0);
        stroke(0);
        ellipse(gameChar_x-4,
                gameChar_y-17, 
                4, 4);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        stroke(255, 255, 255);
        strokeWeight(3);
        point(gameChar_x-4,
              gameChar_y-17);

        strokeWeight(1);
        noStroke();

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-15, 
                5, 5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-15, 
                5, 5);
    }

    else if(isRight)
    {
        // add your walking right code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 
             25, 20);

        fill(0, 0, 255);
        triangle(gameChar_x-10,
                 gameChar_y-27,
                 gameChar_x+13,
                 gameChar_y-15,
                 gameChar_x+13,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 
                45, 45);

        stroke(0); //mouth
        line(gameChar_x+10,
             gameChar_y-35,
             gameChar_x+20,
             gameChar_y-35);

        fill(0); //eyes
        rect(gameChar_x+8,
             gameChar_y-50, 
             5, 10);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        fill(255, 249, 204); //Hands
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-15, 
                5, 5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-15, 
                5, 5);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 5,10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 
             25, 20);

        fill(0, 0, 255);
        triangle(gameChar_x-12,
                 gameChar_y-27,
                 gameChar_x,
                 gameChar_y-15,
                 gameChar_x+13,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 45,45);

        stroke(0);
        line(gameChar_x-5,
             gameChar_y-35,
             gameChar_x+5,
             gameChar_y-35);

        fill(0);
        rect(gameChar_x-13,
             gameChar_y-50,5,10);
        rect(gameChar_x+8,
             gameChar_y-50, 
             5, 10);

        fill(0);
        stroke(0);
        ellipse(gameChar_x+7,
                gameChar_y-17, 4,4);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        stroke(255, 255, 255);
        strokeWeight(3);
        point(gameChar_x+7,
              gameChar_y-17);

        strokeWeight(1);
        noStroke();

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-30, 
                5, 5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-30, 
                5, 5);
    }

    else
    {
        // add your standing front facing code
        stroke(0);
        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x+8,
             gameChar_y-10, 
             5, 10);

        fill(255, 150, 100);
        rect(gameChar_x-12,
             gameChar_y-30, 
             25, 20);

        fill(0, 0, 255);
        triangle(gameChar_x-12,
                 gameChar_y-27,
                 gameChar_x,
                 gameChar_y-15,
                 gameChar_x+13,
                 gameChar_y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+0.5,
                gameChar_y-45, 
                45, 45);

        stroke(0);
        line(gameChar_x-5,
             gameChar_y-35,
             gameChar_x+5,
             gameChar_y-35);

        fill(0);
        rect(gameChar_x-13,
             gameChar_y-50, 
             5, 10);

        rect(gameChar_x+8,
             gameChar_y-50, 
             5, 10);

        fill(0);
        stroke(0);
        ellipse(gameChar_x+7,
                gameChar_y-17, 
                4, 4);

        fill(0, 0, 255);
        noStroke();
        rect(gameChar_x-12,
             gameChar_y-13, 
             25, 2);

        stroke(255, 255, 255);
        strokeWeight(3);
        point(gameChar_x+7,
              gameChar_y-17);

        strokeWeight(1);
        noStroke();

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x-20,
                gameChar_y-15, 
                5, 5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(gameChar_x+20,
                gameChar_y-15, 
                5, 5);
    }  
}

// Goku
function drawGameCharGoku()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Goku[4], 
              gameChar_x-40, 
              gameChar_y-115, 
              width/12, 
              height/5.5);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Goku[5], 
              gameChar_x-40, 
              gameChar_y-115, 
              width/12, 
              height/5.5);
        isFalling = true;

    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Goku[2],
              gameChar_x-45, 
              gameChar_y-120,
              width/12,
              height/6);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Goku[3], 
              gameChar_x-45, 
              gameChar_y-120, 
              width/12,
              height/6);

    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Goku[4], 
                  gameChar_x-40, 
                  gameChar_y-115, 
                  width/12, 
                  height/5.5);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Goku[5], 
                  gameChar_x-40,
                  gameChar_y-115,
                  width/12, 
                  height/5.5);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Goku[0],
                  gameChar_x-30, 
                  gameChar_y-115, 
                  width/18.5, 
                  height/4.5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Goku[1],
                  gameChar_x-30, 
                  gameChar_y-115, 
                  width/18.5, 
                  height/4.5);
        }
    }  
};

// Krillin
function drawGameCharKrillin()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Krillin[4], 
              gameChar_x-39, 
              gameChar_y-80, 
              width/14.3, 
              height/6.6);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Krillin[5],
              gameChar_x-39, 
              gameChar_y-80, 
              width/14.3, 
              height/6.6);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Krillin[2], 
              gameChar_x-39, 
              gameChar_y-80, 
              width/13.6, 
              height/8.1);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Krillin[3], 
              gameChar_x-39, 
              gameChar_y-80,
              width/13.6, 
              height/8.1);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Krillin[4], 
                  gameChar_x-39, 
                  gameChar_y-80, 
                  width/14.3,
                  height/6.6);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Krillin[5], 
                  gameChar_x-39, 
                  gameChar_y-80, 
                  width/14.3, 
                  height/6.6);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Krillin[0], 
                  gameChar_x-25, 
                  gameChar_y-90, 
                  width/22.5, 
                  height/6);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Krillin[1], 
                  gameChar_x-25, 
                  gameChar_y-90, 
                  width/22.5, 
                  height/6);
        }
    }  
};

// Majin Buu
function drawGameCharMajinBuu()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Majin_Buu[4], 
              gameChar_x-64, 
              gameChar_y-90, 
              width/8.5, 
              height/5.5);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Majin_Buu[5], 
              gameChar_x-64, 
              gameChar_y-90, 
              width/8.5, 
              height/5.5);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Majin_Buu[2], 
              gameChar_x-61, 
              gameChar_y-90, 
              width/10,
              height/7);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Majin_Buu[3], 
              gameChar_x-61, 
              gameChar_y-90, 
              width/10,
              height/7);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Majin_Buu[4], 
                  gameChar_x-64, 
                  gameChar_y-90,
                  width/8.5, 
                  height/5.5);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Majin_Buu[5], 
                  gameChar_x-64,
                  gameChar_y-90, 
                  width/8.5, 
                  height/5.5);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Majin_Buu[0], 
                  gameChar_x-57, 
                  gameChar_y-100, 
                  width/10,
                  height/5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Majin_Buu[1], 
                  gameChar_x-57,
                  gameChar_y-100, 
                  width/10, 
                  height/5);
        }
    }  
};

// Vegeta
function drawGameCharVegeta()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Vegeta[4],
              gameChar_x-42, 
              gameChar_y-95,
              width/15, 
              height/6);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Vegeta[5],
              gameChar_x-42, 
              gameChar_y-95, 
              width/15, 
              height/6);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Vegeta[2], 
              gameChar_x-60, 
              gameChar_y-95, 
              width/10,
              height/9);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Vegeta[3], 
              gameChar_x-60, 
              gameChar_y-95,
              width/10, 
              height/9);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Vegeta[4], 
                  gameChar_x-42,
                  gameChar_y-95, 
                  width/15, 
                  height/6);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Vegeta[5], 
                  gameChar_x-42,
                  gameChar_y-95, 
                  width/15, 
                  height/6);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Vegeta[0], 
                  gameChar_x-24, 
                  gameChar_y-105,
                  width/27, 
                  height/5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Vegeta[1], 
                  gameChar_x-24, 
                  gameChar_y-105, 
                  width/27, 
                  height/5);
        }
    }  
};

// Android 18
function drawGameCharAndroid18()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Android_18[4], 
              gameChar_x-37,
              gameChar_y-95, 
              width/16.5, 
              height/5.5);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Android_18[5], 
              gameChar_x-37, 
              gameChar_y-95,
              width/16.5, 
              height/5.5);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Android_18[2], 
              gameChar_x-30,
              gameChar_y-120, 
              width/20, 
              height/5);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Android_18[3],
              gameChar_x-30,
              gameChar_y-120, 
              width/20, 
              height/5);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Android_18[4],
                  gameChar_x-37, 
                  gameChar_y-95,
                  width/16.5,
                  height/5.5);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Android_18[5], 
                  gameChar_x-37, 
                  gameChar_y-95, 
                  width/16.5, 
                  height/5.5);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Android_18[0], 
                  gameChar_x-19, 
                  gameChar_y-107,
                  width/30, 
                  height/5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Android_18[1], 
                  gameChar_x-19, 
                  gameChar_y-107, 
                  width/30, 
                  height/5);
        }
    }  
};

// Piccolo
function drawGameCharPiccolo()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Piccolo[4],
              gameChar_x-42, 
              gameChar_y-95, 
              width/15, 
              height/5);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Piccolo[5],
              gameChar_x-42,
              gameChar_y-95, 
              width/15, 
              height/5);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Piccolo[2],
              gameChar_x-76, 
              gameChar_y-80,
              width/8, 
              height/12);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Piccolo[3], 
              gameChar_x-76, 
              gameChar_y-80, 
              width/8, 
              height/12);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Piccolo[4], 
                  gameChar_x-42, 
                  gameChar_y-95, 
                  width/15,
                  height/5);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Piccolo[5], 
                  gameChar_x-42, 
                  gameChar_y-95, 
                  width/15, 
                  height/5);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Piccolo[0], 
                  gameChar_x-28, 
                  gameChar_y-115,
                  width/16,
                  height/4.5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Piccolo[1], 
                  gameChar_x-28, 
                  gameChar_y-115, 
                  width/16, 
                  height/4.5);
        }
    }  
};

// Gohan
function drawGameCharGohan()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Gohan[4], 
              gameChar_x-40, 
              gameChar_y-95, 
              width/16.5, 
              height/7.6);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Gohan[5], 
              gameChar_x-40, 
              gameChar_y-95, 
              width/16.5, 
              height/7.6);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Gohan[2], 
              gameChar_x-50,
              gameChar_y-80, 
              width/13.2, 
              height/9.8);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Gohan[3], 
              gameChar_x-50,
              gameChar_y-80, 
              width/13.2, 
              height/9.8);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Gohan[4],
                  gameChar_x-40,
                  gameChar_y-95,
                  width/16.5, 
                  height/7.6);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Gohan[5], 
                  gameChar_x-40, 
                  gameChar_y-95, 
                  width/16.5,
                  height/7.6);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Gohan[0], 
                  gameChar_x-31,
                  gameChar_y-90, 
                  width/20, 
                  height/6);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Gohan[1],
                  gameChar_x-31,
                  gameChar_y-90,
                  width/20, 
                  height/6);
        }
    }  
};
    
// Gotenks
function drawGameCharGotenks()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Gotenks[4], 
              gameChar_x-33, 
              gameChar_y-95, 
              width/24,
              height/7);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Gotenks[5], 
              gameChar_x-33, 
              gameChar_y-95, 
              width/24, 
              height/7);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Gotenks[2], 
              gameChar_x-37,
              gameChar_y-80, 
              width/19, 
              height/8);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Gotenks[3], 
              gameChar_x-37,
              gameChar_y-80, 
              width/19, 
              height/8);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Gotenks[4], 
                  gameChar_x-33,
                  gameChar_y-95, 
                  width/24, 
                  height/7);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Gotenks[5], 
                  gameChar_x-33, 
                  gameChar_y-95, 
                  width/24, 
                  height/7);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Gotenks[0],
                  gameChar_x-36, 
                  gameChar_y-70, 
                  width/20, 
                  height/8);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Gotenks[1],
                  gameChar_x-36,
                  gameChar_y-70, 
                  width/20, 
                  height/8);
        }
    }    
};

// Beerus
function drawGameCharBeerus()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Beerus[4],
              gameChar_x-31,
              gameChar_y-140,
              width/17.5, 
              height/4.5);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Beerus[5], 
              gameChar_x-31,
              gameChar_y-140, 
              width/17.5,
              height/4.5);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Beerus[2],
              gameChar_x-43, 
              gameChar_y-145, 
              width/14.5, 
              height/4.5);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Beerus[3], 
              gameChar_x-43, 
              gameChar_y-145, 
              width/14.5,
              height/4.5);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Beerus[4], 
                  gameChar_x-31, 
                  gameChar_y-140, 
                  width/17.5, 
                  height/4.5);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Beerus[5],
                  gameChar_x-31,
                  gameChar_y-140,
                  width/17.5,
                  height/4.5);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Beerus[0], 
                  gameChar_x-25, 
                  gameChar_y-120, 
                  width/18.5,
                  height/4.5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Beerus[1],
                  gameChar_x-25,
                  gameChar_y-120,
                  width/18.5, 
                  height/4.5);
        }
    }    
};

// Master Roshi
function drawGameCharMasterRoshi()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Master_Roshi[4], 
              gameChar_x-34, 
              gameChar_y-100, 
              width/12, 
              height/6);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Master_Roshi[5], 
              gameChar_x-34, 
              gameChar_y-100, 
              width/12,
              height/6);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Master_Roshi[2],
              gameChar_x-36,
              gameChar_y-100, 
              width/11,
              height/7);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Master_Roshi[3],
              gameChar_x-36,
              gameChar_y-100, 
              width/11,
              height/7);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Master_Roshi[4], 
                  gameChar_x-34, 
                  gameChar_y-100, 
                  width/12, 
                  height/6);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Master_Roshi[5], 
                  gameChar_x-34,
                  gameChar_y-100,
                  width/12,
                  height/6);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Master_Roshi[0],
                  gameChar_x-30, 
                  gameChar_y-90,
                  width/15,
                  height/6);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Master_Roshi[1], 
                  gameChar_x-30, 
                  gameChar_y-90,
                  width/15, 
                  height/6);
        }
    }    
};

// Hercule
function drawGameCharHercule()
{
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        image(Hercule[4], 
              gameChar_x-30,
              gameChar_y-100, 
              width/15, 
              height/6);
        isFalling = true;
    }

    else if(isRight && isFalling)
    {
        // add your jumping-right code
        image(Hercule[5], 
              gameChar_x-30, 
              gameChar_y-100,
              width/15,
              height/6);
        isFalling = true;
    }

    else if(isLeft)
    {
        // add your walking left code
        wasRight = false;
        wasLeft = true;
        image(Hercule[2],
              gameChar_x-26, 
              gameChar_y-120,
              width/20,
              height/5.5);
    }

    else if(isRight)
    {
        // add your walking right code
        wasRight = true;
        wasLeft = false;
        image(Hercule[3],
              gameChar_x-26, 
              gameChar_y-120, 
              width/20,
              height/5.5);
    }

    else if(isFalling || isPlummeting)
    {
        // add your jumping facing forwards code
        if (isFalling == true && wasLeft == true) 
        {
            image(Hercule[4], 
                  gameChar_x-30, 
                  gameChar_y-100, 
                  width/15, 
                  height/6);
        }
        else if (isFalling == true && wasRight ==true)
        {
            image(Hercule[5], 
                  gameChar_x-30,
                  gameChar_y-100,
                  width/15, height/6);
        }
    }

    else
    {
        // add your standing front facing code
        if (wasLeft == true && isLeft == false)
        {
            image(Hercule[0], 
                  gameChar_x-24,
                  gameChar_y-110, 
                  width/20,
                  height/5);
        }

        else if (wasRight == true && isRight == false)
        {
            image(Hercule[1], 
                  gameChar_x-24, 
                  gameChar_y-110, 
                  width/20, 
                  height/5);
        }
    }    
};

// Extra Characters
function extraCharacters()
{
    if (Planets[0].Namek)
    {
        image(Dende_img,50,floorPos_y-55,35,60);
        
        image(KameChicken[0],100,floorPos_y-20,30,30);
        image(KameChicken[1],1000,floorPos_y-20,30,30);
        image(KameChicken[1],2000,floorPos_y-20,30,30);
        image(KameChicken[0],3000,floorPos_y-20,30,30);
        image(KameChicken[1],-1000,floorPos_y-20,30,30);
        image(KameChicken[1],-2000,floorPos_y-20,30,30);
        image(KameChicken[0],-3000,floorPos_y-20,30,30);
        
    }
    
    if (Planets[1].Earth)
    {
        image(Android16_img,700,floorPos_y-140,70,150);
        image(Android17_img,800,floorPos_y-110,40,120);
        
        image(KameChicken[0],200,floorPos_y-20,30,30);
        image(KameChicken[1],1000,floorPos_y-20,30,30);
        image(KameChicken[1],2000,floorPos_y-20,30,30);
        image(KameChicken[0],3000,floorPos_y-20,30,30);
        image(KameChicken[1],-1000,floorPos_y-20,30,30);
        image(KameChicken[1],-2000,floorPos_y-20,30,30);
        image(KameChicken[0],-3000,floorPos_y-20,30,30);
    }
    
    if (Planets[2].King_Kai_World)
    {
        image(Tien_img,700,floorPos_y-110,50,120);
        image(Yamcha_img,200,floorPos_y-110,60,120);
        image(Chiatzu_img,100,floorPos_y-110,40,60);
        
        image(KameChicken[0],300,floorPos_y-20,30,30);
        image(KameChicken[1],1000,floorPos_y-20,30,30);
        image(KameChicken[1],2000,floorPos_y-20,30,30);
        image(KameChicken[0],3000,floorPos_y-20,30,30);
        image(KameChicken[1],-1000,floorPos_y-20,30,30);
        image(KameChicken[1],-2000,floorPos_y-20,30,30);
        image(KameChicken[0],-3000,floorPos_y-20,30,30);
    }
    
    if (Planets[3].Default)
    {
        image(DR_B_img,50,floorPos_y-75,60,80);
        
        image(KameChicken[0],400,floorPos_y-20,30,30);
        image(KameChicken[1],1000,floorPos_y-20,30,30);
        image(KameChicken[1],2000,floorPos_y-20,30,30);
        image(KameChicken[0],3000,floorPos_y-20,30,30);
        image(KameChicken[1],-1000,floorPos_y-20,30,30);
        image(KameChicken[1],-2000,floorPos_y-20,30,30);
        image(KameChicken[0],-3000,floorPos_y-20,30,30);
    }
}

//////////////////////// Background render functions//////////////////////////

// Function to draw ground
function drawGround()
{
    if (Planets[1].Earth)
    {
        for (var i = 0; i < Ground_length; i++)
        {
            image(Earth_Ground,width*[i],
                  floorPos_y-25,
                  width+10, 
                  height/4+25);
            
            image(Earth_Ground,-width*[i],
                  floorPos_y-25,
                  width+10, 
                  height/4+25);
        }
    }
    
    if (Planets[0].Namek)
    {
        for (var i = 0; i < Ground_length; i++)
        {
            image(Namek_Ground,width*[i],
                  floorPos_y-25,
                  width+10, 
                  height/4+25);
            
            image(Namek_Ground,
                  -width*[i],
                  floorPos_y-25, 
                  width+10, 
                  height/4+25);
        }
    }
    
    if (Planets[2].King_Kai_World)
    {
        for (var i = 0; i < Ground_length; i++)
        {
            image(King_Kai_Ground,
                  width*[i],
                  floorPos_y-25, 
                  width+10, 
                  height/4+25);
            
            image(King_Kai_Ground,
                  -width*[i],
                  floorPos_y-25, 
                  width+10,
                  height/4+25);
        }
    }
};

// Function to draw cloud objects.
function drawClouds()
{
    //Cloud
    for (var i = 0; i < clouds.length; i++)
    {   
        if (Planets[1].Earth)
        {
            image(Cloud_large_bulky_img,
                  20 + clouds[i].cloud_X_pos,
                  75 + clouds[i].cloud_Y_pos,
                  300 + clouds[i].cloud_size,
                  100 + clouds[i].cloud_size);
            
            image(Cloud_medium_img,
                  -500 + clouds[i].cloud_X_pos,
                  10 + clouds[i].cloud_Y_pos,
                  300 + clouds[i].cloud_size,
                  100 + clouds[i].cloud_size);
        }

        if (Planets[0].Namek)
        {
            image(Cloud_small_img,
                  20 + clouds[i].cloud_X_pos,
                  75 + clouds[i].cloud_Y_pos,
                  150 + clouds[i].cloud_size,
                  75 + clouds[i].cloud_size);
            
            image(Cloud_small_bulky_img,
                  -500 + clouds[i].cloud_X_pos,
                  10 + clouds[i].cloud_Y_pos,
                  150 + clouds[i].cloud_size,
                  50 + clouds[i].cloud_size);
        }

        if (Planets[2].King_Kai_World)
        {
            image(Cloud_large_bulky_yellow_img,
                  20 + clouds[i].cloud_X_pos,
                  75 + clouds[i].cloud_Y_pos,
                  200 + clouds[i].cloud_size,
                  100 + clouds[i].cloud_size);
            
            image(Cloud_medium_yellow_img,
                  -500 + clouds[i].cloud_X_pos,
                  10 + clouds[i].cloud_Y_pos,
                  300 + clouds[i].cloud_size,
                  100 + clouds[i].cloud_size);
        }

        if (Planets[3].Default)
        {
            noStroke(0);
            fill(250, 250, 250); 

            ellipse(90+clouds[i].cloud_X_pos+
                    clouds[i].cloud_size/8,
                    120+clouds[i].cloud_Y_pos+
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+50, 
                    clouds[i].cloud_size+50);

            ellipse(150+clouds[i].cloud_X_pos-
                    clouds[i].cloud_size/8,
                    120+clouds[i].cloud_Y_pos+
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+50,
                    clouds[i].cloud_size+50);

            ellipse(170+clouds[i].cloud_X_pos-
                    clouds[i].cloud_size/8,
                    155+clouds[i].cloud_Y_pos-
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+50,
                    clouds[i].cloud_size+50);

            ellipse(120+clouds[i].cloud_X_pos,
                    100+clouds[i].cloud_Y_pos+
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+50,
                    clouds[i].cloud_size+50);

            ellipse(70+clouds[i].cloud_X_pos+
                    clouds[i].cloud_size/8,
                    155+clouds[i].cloud_Y_pos-
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+50,
                    clouds[i].cloud_size+50);

            ellipse(120+clouds[i].cloud_X_pos,
                    150+clouds[i].cloud_Y_pos-
                    clouds[i].cloud_size/8,
                    clouds[i].cloud_size+75,
                    clouds[i].cloud_size+75); 
        }
    }
};

// Function to draw mountains objects.
function drawMountains() 
{
    for (var i = 0; i < mountains.length; i++) 
    {
        if (Planets[1].Earth)
        {
            //Mountains
            image(Mountain_1,
                  mountains[i].mountain_x_pos, 
                  floorPos_y-50, 50,50);
            
            image(Mountain_2,
                  mountains[i].mountain_x_pos+500, 
                  floorPos_y-50, 50,50);
            
            image(Mountain_3,
                  mountains[i].mountain_x_pos+1500,
                  floorPos_y-50, 50,50);
            
            //Rocks
            image(Rock_1,
                  mountains[i].mountain_x_pos, 
                  floorPos_y-25, 25,25);
            
            image(Rock_2,
                  mountains[i].mountain_x_pos+500,
                  floorPos_y-25, 25,25);
            
            image(Rock_3,
                  mountains[i].mountain_x_pos+1500, 
                  floorPos_y-25, 25,25);
        }
    

        if (Planets[0].Namek)
        {
            //Mountains
            image(Mountain_4,
                  mountains[i].mountain_x_pos, 
                  floorPos_y-50, 150,50);
            
            image(Mountain_5,
                  mountains[i].mountain_x_pos+500, 
                  floorPos_y-50, 50,50);
            
            image(Mountain_6,
                  mountains[i].mountain_x_pos+1500,
                  floorPos_y-50, 50,50);
            
            //Rocks
            image(Rock_4,
                  mountains[i].mountain_x_pos, 
                  floorPos_y-50, 50,50);
            
            image(Rock_5,
                  mountains[i].mountain_x_pos+500, 
                  floorPos_y-50, 50,50);
            
            image(Rock_6,
                  mountains[i].mountain_x_pos+1500, 
                  floorPos_y-50, 50,50);
        }

        if (Planets[2].King_Kai_World)
        {
            image(Rock_1,
                  mountains[i].mountain_x_pos, 
                  floorPos_y-50, 50,50);
            
            image(Rock_3,
                  mountains[i].mountain_x_pos+500, 
                  floorPos_y-50, 50,50);
            
            image(Rock_6,
                  mountains[i].mountain_x_pos+1500,
                  floorPos_y-50, 50,50);
        }

        if (Planets[3].Default)
        {
            stroke(0);
            fill(200, 100, 100);
            triangle(0 + mountains[i].mountain_x_pos, floorPos_y, 
                     150 + mountains[i].mountain_x_pos, 200,
                     300 + mountains[i].mountain_x_pos, floorPos_y);
            
            stroke(0);
            fill(200, 150, 100);
            triangle(-500 + mountains[i].mountain_x_pos, floorPos_y, 
                     -650 + mountains[i].mountain_x_pos, 300,
                     -800 + mountains[i].mountain_x_pos, floorPos_y);
            
            stroke(0);
            fill(200, 150, 100);
            triangle(-500 + mountains[i].mountain_x_pos, floorPos_y, 
                     -700 + mountains[i].mountain_x_pos, 350,
                     -900 + mountains[i].mountain_x_pos, floorPos_y);
            
            //Rocks
            fill(100,100,100);
            ellipse(mountains[i].mountain_x_pos + 50,
            floorPos_y-25, 50,50);
            
            ellipse(mountains[i].mountain_x_pos + 200,
            floorPos_y-25, 50,50);
            
            ellipse(mountains[i].mountain_x_pos + 350,
            floorPos_y-25, 50,50);
        }
    }
};

// Function to draw trees objects.
function drawTrees() 
{
    if (Planets[0].Namek)
    {
        for (var i = 0; i < trees_x.length; i++) 
        {
            for (var j = 0; j < trees_y.length; j++) 
            {
                stroke(0);
                strokeWeight(1);
                fill(255, 125, 100);

                //Tree
                rect(trees_x[i]-82, 
                     tree_y+44 - trees_y[j], 
                     5, 100+ trees_y[j]);

                //Tree Flakes
                fill(100,200,100);
                ellipse(trees_x[i]-79,
                        tree_y+50 - trees_y[j],
                        50,50);
            }
        }
    }
    
    if (Planets[1].Earth)
    {
        for (var i = 0; i < trees_x.length; i++) 
        {
            image(Earth_Tree,trees_x[i],
                  tree_y-50, 100,200);
        }
    }
    
    if (Planets[2].King_Kai_World)
    {
        for (var i = 0; i < trees_x.length; i++) 
        {
            image(King_Kai_Tree,
                  trees_x[i],
                  tree_y+40, 100,100);
        }
    }
    
    if (Planets[3].Default)
    {
        for (var i = 0; i < trees_x.length; i++) 
        {
            stroke(0);
            strokeWeight(1);
            fill(255,125,100);
            //Tree
            rect(trees_x[i]-82, 
                 tree_y+30, 10,113);

            //Tree Flakes
            fill(0,255,150);
            triangle(trees_x[i]-120, 
                     tree_y+75,
                     trees_x[i]-85, 
                     tree_y-120,
                     trees_x[i]-30, 
                     tree_y+75);

            triangle(trees_x[i]-120, 
                     tree_y+35, 
                     trees_x[i]-85, 
                     tree_y-120, 
                     trees_x[i]-30, 
                     tree_y+60);

            triangle(trees_x[i]-120, 
                     tree_y-5, 
                     trees_x[i]-85, 
                     tree_y-120, 
                     trees_x[i]-30, 
                     tree_y+45);
        }
    } 
}

//////////////////////// Canyon render and check functions///////////////////

// Function to draw canyon objects.
function drawCanyon(t_canyon) 
{
    noStroke;
    strokeWeight(0);

    fill(140, 60, 35);
    rect(t_canyon.x_pos+100 - 50, 
         477/576*height,
         t_canyon.width +25, 
         144);
    
    triangle(t_canyon.x_pos+100 -
             50, 477/576*height,
             t_canyon.x_pos+100, 
             432/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width-25, 
             477/576*height);
    
    triangle(t_canyon.x_pos+100, 
             477/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width, 
             432/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width -25, 
             477/576*height);
    
    triangle(t_canyon.x_pos+100, 
             432/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width, 
             432/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width/2 -8, 
             470/576*height);
    
    strokeWeight(1);
    line(t_canyon.x_pos+100, 432/576*height, t_canyon.x_pos+100, height-30);
    
    
    //Water
    noStroke;
    strokeWeight(0);
    fill(0, 0, 255, 200);
    rect(t_canyon.x_pos+50, 546/576*height,
         t_canyon.width+25, 30);
    
    strokeWeight(0);
    triangle(t_canyon.x_pos+100 -50, 
             546/576*height,
             t_canyon.x_pos+100, 
             502/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width -25, 
             546/576*height);
    
    triangle(t_canyon.x_pos+100 + 
             t_canyon.width - 25,
             546/576*height,
             t_canyon.x_pos+100, 
             502/576*height,
             t_canyon.x_pos+100 + 
             t_canyon.width -25, 
             502/576*height); 
};

// Function to check character is over a canyon.
function checkCanyon(t_canyon) 
{
    canyon_space = t_canyon.x_pos + 
        100 + 
        t_canyon.width / 2;
        
    if (int(dist(canyon_space,
                 floorPos_y, 
                 gameChar_world_x,
                 gameChar_y) < t_canyon.width/2 && 
                 gameChar_y == floorPos_y) && 
                 t_canyon.width >= 30)
    {  
        isPlummeting = true;  
    }

    else if (isPlummeting == true)
    {
        gameChar_y += 1;  
    }

    else 
    {
       isPlummeting = false; 
    }

    if (isPlummeting == true)
    {
        gameChar_y += 1;
    }
};

///////////////////Collectable items render and check functions//////////////////

// Function to draw collectable objects.
function drawDBNamekCollectable(t_collectable) 
{
    //Dragon Ball
    // I made the 1-7 star Dragonballs.
    
    if (Planets[3].Default)
    {
         stroke(0);
    fill(255,200,0);  
    ellipse(t_collectable.x_pos,
            t_collectable.y_pos/576*height,
            t_collectable.size,
            t_collectable.size);
    
        if (t_collectable.DB_num == 1)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 2)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos-10,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 3)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos,
                -12+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                7+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                7+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 4)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos-10,
                -10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                -10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 5)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                -10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                -10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                10+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 6)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos,
                -15+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-15,
                -5+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+15,
                -5+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                12+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                12+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }

        else if (t_collectable.DB_num == 7)
        {
        noStroke();
        fill(255,100,0);
        ellipse(t_collectable.x_pos-10,
                -15+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                -15+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-15,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+15,
                t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos-10,
                15+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);

        ellipse(t_collectable.x_pos+10,
                15+t_collectable.y_pos/576*height,
                t_collectable.size-40,
                t_collectable.size-40);
        }
    }
    
    else
    {
        stroke(0);
        strokeWeight(1);
        fill(255, 200, 0);  
        ellipse(t_collectable.x_pos,
        t_collectable.y_pos/576*height,
        t_collectable.size,
        t_collectable.size);

        if (t_collectable.DB_num == 1)
        {
            image(Dragon_balls_img[0],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 2)
        { 
            image(Dragon_balls_img[1],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 3)
        {
            image(Dragon_balls_img[2],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 4)
        {
            image(Dragon_balls_img[3],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 5)
        {
            image(Dragon_balls_img[4],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 6)
        {
            image(Dragon_balls_img[5],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }

        else if (t_collectable.DB_num == 7)
        {
            image(Dragon_balls_img[6],
                  t_collectable.x_pos- 
                  t_collectable.size/2,
                  (t_collectable.y_pos - 
                  t_collectable.size/2)/576*height,
                  t_collectable.size,
                  t_collectable.size);
        }
    }
};

// Function to check character has collected an item.
function checkDBNamekCollectable(t_collectable) 
{
    if((dist(t_collectable.x_pos,
             t_collectable.y_pos/576*height,
            gameChar_world_x,
            gameChar_y) < 40 ))
    {
        t_collectable.isFound = true; 
        game_score += 50;
        Dragon_ball_Counter +=1;
        collectDBSound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
}

//Earths Dragon balls
function drawDBEarthCollectable(t_collectable) 
{
    //Dragon Ball
    // I made the 1-7 star Dragonballs.

    stroke(0);
    strokeWeight(2);
    fill(255, 200, 0);  
    ellipse(t_collectable.x_pos,
    t_collectable.y_pos/576*height,
    t_collectable.size,
    t_collectable.size);

    if (t_collectable.DB_num == 1)
    {
        image(Dragon_balls_img[0],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 2)
    { 
        image(Dragon_balls_img[1],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 3)
    {
        image(Dragon_balls_img[2],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 4)
    {
        image(Dragon_balls_img[3],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 5)
    {
        image(Dragon_balls_img[4],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 6)
    {
        image(Dragon_balls_img[5],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }

    else if (t_collectable.DB_num == 7)
    {
        image(Dragon_balls_img[6],
              t_collectable.x_pos- 
              t_collectable.size/2,
              (t_collectable.y_pos - 
              t_collectable.size/2)/576*height,
              t_collectable.size,
              t_collectable.size);
    }
};

// Function to check character has collected an item.
function checkDBEarthCollectable(t_collectable) 
{
    if((dist(t_collectable.x_pos,
             t_collectable.y_pos/576*height,
            gameChar_world_x,
            gameChar_y) < t_collectable.size ))
    {
        t_collectable.isFound = true; 
        game_score += 50;
        Dragon_ball_Counter +=1;
        collectDBSound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
}

// Zeni Collectable
function drawZeniCollectable(t_collectable) 
{
    //Zeni coins
    // Zeni coins are the currency.    
    if (t_collectable.size < 40)
    {
        t_collectable.size *= random(1,1.005);
    }
    
    else if (t_collectable.size > 30)
    {
        t_collectable.size *= random(-1,-0.9995);
        
        t_collectable.size = max(31, t_collectable.size)
    }
    
    fill(255,230,0);
    stroke(0);
    strokeWeight(1);
    
    if (Planets[3].Default)
    {
        ellipse(t_collectable.x,
          t_collectable.y/576*height,
          t_collectable.size,
          t_collectable.size);
        
        ellipse(t_collectable.x,
          t_collectable.y/576*height,
          t_collectable.size/1.4,
          t_collectable.size/1.4);  
    }
    
    else
    {
        image(Zeni_coins_img[0],
          t_collectable.x-t_collectable.size/2,
          (t_collectable.y-t_collectable.size/2)/576*height,
          t_collectable.size,
          t_collectable.size);
    }
};

// Function to check character has collected an item.
function checkZeniCollectable(t_collectable) 
{
    if((dist(t_collectable.x,
             t_collectable.y/576*height,
            gameChar_world_x,
            gameChar_y) < t_collectable.size ))
    {
        t_collectable.isFound = true; 
        game_score += 10;
        Zeni_coins_counter += 1;
        collectCoinSound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
};

// Gem Collectable
function drawGemCollectable(t_collectable) 
{
    //Zeni coins
    // Zeni coins are the currency.
    image(Gem_img[0],
          t_collectable.x-t_collectable.size/2-5,
          (t_collectable.y-t_collectable.size/2)/576*height,
          t_collectable.size+5,
          t_collectable.size);
};

// Function to check character has collected an item.
function checkGemCollectable(t_collectable) 
{
    if((dist(t_collectable.x,
             t_collectable.y/576*height,
            gameChar_world_x,
            gameChar_y) < t_collectable.size ))
    {
        t_collectable.isFound = true; 
        game_score += 20;
        Gem_counter += 1;
        collectGemSound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
};

// Heart Collectable
function drawHeartCollectable(t_collectable) 
{
    //Heart collectables
    // Heart Collectables increase character lives.
    if (t_collectable.size < 40)
    {
        t_collectable.size *= random(1,1.005);
    }
    
    if (t_collectable.size > 39)
    {
        t_collectable.size *= random(-1,-0.9995);
        
        t_collectable.size = max(35, t_collectable.size)
    }
    
    image(Hearts_img[0],
          t_collectable.x-t_collectable.size/2,
          (t_collectable.y-t_collectable.size/2)/576*height,
          t_collectable.size,
          t_collectable.size);
};

// Function to check character has collected an item.
function checkHeartCollectable(t_collectable) 
{
    if((dist(t_collectable.x,
             t_collectable.y/576*height,
            gameChar_world_x,
            gameChar_y) < t_collectable.size ) && 
            lives < 5)
    {
        t_collectable.isFound = true; 
        lives += 1;
        collectHeartSound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
};

// Zeni Collectable
function drawCandyCollectable(t_collectable) 
{
    //Candy
    //Buu needs Candy.    
    fill(255,230,0);
    stroke(0);
    strokeWeight(1);
    image(Candy_img[0],
      t_collectable.x,
      t_collectable.y/576*height,
      t_collectable.size,
      t_collectable.size);
    
    image(Candy_img[1],
      t_collectable.x-5,
      t_collectable.y/576*height-5,
      t_collectable.size,
      t_collectable.size);
    
    image(Candy_img[2],
      t_collectable.x+5,
      t_collectable.y/576*height+5,
      t_collectable.size,
      t_collectable.size);
    
    image(Candy_img[3],
      t_collectable.x+5,
      t_collectable.y/576*height-5,
      t_collectable.size,
      t_collectable.size);
    
    image(Candy_img[4],
      t_collectable.x-5,
      t_collectable.y/576*height+5,
      t_collectable.size,
      t_collectable.size);
    
    image(Candy_img[5],
      t_collectable.x-5,
      t_collectable.y/576*height,
      t_collectable.size,
      t_collectable.size);
};

// Function to check character has collected an item.
function checkCandyCollectable(t_collectable) 
{
    if((dist(t_collectable.x,
             t_collectable.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_collectable.isFound = true; 
        game_score += 20;
        Time_score +=100;
        collectCandySound.play();
    }
    else if (t_collectable.isFound == false)
    {
        t_collectable.isFound = false; 
    }
};

// Tokens
function drawTokens(t_token) 
{
    //Zeni coins
    // Zeni coins are the currency.    
    if (t_token.size < 60)
    {
        t_token.size *= random(1,1.005);
    }
    
    else if (t_token.size > 40)
    {
        t_token.size *= random(-1,-0.9995);
        
        t_token.size = max(50, t_token.size);
    }
    
    for (var i = 0; i < 3; i++)
    {
        if (t_token == collectableBeerus[i])
        {
            image(Beerus_Portrait,
                  t_token.x - t_token.size/2,
                  (t_token.y - t_token.size/2)/576*height,
                  t_token.size +5,
                  t_token.size);
        }

        if (t_token == collectableMasterRoshi[i])
        {
            image(Master_Roshi_Portrait,
                  t_token.x - t_token.size/2,
                 (t_token.y - t_token.size/2)/576*height,
                  t_token.size +5,
                  t_token.size);
        }

        if (t_token == collectableHercule[i])
        {
            image(Hercule_Portrait,
                  t_token.x - t_token.size/2,
                  (t_token.y - t_token.size/2)/576*height,
                  t_token.size +5,
                  t_token.size);
        }
    }
};

// Function to check character has collected an item.
function checkBeerusToken(t_token) 
{
    if((dist(t_token.x,
             t_token.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_token.isFound = true; 
        game_score += 100;
        Zeni_coins_counter += 5;
        Beerus_Tokens += 1;
        collectTokenSound.play();
    }
    else if (t_token.isFound == false)
    {
        t_token.isFound = false; 
    }
};

// Function to check character has collected an item.
function checkMasterRoshiToken(t_token) 
{
    if((dist(t_token.x,
             t_token.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_token.isFound = true; 
        game_score += 100;
        Zeni_coins_counter += 5;
        Master_Roshi_Tokens += 1;
        collectTokenSound.play();
    }
    else if (t_token.isFound == false)
    {
        t_token.isFound = false; 
    }
};

// Function to check character has collected an item.
function checkHerculeToken(t_token) 
{
    if((dist(t_token.x,
             t_token.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_token.isFound = true; 
        game_score += 100;
        Zeni_coins_counter += 5;
        Hercule_Tokens += 1;
        collectTokenSound.play();
    }
    else if (t_token.isFound == false)
    {
        t_token.isFound = false; 
    }
};

//Chests
function drawChest(t_chest) 
{
    //Chests, Red, Blue, Yellow
    // Chests are bonuses.    
    for (var i = 0; i < 3; i++)
    {
        if (t_chest == collectableChestRed[i])
        {
            image(Red_chest,
                  t_chest.x - t_chest.size/2,
                  (-10+t_chest.y - 
                   t_chest.size/2)/576*height,
                  t_chest.size +5,
                  t_chest.size);
        }

        if (t_chest == collectableChestBlue[i])
        {
            image(Blue_chest,
                  t_chest.x - t_chest.size/2,
                  (-10+t_chest.y - 
                   t_chest.size/2)/576*height,
                  t_chest.size +5,
                  t_chest.size);
        }

        if (t_chest == collectableChestYellow[i])
        {
            image(Yellow_chest,
                  t_chest.x - t_chest.size/2,
                  (-10+t_chest.y - 
                   t_chest.size/2)/576*height,
                  t_chest.size +5,
                  t_chest.size);
        }
    }
};

// Function to check character has collected an item.
function checkChestRed(t_chest) 
{
    if((dist(t_chest.x,
             t_chest.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_chest.isFound = true; 
        game_score += 200;
        Zeni_coins_counter += 10;
        Red_chest_counter += 1;
        collectChestSound.play();
    }
    else if (t_chest.isFound == false)
    {
        t_chest.isFound = false; 
    }
};

// Function to check character has collected an item.
function checkChestBlue(t_chest) 
{
    if((dist(t_chest.x,
             t_chest.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_chest.isFound = true; 
        game_score += 200;
        Zeni_coins_counter += 10;
        Blue_chest_counter += 1;
        collectChestSound.play();
    }
    else if (t_chest.isFound == false)
    {
        t_chest.isFound = false; 
    }
};

// Function to check character has collected an item.
function checkChestYellow(t_chest) 
{
    if((dist(t_chest.x,
             t_chest.y/576*height,
            gameChar_world_x,
            gameChar_y) < 50 ))
    {
        t_chest.isFound = true; 
        game_score += 200;
        Zeni_coins_counter += 10;
        Yellow_chest_counter += 1;
        collectChestSound.play();
    }
    else if (t_chest.isFound == false)
    {
        t_chest.isFound = false; 
    }
};

///////////////////////////////Dragon Radar/////////////////////////////////////
function checkRadar()
{   
    stroke(0);
    strokeWeight(3);
    textSize(20);

    image(Shenron_Dragon_Stand,120,-50,425,175);
    
    for (var i =0; i < 7; i++)
    {
        fill(0,0,0,10);
        strokeWeight(5);
        stroke(255,0,0);
        rect(290+i*32,40,30,30,20);
        
        strokeWeight(2);
        stroke(0);
        rect(290+i*32,40,31,31,20);
        
        strokeWeight(5);
        stroke(255,150,100);
    }
    
        stroke(0);
    
        if(Shenron_sum < 1)
        {
            if (collectablesDBNamek[0].isFound || 
                collectablesDBEarth[0].isFound)
            {
                image(Dragon_balls_img[0],
                      290, 
                      40, 30,30);
            }

            if (collectablesDBNamek[1].isFound || 
                collectablesDBEarth[1].isFound)
            {
                image(Dragon_balls_img[1],
                      290+32, 
                      40, 30,30);
            }

            if (collectablesDBNamek[2].isFound || 
                collectablesDBEarth[2].isFound)
            {
                image(Dragon_balls_img[2],
                      290+64, 
                      40, 30,30);
            }

            if (collectablesDBNamek[3].isFound || 
                collectablesDBEarth[3].isFound)
            {
                image(Dragon_balls_img[3],
                      290+96, 
                      40, 30,30);
            }

            if (collectablesDBNamek[4].isFound || 
                collectablesDBEarth[4].isFound)
            {
                image(Dragon_balls_img[4],
                      290+128, 
                      40, 30,30);
            }

            if (collectablesDBNamek[5].isFound || 
                collectablesDBEarth[5].isFound)
            {
                image(Dragon_balls_img[5],
                      290+160, 
                      40, 30,30);
            }

            if (collectablesDBNamek[6].isFound || 
                collectablesDBEarth[6].isFound)
            {
                image(Dragon_balls_img[6],
                      290+192, 
                      40, 30,30);
            }  
        }
    
        if (Shenron_sum > 0)
        {
            if (Planets[1].Earth)
            {
                for(var i = 0; i < 7; i++)
                {
                    collectablesDBEarth[i].isFound = true;
                }
            }
            
            if (Planets[0].Namek)
            {
                for(var i = 0; i < 7; i++)
                {
                    collectablesDBNamek[i].isFound = true;
                }
            }
        }
    
    for (var i = 0; i < 7; i++)
    {
        if (collectablesDBEarth[0].isFound &&
            collectablesDBEarth[1].isFound &&
            collectablesDBEarth[2].isFound &&
            collectablesDBEarth[3].isFound &&
            collectablesDBEarth[4].isFound &&
            collectablesDBEarth[5].isFound &&
            collectablesDBEarth[6].isFound || 
            collectablesDBNamek[0].isFound &&
            collectablesDBNamek[1].isFound &&
            collectablesDBNamek[2].isFound &&
            collectablesDBNamek[3].isFound &&
            collectablesDBNamek[4].isFound &&
            collectablesDBNamek[5].isFound &&
            collectablesDBNamek[6].isFound)
        {
            Shenron = true;
        }

        if (Shenron_sum > 0)
        {
            collectablesDBEarth[i].isFound = false;
            collectablesDBNamek[i].isFound = false;
            Shenron = false;
        }
    }
}

///////////////////////////////Flag pole render/////////////////////////////////
function renderFlagpole()
{
    if (Planets[0].Namek)
    {
        //Capsule corp ship
        image(capsule_corp_ship,
              510/1024*width,
              570-floorPos_y/576*height,
              300, 310);
        
        image(Frieza_ship,
              4000,
              floorPos_y-400,
              500,300);
    }
    
    if (Planets[1].Earth)
    {
        //Goku's House
        image(Gokus_house,
              250/1024*width,
              floorPos_y-270);
    }
    
    //pole
    stroke(0);
    strokeWeight(1);
    fill(200, 200, 200);
    rect(345 + flagpole.x_pos,
         100 + flagpole.y_pos, 
         5, 330,100);
    
    if (flagpole.isReached)
    {
        //Flag Pole
        stroke(0);
        strokeWeight(2);
        fill(255, 150, 0);
        rect(350 + flagpole.x_pos,
             100 + flagpole.y_pos, 
             100, 50);   
    }
    else
    { 
        //Flag Pole
        stroke(0);
        strokeWeight(2);
        fill(255, 150, 0);
        rect(350 + flagpole.x_pos,
             350 + flagpole.y_pos, 
             100, 50);
    }
}
    
function checkFlagpole()
{
    if((dist(350+flagpole.x_pos, 
             400+flagpole.y_pos,
             gameChar_world_x, 
             gameChar_y) < 40 
             && Shenron_sum > 0) ||
       (dist(350+flagpole.x_pos, 
             400+flagpole.y_pos,
             gameChar_world_x, 
             gameChar_y) < 40 && 
        Gregory_char == false))
    {
        flagpole.isReached = true;
    }
}

function checkPlayerDie()
{    
    // This is a basic respawning command, when the chararcter reaches the height limit the game character is reset.
    if (gameChar_y > height)
    {
        isPlummeting = false;
        gameChar_x = gameChar_x;
        gameChar_y = floorPos_y-150; //ATM the character will respawn above floor pos*
        lives -=1;
        
        if (Planets[0].Namek || Planets[3].Default)
        {
            platformsNamekDef.push(createPlatformsNamekDef(gameChar_world_x-50, floorPos_y -50, 100));
        }
        
        if (Planets[1].Earth)
        {
            platformsEarth.push(createPlatformsEarth(gameChar_world_x-50, floorPos_y -50, 100));
        }
        
        if (Planets[2].King_Kai_World)
        {
            platformsKKW.push(createPlatformsKKW(gameChar_world_x-50, floorPos_y -50, 100));
        }
    }
}

// Game Start Screen
function startScreen()
{  
    background(255);
    if (r2 == 1)
    {
        image(DBZ_menu_img[0],
              0+mouseX/200,
              0+mouseY/200,
              width,
              height);
        
        textSize(20);
        fill(255,240,0);
        stroke(0);
        strokeWeight(6);
        text('Tip > Your loot carries over when completing a level <',
                 90-mouseX/400,
                 275-mouseY/400);
    }
    
    else if (r2 == 2)
    {
        image(DBZ_menu_img[1],
              0+mouseX/200,
              0+mouseY/200,
              width,
              height);
        
        textSize(20);
        fill(255,240,0);
        stroke(0);
        strokeWeight(6);
        text('Tip > You can jump over enemies with good practice <',
                 90-mouseX/400,
                 270-mouseY/400);
    }
    
    else if (r2 == 3)
    {
        image(DBZ_menu_img[2],
              0+mouseX/200,
              0+mouseY/200,
              width,
              height);
        
        textSize(20);
        fill(255,240,0);
        stroke(0);
        strokeWeight(6);
        text('Tip > You can buy Health and Gems from Baba in Extras <',
                 90-mouseX/400,
                 275-mouseY/400);
    }
    
    else if (r2 == 4)
    {
        image(DBZ_menu_img[3],
              0+mouseX/200,
              0+mouseY/200,
              width,
              height);
        
        textSize(20);
        fill(255,240,0);
        stroke(0);
        strokeWeight(6);
        text('Tip > Shenrons Wishes last only for one level <',
                 90-mouseX/400,
                 275-mouseY/400);
    }
    
    else if (r2 == 5)
    {
        image(DBZ_menu_img[4],
              0+mouseX/200,
              0+mouseY/200,
              width,
              height);
        
        textSize(20);
        fill(255,240,0);
        stroke(0);
        strokeWeight(6);
        text('Tip > Unlocked Characters only last for one level <',
                 90-mouseX/400,
                 275-mouseY/400);
    }

    stroke(0);
    strokeWeight(20);
    fill(0,0,0,0);
    rect(0,0,width,height);
    
    image(DBZ_logo,
          20-mouseX/100,
          20-mouseY/100,
          width/3,
          (height/2)/3);

    textSize(30);
    fill(255,240,0);
    stroke(0);
    strokeWeight(6);
    text('PIXEL',
         75-mouseX/100,
         140-mouseY/100);

    fill(255,0,0);
    text('GAME',
         170-mouseX/100,
         140-mouseY/100);
    
    textSize(30);
    fill(255,240,0);
    ellipse(55,230,60,60);
    image(Dragon_balls_img[0],
          25, 200, 60, 60);
    text('PLAY GAME',
         90+mouseX/100,
         245+mouseY/100);

    textSize(30);
    fill(255,240,0);
    ellipse(55,330,60,60);
    image(Dragon_balls_img[1],
          25, 300, 60, 60);
    text('Difficulty',
         90+mouseX/100,
         345+mouseY/100);

    ellipse(55,430,60,60);
    image(Dragon_balls_img[2],
          25, 400, 60, 60);
    text('Planets',
         90+mouseX/100,
         445+mouseY/100);

    ellipse(55,530,60,60);
    image(Dragon_balls_img[3],
          25, 500, 60, 60);
    text('Credits',
         90+mouseX/100,
         545+mouseY/100);

    image(Radar[0],
          700-mouseX/200,
          200-mouseY/200,
          400, 450);

    fill(255,240,0);
    
    ///Main option detection
    if (dist(55,230,mouseX,mouseY) < 30)
    {
        image(Dragon_balls_img[0],
              24, 199, 62, 62);
    }

    else if (dist(55,330,mouseX,mouseY) < 30)
    {
        image(Dragon_balls_img[1],
              24, 299, 62, 62);
    }

    else if (dist(55,430,mouseX,mouseY) < 30)
    {
        image(Dragon_balls_img[2],
              24, 399, 62, 62);
    } 

    else if (dist(55,530,mouseX,mouseY) < 30)
    {
        image(Dragon_balls_img[3],
              24, 499, 62, 62);
    } 
    
//////////////////////////Play button
    if (play_Button)
    {
        GameStart = true;
    }

/////////////////////////Difficulty button
    if (difficulty_Button)
    {
        textSize(20);
        text('>   Select a Difficulty',100,370);
        
        fill(0,0,0,200);
        ellipse(width-127-mouseX/200,
                height-120-mouseY/200,
                330,330);

        fill(100,255,100);
        textSize(30);
        ellipse(540,330,60,60);
        image(Dragon_balls_img[4],
              510, 300, 60, 60);
        text('Easy',575,350);

        if (dist(540,330,mouseX,mouseY) < 30)
        {
            image(Dragon_balls_img[4],
                  509, 299, 62, 62);
            text('Easy',800,350);
            textSize(18);
            text('-Slow Enemies',740,380);
            text('-More chance of Hearts',730,410);
            text('-More chance of Items',720,440);
        }
        
        if (Difficulty[0].Dif_easy)
        {
            fill(255);
            textSize(18);
            text('Difficulty: Easy',790,500);
        }

        fill(100,100,255);
        textSize(30);
        ellipse(540,430,60,60);
        image(Dragon_balls_img[5],
              510, 400, 60, 60);
        text('Medium',575,450);

        if (dist(540,430,mouseX,mouseY) < 30)
        {
            image(Dragon_balls_img[5],
                  509, 399, 62, 62);
            text('Medium',800,350);
            textSize(18);
            text('-Fast Enemies',740,380);
            text('-less chance of Hearts',730,410);
            text('-less chance of Items',720,440);
        }
        
        if (Difficulty[1].Dif_medium)
        {
            fill(255);
            textSize(18);
            text('Difficulty: Medium',790,500);
        }

        fill(255,100,100);
        textSize(30);
        ellipse(540,530,60,60);
        image(Dragon_balls_img[6],
              510, 500, 60, 60);
        text('Hard',575,550);

        if (dist(540,530,mouseX,mouseY) < 30)
        {
            image(Dragon_balls_img[6],
                  509, 499, 62, 62);
            text('Hard',800,350);
            textSize(18);
            text('-Faster Enemies',740,380);
            text('-least chance of Hearts',730,410);
            text('-least chance of Items',720,440);
        }
        
        if (Difficulty[2].Dif_hard)
        {
            fill(255);
            textSize(18);
            text('Difficulty: Hard',790,500);
        }
    }
////////////////////////Planet Button
    if (planet_Button)
    {   
        start_Button = false;
        credit_Button = false;
        
        textSize(20);
        text('>   Select a planet',100,470);

        ////// King kai world
        
        fill(255,240,0);
        textSize(30);
        ellipse(535,330,60,60);
        image(Dragon_balls_img[4],
              505, 300, 60, 60);
        text("King Kai's",570,345);
        text("World",580,375);
            
        if (Planets[2].King_Kai_World)
        {
            textSize(25);
            image(Planet_king_kai,
                  790, 340, 210, 225);
            
            fill(255);
            strokeWeight(20);
            ellipse(width-127-mouseX/200,
                    height-120-mouseY/200, 
                    330, 330);
            
            strokeWeight(6);
            image(Menu_Selection_King_Kai_World,
                  width-292-mouseX/200,
                  height-285-mouseY/200, 
                  330, 330);
            
            fill(250,150,50);
            text("King Kai's World",740,450);
            textSize(25);
            text('SELECTED',840,500);
        }
        
        ////// namek
        
        fill(255,240,0);
        textSize(30);
        ellipse(535,430,60,60);
        image(Dragon_balls_img[5],
              505, 400, 60, 60);
        text('Namek',580,450);
        
        if (Planets[0].Namek)
        {
            textSize(30);
            image(Planet_namek,
                  800, 365, 200, 200);
            
            fill(255);
            strokeWeight(20);
            ellipse(width-127-mouseX/200,
                    height-120-mouseY/200, 
                    330,330);
            strokeWeight(6);
            image(Menu_Selection_Namek,
                  width-292-mouseX/200,
                  height-285-mouseY/200, 
                  330,330);
            
            fill(0,255,0);
            text('Namek',790,450);
            textSize(25);
            text('SELECTED',840,500);
        }

        ////// earth

        fill(255,240,0);
        textSize(30);
        ellipse(535,530,60,60);
        image(Dragon_balls_img[6],
              505, 500, 60, 60);
        text('Earth',580,550);
        
        if (Planets[1].Earth)
        {
            textSize(30);
            image(Planet_earth,
                  800, 350, 200, 215);
            
            fill(255);
            strokeWeight(20);
            ellipse(width-127-mouseX/200,
                    height-120-mouseY/200, 
                    330,330);
            strokeWeight(6);
            image(Menu_Selection_Earth,
                  width-292-mouseX/200,
                  height-285-mouseY/200,
                  330,330);
            
            fill(150,150,255);
            text('Earth',790,450);
            textSize(25);
            text('SELECTED',840,500);
        }
        
        if (dist(535,330,mouseX,mouseY) < 30 && 
            Planets[2].King_Kai_World == false)
        {
            image(Dragon_balls_img[4],
                  504, 299, 62, 62);
            image(Planet_king_kai,
                  790, 340, 210, 225);
            fill(250,150,50);
            textSize(25);
            text("King Kai's World",740,450);
            textSize(30);
        }

        else if (dist(535,430,mouseX,mouseY) < 30 &&
                 Planets[0].Namek == false)
        {
            image(Dragon_balls_img[5],
                  504, 399, 62, 62);
            image(Planet_namek,
                  800, 365, 200, 200);
            fill(0,255,0);
            text('Namek',790,450);
        }

        else if (dist(535,530,mouseX,mouseY) < 30 && 
                 Planets[1].Earth == false)
        {
            image(Dragon_balls_img[6],
                  504, 499, 62, 62);
            image(Planet_earth,
                  800, 350, 200, 215);
            fill(150,150,255);
            text('Earth',790,450);
        } 
    }

///////////////////////Credits button
    if (credit_Button || 
        Namek_Complete && 
        Earth_Complete && 
        King_Kai_World_Complete)
    {
        fill(0);
        rect(0,0,width,height);
        if (r1 == 1)
        {
            image(Credit_Background[0],
                  0,50,
                  width,
                  height-100);
        }

        else if (r1 == 2)
        {
            image(Credit_Background[1],0,50,
                  width,
                  height-100);
        }

        else if (r1 == 3)
        {
            image(Credit_Background[2],
                  0,50,
                  width,
                  height-100);
        }

        else if (r1 == 4)
        {
            image(Credit_Background[3],
                  0,50,
                  width,
                  height-100);
        }

        else if (r1 == 5)
        {
            image(Credit_Background[4],
                  0,50,
                  width,
                  height-100);
        } 
        
        fill(255,200,0);
        textSize(40);
        text("Thanks For playing",
             300-mouseX/100,
             270-mouseY/100);
        image(DBZ_logo,
              300-mouseX/100,
              300-mouseY/100,
              470,100);
        
        fill(255,240,0);
        text('PIXEL',
             370-mouseX/100,
             425-mouseY/100);

        fill(255,0,0);
        text('GAME',
             500-mouseX/100,
             425-mouseY/100); 
        
        textSize(18);
        fill(255);
        text('Created & Programmed By Roberto Valentin Bliaja',
             400-mouseX/100,
             525-mouseY/100); 
        
        image(Goku_Nimbus,
          10-mouseX/50,
          400-mouseY/50,
          180,180);
    
        fill(255,255,255);
        textSize(20);
        text("Back", 50, 550); 
        ellipse(147,535,70,70);
        image(Dragon_balls_img[0],
              112, 500, 70, 70);
        
        if (dist(147,535,mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[0],
                  111, 499, 72, 72);
        }
        
        if (Namek_Complete &&
            Earth_Complete &&
            King_Kai_World_Complete && 
            dist(147,535,mouseX,mouseY) < 35)
        {
            Namek_Complete = false;
            Earth_Complete = false;
            King_Kai_World_Complete = false;
        }
    }
}

/////////////////////////////////Game counters/////////////////////////////
function gameCounters()
{
    strokeWeight(3);
    stroke(255);
    fill(0,0,0,100);
//    rect(280,-10,350,120,10);
    
    textSize(18);
    stroke(0);
    strokeWeight(3);
    
    // This is the Lives counter
    fill(100,255,0);
    text("Health: "+ " > "+ 
         lives +
         " < ", 150, 120);
    
    // This is the Game Score Counter
    fill(255,250,100);
    text("Energy: "+" > "+ 
         game_score +
         " < ", 150, 100);
}

//////////////////////////////User Interface Tokens/////////////////////////
function userInterfacetokens()
{
    // UI tokens
    stroke(0);
    strokeWeight(5);
    fill(255,200,0);
    textSize(18);
    
    if (Pause_Menu == false)
    {
        text("Press 1 for menu",
            320+mouseX/200,
            120+mouseY/200);
    
        text("Objective",
            550+mouseX/200,
            30+mouseY/200);

        //Objectives on screen
        if(Planets[0].Namek || Planets[3].Default)
        {
            if (Shenron)
            {
                text("> Click on Shenrons Tips to make a wish <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
            
            else if (Shenron_sum > 0)
            {
                text("> Explore or head back to the flagpole <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
            
            else
            {
                text("> Find The Namekian Dragon Balls <",
                    550+mouseX/200,
                    50+mouseY/200);
            }  
        }

        if(Planets[1].Earth)
        {
            
            if (Shenron)
            {
                text("> Click on Shenron Tips to make a wish <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
            
            else if (Shenron_sum > 0)
            {
                text("> Explore or head back to the flagpole <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
            
            else
            {
                text("> Find Earths Dragon Balls <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
        }

        if(Planets[2].King_Kai_World)
        {  
            if (Gregory_char == false)
            {
                text("> Explore or head back to the flagpole <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
            
            else
            {
                text("> Find & Catch Gregory <",
                    550+mouseX/200,
                    50+mouseY/200);
            }
        }
    }
    
    //Health bar
    fill(0,0,0,0);
    strokeWeight(1);
    rect(285, 5, 240, 30,5);
    
    for (var i = 0; i < lives; i++)
    {   
        //Life tokens
        if (lives > 4)
        {
            fill(0-i*lives, 
                 255+i*lives, 
                 0-i*lives); // green
        }
        
        else if (lives > 3)
        {
            fill(255+i*lives,
                 255+i*lives,
                 0-i*lives); // yellow
        }
        
        else if (lives > 2)
        {
            fill(255+i*lives, 
                 100+i*lives, 
                 0-i*lives); // orange
        }
                
        else if (lives >= 1)
        {
            fill(255+i*lives, 
                 0-i*lives,
                 0-i*lives); // red
        }
        noStroke(0);
        rect(290+i*45, 10, 50, 20);
        strokeWeight(1);    
    }
}

////////////////////////////////Character Display//////////////////////////
function charType()
{
    image(Radar[0],5,5,140,163);

    var x= 43;
    var y= 93;
    
    strokeWeight(3);
    if (game_characters[0].Goku)
    {
        image(Goku_rad_img,
              16.5 ,38 ,115, 115);
        image(Goku_Portrait,
              188 ,25 ,83, 42);
        textSize(20);
        stroke(0);
        strokeWeight(5);
        fill(255,100,0);
        text("Goku", 195, 20); 
    }
    
    else if (game_characters[1].Krillin)
    {
        image(Krillin_rad_img,
              16.5 ,38 ,115, 115);
        image(Krillin_Portrait,
              188 ,25 ,83, 42);
        textSize(20);
        stroke(0);
        strokeWeight(5);
        fill(255,100,0);
        text("Krillin", 187, 20); 
    }
    
    else if (game_characters[2].Majin_Buu)
    {
        image(Majin_Buu_rad_img,
              16.5 ,38 ,115, 115);
        image(Majin_Buu_Portrait,
              188 ,25 ,83, 42);
        textSize(15);
        stroke(0);
        strokeWeight(5);
        fill(255,100,255);
        text("Majin Buu", 187, 20); 
    }
    
    else if (game_characters[3].Vegeta)
    {
        image(Vegeta_rad_img,
              16.5 ,38 ,115, 115);
        image(Vegeta_Portrait,
              188 ,25 ,83, 42);
        textSize(18);
        stroke(0);
        strokeWeight(5);
        fill(255,10,25);
        text("Vegeta", 195, 20); 
    }
    
    else if (game_characters[4].Android_18)
    {
        image(Android_18_rad_img,
              16.5 ,38 ,115, 115);
        image(Android_18_Portrait,
              188 ,25 ,83, 42);
        textSize(15);
        stroke(0);
        strokeWeight(5);
        fill(100,100,255);
        text("Android 18", 190, 20); 
    }
    
    else if (game_characters[5].Piccolo)
    {
        image(Piccolo_rad_img,
              16.5 ,38 ,115, 115);
        image(Piccolo_Portrait,
              188 ,25 ,83, 42);
        textSize(15);
        stroke(0);
        strokeWeight(5);
        fill(100,255,100);
        text("Piccolo", 190, 20); 
    }
    
    else if (game_characters[6].Gohan)
    {   
        image(Gohan_rad_img,
              16.5 ,38 ,115, 115);
        image(Gohan_Portrait,
              188 ,25 ,83, 42);
        textSize(19);
        stroke(0);
        strokeWeight(5);
        fill(200,100,200);
        text("Gohan", 195, 20); 
    }
    
    else if (game_characters[7].Gotenks)
    {   
        image(Gotenks_rad_img,
              16.5 ,38 ,115, 115);
        image(Gotenks_Portrait,
              188 ,25 ,83, 42);
        textSize(18);
        stroke(0);
        strokeWeight(5);
        fill(200,100,255);
        text("Gotenks", 190, 20); 
    }
    
    else if (game_characters[8].Beerus)
    {   
        image(Beerus_rad_img,
              16.5 ,38 ,115, 115);
        image(Beerus_Portrait,
              188 ,20 ,65, 55);
        textSize(18);
        stroke(0);
        strokeWeight(5);
        fill(200,100,255);
        text("Beerus", 190, 20); 
    }
    
    else if (game_characters[9].Master_Roshi)
    {   
        image(Master_Roshi_rad_img,
              16.5 ,38 ,115, 115);
        image(Master_Roshi_Portrait,
              188 ,20 ,65, 55);
        textSize(18);
        stroke(0);
        strokeWeight(5);
        fill(200,100,255);
        text("Master Roshi", 140, 20); 
    }
    
    else if (game_characters[10].Hercule)
    {   
        image(Hercule_rad_img,
              16.5 ,38 ,115, 115);
        image(Hercule_Portrait,
              188 ,20 ,65, 55);
        textSize(18);
        stroke(0);
        strokeWeight(5);
        fill(200,100,255);
        text("Mr.Satan", 180, 20); 
    }
    else
    {
        scale(1.7);
        strokeWeight(1);
        noStroke(0);

        fill(255, 150, 100);
        rect(x-12, y-30, 25, 20);

        fill(0, 0, 255);
        triangle(x-12,
                 y-27,
                 x, 
                 y-15,
                 x+13,
                 y-27);

        fill(255, 249, 204);
        stroke(0);
        ellipse(x+0.5, y-45, 45, 45);

        stroke(0);
        line(x-5, y-35, x+5, y-35);

        fill(0);
        rect(x-13,
             y-50, 5, 10);

        rect(x+8,
             y-50, 5, 10);

        fill(0);
        stroke(0);
        ellipse(x+7,
                y-17, 4, 4);

        fill(0, 0, 255);
        noStroke();
        rect(x-12,
             y-13, 25, 2);

        stroke(255, 255, 255);
        strokeWeight(3);
        point(x+7,y-17);

        strokeWeight(1);
        noStroke();

        fill(255, 249, 204);
        stroke(0);
        ellipse(x-20,
                y-15, 5, 5);

        fill(255, 249, 204);
        stroke(0);
        ellipse(x+20,
                y-15, 5, 5);
        scale(0.58);
    }
    
    stroke(0);
    strokeWeight(3);
    fill(0,0,0,10);
    ellipse(75.5,97,115,115);
    
    textSize(18);
    stroke(0);
    strokeWeight(5);
    fill(255,100,0);
    text("P 1", 5, 20); 
}

/////////////////////////////////////Platforms////////////////////////////////
function createPlatformsNamekDef(x, y, length)
{
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function()
        {
            if (Planets[3].Default)
            {
                strokeWeight(1);
                stroke(0);
                fill(255);
                ellipse(this.x,
                        this.y-10,
                        this.length/4,
                        this.length/4);
                
                ellipse(this.x+this.length/5,
                        this.y,
                        this.length/4,
                        this.length/4);
                
                ellipse(this.x+this.length/5*2,
                        this.y-10,
                        this.length/4,
                        this.length/4);
                
                ellipse(this.x+this.length/5*3,
                        this.y,
                        this.length/4,
                        this.length/4);
                
                ellipse(this.x+this.length/5*4,
                        this.y-10,
                        this.length/4,
                        this.length/4);
                
                ellipse(this.x+this.length/5*5,
                        this.y,
                        this.length/4,
                        this.length/4);
            }
            
            else
            {
                fill(255,0,255);
                image(Cloud_small_img,
                      this.x,
                      this.y-25,
                      this.length, 
                      50);
            }
        },
        
        checkContactNamekDef: function(gc_x, gc_y)
        {
            if(gc_x > this.x && 
               gc_x < this.x + this.length)
            {
                var d = this.y - gc_y;
                if (d >= 0 && d < 5) 
                {
                    return true;
                }
            }
            return false;
        }
    }
    return p;
}

function createPlatformsEarth(x, y, length)
{
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function()
        {
            fill(255,0,255);
            image(Cloud_small_img,
                  this.x, 
                  this.y-25,
                  this.length,
                  50)
        },
        
        checkContactEarth: function(gc_x, gc_y)
        {
            if(gc_x > this.x &&
               gc_x < this.x + this.length)
            {
                var d = this.y - gc_y;
                if (d >= 0 && d < 5) 
                {
                    return true;
                }
            }
            return false;
        }
    }
    return p;
}

function createPlatformsKKW(x, y, length)
{
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function()
        {
            fill(255,0,255);
            image(Cloud_medium_yellow_img,
                  this.x, 
                  this.y-25, 
                  this.length,
                  50);
        },
        
        checkContactKKW: function(gc_x, gc_y)
        {
            if(gc_x > this.x &&
               gc_x < this.x + this.length)
            {
                var d = this.y - gc_y;
                if (d >= 0 && d < 5) 
                {
                    return true;
                }
            }
            return false;
        }
    }
    return p;
}

/////////////////////////////////////Enemies////////////////////////////////
function Enemy(x, y, range)
{
    this.x = x;
    this.y = y;
    this.range = random(300,900);   
    this.currentX = x;
    this.currentY = y;
    this.inc = 1;
    
    this.update = function()
    {
        this.currentX+= this.inc;
        
        if(this.currentX >= this.x + this.range)
        {
            if (Difficulty[0].Dif_easy)
            {
                this.inc = -0.5;
            }
            
            if (Difficulty[1].Dif_medium)
            {
                this.inc = -0.8;
            }
            
            if (Difficulty[2].Dif_hard)
            {
                this.inc = -1;
            }
        }
        
        else if(this.currentX < this.x)
        {
            if (Difficulty[0].Dif_easy)
            {
                this.inc = 0.5;
            }
            
            if (Difficulty[1].Dif_medium)
            {
                this.inc = 0.8;
            }
            
            if (Difficulty[2].Dif_hard)
            {
                this.inc = 1;
            }
        }
    }
    
    this.drawDodoria = function()
    {
        this.update();
        fill(255,0,0);
        
        if (enemies[0])
        {
            if (this.inc == -0.5 ||
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Dodoria[0],
                      this.currentX-25, 
                      this.y-100 ,110,120);
            }
            else
            {
                image(Dodoria[1],
                      this.currentX-25, 
                      this.y-100 ,110,120);
            }
        } 
    }
    
    this.drawZarbon = function()
    { 
        this.update();
        if (enemies[1])
        {
            if (this.inc == -0.5 || 
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Zarbon[0],
                      this.currentX-25, 
                      this.y-100 ,110,120);
            }
            else
            {
                image(Zarbon[1],
                      this.currentX-25, 
                      this.y-100 ,110,120);
            }
        }  
    }
    
    this.drawFrieza = function()
    { 
        this.update();
        if (enemies[2])
        {
            if (this.inc == -0.5 || 
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Frieza[0],
                      this.currentX-25,
                      this.y-100 ,75,110);
            }
            else
            {
                image(Frieza[1],
                      this.currentX-25,
                      this.y-100 ,75,105);
            }
        }  
    }
    
    this.drawGinyu = function()
    { 
        this.update();
        if (enemies[3])
        {
            if (this.inc == -0.5 || 
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Ginyu[0],
                      this.currentX-25,
                      this.y-100 ,80,110);
            }
            else
            {
                image(Ginyu[1],
                      this.currentX-25, 
                      this.y-100 ,80,110);
            }
        }  
    }
    
    this.drawGregory = function()
    { 
        this.update();
        if (enemies[4])
        {
            if (this.inc == -0.5 ||
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Gregory,
                      this.currentX-25,
                      this.y-100 ,40,55);
            }
            else
            {
                image(Gregory,
                      this.currentX-25, 
                      this.y-100 ,40,55);
            }
        }  
    }
    
    this.drawCell = function()
    { 
        this.update();
        if (enemies[5])
        {
            if (this.inc == -0.5 || 
                this.inc == -0.8 || 
                this.inc == -1)
            {
                image(Cell[0],
                      this.currentX-25, 
                      this.y-100 ,80,120);
            }
            else
            {
                image(Cell[1],
                      this.currentX-25, 
                      this.y-100 ,80,120);
            }
        }  
    }
    
    this.drawSuperBuu = function()
    { 
        this.update();
        if (enemies[6])
        {
            if (this.inc == -0.5 ||
                this.inc == -0.8 ||
                this.inc == -1)
            {
                image(Super_Buu[0],
                      this.currentX-25,
                      this.y-100 ,80,120);
            }
            else
            {
                image(Super_Buu[1],
                      this.currentX-25,
                      this.y-100 ,80,120);
            }
        }  
    }
    
    this.checkContact = function(gc_x, gc_y)
    {
        var d = dist(gc_x, gc_y,
                     this.currentX,
                     this.y)
        
        if(d < 20)
        {
            return true;
        }
        
        return false;
    }
}

//////////////////////////////////////////Background/////////////////////////////////////
function backGround()
{
    if (Planets[0].Namek)
    {
        background(Background[1]); // fill the sky namek
    }

    if (Planets[1].Earth)
    {
        background(Background[0]); // fill the sky earth
    }

    if (Planets[2].King_Kai_World)
    {
        background(Background[2]); // fill the sky purple ??
    }

    if (Planets[3].Default)
    {
        background(0,200,255); // fill the sky blue 
    }
}

function BackgroundScenery()
{
    noStroke();
    strokeWeight(3);
    for (var i = 0; i < 3; i++)
    {
        if (Planets[1].Earth)
        {
            fill(0, 155, 0);
            rect(0, floorPos_y, width, height / 4); // draw some green ground

            image(Planet_Earth_Background,width*[i],
                  floorPos_y-130,
                  width,
                  height/4);
        }

        if (Planets[2].King_Kai_World)
        {
            fill(0, 155, 0);
            rect(0, floorPos_y, width, height / 4); // draw some green ground

            image(Planet_King_Kai_Background,width*[i],
                  floorPos_y-130,
                  width,
                  height/4);
        }

        if (Planets[0].Namek)
        {
            fill(0, 130, 255);
            rect(0, floorPos_y, width, height / 4); // draw some green ground

            image(Planet_Namek_Background,width*[i],
                  floorPos_y-140,
                  width,
                  height/4);
        }

        if (Planets[3].Default)
        {
            fill(0, 155, 0);
            rect(0, floorPos_y, width, height / 4); // draw some green ground

            image(Planet_Earth_Background,width*[i],
                  floorPos_y-143,
                  width,
                  height/4);
        }
    }
}

///////////////////////////////////////////Loading Screen///////////////////////////////
function loadingScreen()
{
    fill(25);
    rect(0,0,width,height);
    
    image(DBZ_logo,5,height/10,1010,250);

    textSize(60);
    fill(255,240,0);
    stroke(0);
    strokeWeight(18);
    text('PIXEL',250,350);

    fill(255,0,0);
    text('GAME',470,350);
    
    fill(255);
    strokeWeight(6);
    rect(150,450,680,50,10);
    
    fill(0,255,0);
    noStroke();
    
    // Loading Code -- just for presentation
    if(loading == false)
    {
        for (var i = 0; i < frameCount*3; i++)
        {
            if (i == 674)
            {
                loading = true;
            }
            
            else
            {   
                fill(0,255,0);
                rect(153,453,i,44);
                
                textSize(30);
                stroke(0);
                strokeWeight(2);
                fill(255);
                var percentage;
                percentage = (i/674)*100;
            }
        } 
        
        for (var i = 0; i < frameCount/20; i++)
        {
            image(Fusion[i],500,400,100,50);
        }
        
        text("Loading . . . "+ 
             round(percentage) + 
             "%",153,440);
    }
}

function Mouse_Cursor()
{    
    image(Mouse_cursor,
          mouseX,
          mouseY,
          45,
          57);
}

function drawFont()
{
    if (r1 == 1)
    {
        textFont('Bowlby One SC Regular');
    }
    
    else if (r1 == 2)
    {
        textFont('Fugaz One');
    }
    
    else if (r1 == 3)
    {
        textFont('Kalam');
    }
    
    else if (r1 == 4)
    {
        textFont('Orbitron');
    }
    
    else if (r1 == 5)
    {
        textFont('Bungee Inline');
    }
}

function Shenron_Mods()
{
    if (lives_Wish &&
        lives < 5)
    {
        lives +=1;
    }
    
    else if (money_Wish)
    {
        Zeni_coins_counter +=1;
    }
}

/////////////////////////////////////////Pause Menu/////////////////////////////////
function PauseMenu()
{
    if (Pause_Menu)
    {
        fill(0,0,0,100);
        stroke(0);
        strokeWeight(5);
        rect(0,0,width+12,height+8);

        if (dist(335,45,mouseX,mouseY) < 35)
        {
            image(Characters_Menu_img,
                  355,2,678,700);
        }

        else if (dist(365,145,mouseX,mouseY) < 35)
        {
            image(Items_Menu_img,
                  355,2,width,585);
        }

        else if (dist(415,245,mouseX,mouseY) < 35)
        {
            image(Controls_Menu_img,
                  5,2,width+5,height+8);
        }

        else if (dist(485,345,mouseX,mouseY) < 35)
        {
            image(Extras_Menu_img,
                  5 ,2 ,width+5, height+8);
        }

        image(Side_Border_01,
              3-mouseX/200,
              2-mouseY/200,
              width+5,
              height+8);
        image(Pause_Menu_DB,
              80-mouseX/50,
              80-mouseY/50,
              100,
              100);
        image(Pause_Menu_DB,
              400-mouseX/50,
              400-mouseY/50,
              120,
              120);
        
        textSize(35);
        fill(255,200,0);
        text("Pause Menu",25,50);

        if (r3 == 0)
        {
           image(Goku_Menu_01,
                 3+mouseX/50,
                 87+mouseY/50,
                 410,
                 494); 
        }

        else if (r3 == 1)
        {
           image(Goku_Menu_02,
                 3+mouseX/50,
                 95+mouseY/50,
                 402,
                 486); 
        }

        else if (r3 == 2)
        {
           image(Goku_Menu_03,
                 3+mouseX/50,
                 90+mouseY/50,
                 489,
                 491); 
        }

        fill(255,200,0);
        ellipse(335,45,70,70);
        image(Dragon_balls_img[0],
              300,10,70,70);
        
        text("Characters",380,60);

        ellipse(365,145,70,70);
        image(Dragon_balls_img[1],
              330,110,70,70);
        
        text("Items",410,160);

        ellipse(415,245,70,70);
        image(Dragon_balls_img[2],
              380,210,70,70);
        
        text("Controls",460,260);

        ellipse(485,345,70,70);
        image(Dragon_balls_img[3],
              450,310,70,70);
        
        text("Extras",530,360);

        ellipse(605,445,70,70);
        image(Dragon_balls_img[4],
              570,410,70,70);
        
        text("Exit Menu",650,460);

        if (dist(335,45, mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[0],
                  299, 9, 72, 72);
            r3 = 0;
        }

        else if (dist(365,145, mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[1],
                  329, 109, 72, 72);
            r3 = 1;
        }

        else if (dist(415,245,mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[2],
                  379, 209, 72, 72);
            r3 = 2;
        }

        else if (dist(485,345,mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[3],
                  449, 309, 72, 72);
            r3 = 0;
        }

        else if (dist(605,445,mouseX,mouseY) < 35)
        {
            image(Dragon_balls_img[4],
                  569, 409, 72, 72);
            r3 = 1;
        }

        fill(0,0,0,0);
        rect(0,0,width+12,height+6);
    }
}

/////////////////////////////////Character menu//////////////////////////////
function charMenu() 
{
    fill(255);
    stroke(0);
    strokeWeight(5);
    
    image(Characters_Menu_img,
          0+(mouseX/20),
          -50+(mouseY/50));
    fill(0,0,0,100);
    rect(0,0,width+12,height+8);
        
    image(Side_Border_01,
          -10-mouseX/200,
          -10-mouseY/200,
          450,height+50);
    image(Side_Border_02,
          606-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    
    fill(255,255,255);
    textSize(20);
    text("Zeni: "+Zeni_coins_counter,10,25);
    text("Gems: "+Gem_counter,10,45);
    text("Energy: "+game_score,10,65);
    
    image(Goku_Nimbus,
          10-mouseX/50,
          400-mouseY/50,
          180,180);
    
    fill(255,255,255);
    textSize(20);
    text("Back", 50, 550); 
    ellipse(147,535,70,70);
    image(Dragon_balls_img[0],
          112, 500, 70, 70);
    
    if (dist(147,535,mouseX,mouseY) < 35)
    {
        image(Dragon_balls_img[0],
              111, 499, 72, 72);
    }
    
    fill(255,150,0);
    textSize(30);
    text("Characters",720, 50); 
    
    for (var i = 0; i < 4; i++)
    {
        
        image(Char_Border,
              83+i*200,
              100,
              148,
              148);  
        image(Char_Border,
              150+i*200,
              300,
              148,
              148); 
        
        fill(0,0,0,0);
        stroke(255);
        strokeWeight(10);
        ellipse(157+i*200,174,148,148);
        
        stroke(0);
        strokeWeight(3);
        ellipse(157+i*200,174,116,116);
        
        stroke(255);
        strokeWeight(10);
        ellipse(224+i*200,374,148,148);
        
        stroke(0);
        strokeWeight(3);
        ellipse(224+i*200,374,116,116);
    }
    
    if (game_characters[0].Goku)
    {
        image(Char_flames,
              80, 96,155,155);
    }
    else if (game_characters[1].Krillin)
    {
        image(Char_flames,
              280, 96,155,155);
    }
    else if (game_characters[2].Majin_Buu)
    {
        image(Char_flames,
              480, 96,155,155);
    }
    else if (game_characters[3].Vegeta)
    {
        image(Char_flames,
              680, 96,155,155);
    }
    else if (game_characters[4].Android_18)
    {
        image(Char_flames,
              145,296,155,155);
    }
    else if (game_characters[5].Piccolo)
    {
        image(Char_flames,
              345,296,155,155);
    }
    else if (game_characters[6].Gohan)
    {
        image(Char_flames,
              545,296,155,155);
    }
    else if (game_characters[7].Gotenks)
    {
        image(Char_flames,
              745,296,155,155);
    }
    
    fill(255);
    textSize(30);
    stroke(0);
    strokeWeight(5);
    
    //Goku
    image(Goku_token,
          100, 116, 115, 115);
    
    fill(255,100,0);
    textSize(20);
    text("Goku", 200, 135); 
    
    if((dist(157, 174,mouseX, mouseY)) < 80 && 
        charM == true)
    {
        if (game_characters[0].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 10", 110, 250); 
            fill(0,200,255);
            text("Gems: 2", 110, 270); 
        }
    }
    
    if (game_characters[0].Unlocked)
    {
        text("Unlocked", 110, 250); 
    }
    
    //Krillin
    image(Krillin_token,
          300,116, 115 , 115);
    
    fill(255,100,0);
    textSize(20);
    text("Krillin", 380, 135); 
    
    //Krillin token
    if((dist(357, 174,mouseX, mouseY)) < 80 && 
       charM == true)
    {     
        if (game_characters[1].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 10", 310, 250); 
            fill(0,200,255);
            text("Gems: 1", 310, 270); 
        }
    }
    
    if (game_characters[1].Unlocked)
    {
        text("Unlocked", 310, 250); 
    }
    
    //Majin Buu
    image(Majin_Buu_token,
          500,116, 115 , 115);
    
    fill(220,100,255);
    textSize(20);
    text("Majin Buu", 540, 135); 
    
    //Majin Buu token
    if((dist(557, 174,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[2].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 30", 510, 250); 
            fill(0,200,255);
            text("Gems: 3", 510, 270); 
        }
    }
    
    if (game_characters[2].Unlocked)
    {
        text("Unlocked", 510, 250); 
    }
    
    //Vegeta
    image(Vegeta_token,
          700,116, 115 , 115);
    
    fill(255,50,25);
    textSize(20);
    text("Vegeta", 780, 135); 
    
    //Vegeta token
    if((dist(757, 174,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[3].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 15", 710, 250); 
            fill(0,200,255);
            text("Gems: 3", 710, 270); 
        }
    }
    
    if (game_characters[3].Unlocked)
    {
        text("Unlocked", 710, 250); 
    }
    
    //Android 18
    image(Android_18_token,
          165,316, 115 , 115);
    
    fill(100,100,255);
    textSize(20);
    text("Android 18", 165, 320); 
    
    //Android 18 token 
    if((dist(224, 374,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[4].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 18", 170, 450); 
            fill(0,200,255);
            text("Gems: 1", 170, 470); 
        }
    }
    
    if (game_characters[4].Unlocked)
    {
        text("Unlocked", 170, 450); 
    }
    
    //Piccolo
    image(Piccolo_token,
          365,316, 115 , 115);
    
    fill(100,255,100);
    textSize(20);
    text("Piccolo", 375, 320); 
    
    
    //Piccolo token
    if((dist(424, 374,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[5].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 12", 370, 450); 
            fill(0,200,255);
            text("Gems: 2", 370, 470); 
        }
    }
    
    if (game_characters[5].Unlocked)
    {
        text("Unlocked", 370, 450); 
    }
    
    //Gohan
    image(Gohan_token,
          565,316, 115 , 115);
    
    fill(200,100,200);
    textSize(20);
    text("Gohan", 585, 320); 
    
    //Gohan token
    if((dist(624, 374,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[6].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 10", 570, 450); 
            fill(0,200,255);
            text("Gems: 2", 570, 470); 
        }
    }
    
    if (game_characters[6].Unlocked)
    {
        text("Unlocked", 570, 450); 
    }
    
    //Gotenks
    image(Gotenks_token,
          765,316, 115 , 115);
    
    fill(255,255,0);
    textSize(19);
    text("Gotenks", 775, 320); 
    
    //Gotenks token
    if((dist(824, 374,mouseX, mouseY)) < 80 && 
       charM == true)
    {   
        if (game_characters[7].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Coins: 20", 770, 450); 
            fill(0,200,255);
            text("Gems: 2", 770, 470); 
        }
    }
    
    if (game_characters[7].Unlocked)
    {
        text("Unlocked", 770, 450); 
    }

    for (var i = 0; i < 3; i++)
    {
        image(Char_Border,
              266+i*200,
              455,
              100,
              100);  

        fill(0,0,0,0);
        stroke(255);
        strokeWeight(10);
        ellipse(317+i*200,504,100,100);

        stroke(0);
        strokeWeight(3);
        ellipse(317+i*200,504,90,90);
    }
    
    if (game_characters[10].Unlocked)
    {
        text("Unlocked", 680,544); 
    }
    
    if (game_characters[8].Beerus)
    {
        image(Char_flames,
              263, 452, 105, 105);
    }
    else if (game_characters[9].Master_Roshi)
    {
        image(Char_flames,
              463, 452, 105, 105);
    }
    else if (game_characters[10].Hercule)
    {
        image(Char_flames,
              663, 452, 105, 105);
    }

    //Beerus
    image(Beerus_token,
          276, 465, 80 , 80);
    
    fill(255,255,0);
    textSize(19);
    text("Beerus", 280,564); 
    
    //Beerus token
    if((dist(317,504,mouseX, mouseY)) < 55 && 
       charM == true)
    {   
        if (game_characters[8].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Energy: >1000<", 280,544); 
        }
    }
    
    if (game_characters[8].Unlocked)
    {
        text("Unlocked", 280,544); 
    }
    
    //Master Roshi
    image(Master_Roshi_token,
          476, 465, 80 , 80);
    
    fill(255,255,0);
    textSize(19);
    text("Master Roshi", 480,564); 
    
    //Master Roshi token
    if((dist(517,504,mouseX, mouseY)) < 55 && 
       charM == true)
    {   
        if (game_characters[9].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Energy: >500<", 480,544); 
        }
    }
    
    if (game_characters[9].Unlocked)
    {
        text("Unlocked", 480,544); 
    }   
    
    //Hercule
    image(Hercule_token,
          676, 465, 80 , 80);
    
    fill(255,255,0);
    textSize(19);
    text("Hercule", 680,564); 
    
    //Hercule token
    if((dist(717,504,mouseX, mouseY)) < 55 && 
       charM == true)
    {   
        if (game_characters[10].Unlocked == false)
        {
            textSize(15);
            fill(255,200,0);
            text("Energy: >200<", 680,544); 
        }
    }
    
    if (game_characters[10].Unlocked)
    {
        text("Unlocked", 680,544); 
    } 
}

///////////////////////////////////Item Menu//////////////////////////////
function lootMenu()
{   
    fill(255);
    stroke(0);
    strokeWeight(5);
    
    image(Items_Menu_img,0+(mouseX/20),
          -50+(mouseY/50),
          width+150,height+100);
    
    fill(0,0,0,100);
    rect(0,0,width+12,height+8);
        
    image(Side_Border_01,
          -10-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    image(Side_Border_02,
          606-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    
    image(Goku_Nimbus,
          10-mouseX/50,
          400-mouseY/50,
          180,180);
    
    fill(255,255,255);
    textSize(20);
    text("Back", 50, 550); 
    ellipse(147,535,70,70);
    image(Dragon_balls_img[0],
          112, 500, 70, 70);
    
    if (dist(147,535,mouseX,mouseY) < 35)
    {
        image(Dragon_balls_img[0],
              111, 499, 72, 72);
    }
    
    fill(255,150,0);
    textSize(30);
    text("Items",720, 50); 
    
    stroke(0);
    strokeWeight(5);
    fill(255,210,0);
    image(Zeni_coins_img[0],
          100, 10 ,45, 45);
    text("Zeni: "+ Zeni_coins_counter,155,45);
    
    fill(100,200,255);
    image(Gem_img[0],100,55 ,45, 40);
    text("Gems: "+ Gem_counter,155,85);
    
    fill(255,50,255);
    image(DBZ_symbol_img,105,100,45,40);
    text("Energy: "+ game_score, 160,130); 
    
    // This is the DragonBall counter
    fill(255,150,0);
    image(DBZ_symbol_img,105,150,45,40);
    text("Dragon Balls: "+
         Dragon_ball_Counter + 
         "/7", 170,180); 
    
    fill(255,0,0);
    image(Red_chest,110,200 ,45, 45);
    text("R Chests: "+ 
         Red_chest_counter +
         "/" + 
         collectableChestRed.length,180,235);
    
    fill(0,0,255);
    image(Blue_chest,120,250 ,45, 45);
    text("B Chests: "+ 
         Blue_chest_counter +
         "/" + 
         collectableChestBlue.length,190,285);
    
    fill(255,255,0);
    image(Yellow_chest,130,295 ,45, 45);
    text("Y Chests: "+ 
         Yellow_chest_counter +
         "/" + 
         collectableChestYellow.length,200,330);
    
    fill(255,255,0);
    textSize(30);
    text("Special Character Tokens: ", 245, 400); 
    
    strokeWeight(2);
    
    //Beerus
    image(Beerus_Portrait,
          250, 410, 100, 85);
    
    fill(255,255,0);
    textSize(19);
    text("Beerus", 250, 510); 
    
    textSize(15);
    fill(255,255,0);
    text(Beerus_Tokens + "/3", 350, 420); 
    text(">1000<", 250, 525);
    
    //Master Roshi
    image(Master_Roshi_Portrait,
          375, 410, 100, 85);
    
    fill(255,255,0);
    textSize(17);
    text("Msr Roshi", 380, 510); 
    
    textSize(15);
    fill(255,255,0);
    text(Master_Roshi_Tokens + "/3", 475, 420); 
    text(">500<", 380, 525);
  
    //Hercule
    image(Hercule_Portrait,
          500, 410, 100, 85);
    
    fill(255,255,0);
    textSize(19);
    text("Mr.Satan", 500, 510); 
    
    textSize(15);
    fill(255,255,0);
    text(Hercule_Tokens + "/3", 600, 420); 
    text(">200<", 500, 525);
}

///////////////////////////////////////Controls Menu///////////////////////////////////
function ControlsMenu()
{
    fill(255);
    stroke(0);
    strokeWeight(5);
    
    image(Controls_Menu_img,
          -250+(mouseX/20),
          -50+(mouseY/50),
          width+150,
          height+100);
    
    fill(0,0,0,100);
    rect(0,0,width+12,height+8);
        
    image(Side_Border_01,
          -10-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    
    image(Side_Border_02,
          606-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    
    image(Goku_Nimbus,
          10-mouseX/50,
          400-mouseY/50,
          180,180);
    
    fill(255,255,255);
    textSize(20);
    text("Back", 50, 550); 
    ellipse(147,535,70,70);
    image(Dragon_balls_img[0],
          112, 500, 70, 70);
    
    if (dist(147,535,mouseX,mouseY) < 35)
    {
        image(Dragon_balls_img[0],
              111, 499, 72, 72);
    }
    
    fill(255,150,0);
    textSize(30);
    text("Controls",720, 50); 
    
    image(Keyboard,
          290, 385, 612, 196);
    
    text("Move left",190,50);
    image(Left_arrow_Key,
          250, 55, 50, 50);
    
    text("Move right",420,50);
    image(Right_arrow_Key,
          490, 55, 50, 50);
    
    text("Click / Interact",190,150);
    image(Left_click,
          270, 160, 100, 100);
    
    text("Jump",590,150);
    image(Space_Key,
          500, 160, 280, 50);
    
    text("Pause Menu",220,320);
    image(Pause_Key,
          290, 330, 50, 50);
}

//////////////////////////////////////////Extras Menu/////////////////////////////////
function ExtrasMenu()
{
    fill(255);
    stroke(0);
    strokeWeight(5);
    
    image(Extras_Menu_01_img,50+(mouseX/20),
          -30+(mouseY/50),
          width-150,height+100);
    fill(0,0,0,100);
    rect(0,0,width+12,height+8);
        
    image(Side_Border_01,
          -10-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    image(Side_Border_02,
          606-mouseX/200,
          -10-mouseY/200,
          450,
          height+50);
    
    fill(255,255,255);
    textSize(20);
    text("Zeni: "+Zeni_coins_counter,250,425);
    text("Gems: "+Gem_counter,260,445);
    text("Energy: "+game_score,270,465);
    
    image(Goku_Nimbus,
          10-mouseX/50,
          400-mouseY/50,
          180,
          180);
    
    fill(255,255,255);
    textSize(20);
    text("Back", 50, 550); 
    ellipse(147,535,70,70);
    image(Dragon_balls_img[0],
          112, 500, 70, 70);
    
    if (dist(147,535,mouseX,mouseY) < 35)
    {
        image(Dragon_balls_img[0],
              111, 499, 72, 72);
    }
    
    fill(255,150,0);
    textSize(30);
    text("Extras",720, 50); 
    
    noStroke();
    fill(255,255,255);
    ellipse(150,100,150,150);
    
    if (dist(150,100,mouseX,mouseY) < 80)
    {
        image(Hearts_img[0],
              89+mouseX/200,
              44+mouseY/200,
              122,
              122); 
    }
        
    else
    {
        image(Hearts_img[0],
              90+mouseX/200,
              45+mouseY/200,
              120,
              120); 
    }
    
    textSize(50);
    fill(0);
    text(lives,132,118);
    textSize(30);
    fill(255,200,0);
    text("Add Lives - 100 Zeni",230,118);
    text("5 lives Max",230,148);
    
    fill(255,255,255);
    ellipse(200,265,150,150);
    
    if (dist(200,265,mouseX,mouseY) < 80)
    {
        image(Gem_img[0],
              134+mouseX/200,
              209+mouseY/200,
              132,
              122);
    }
        
    else
    {
        image(Gem_img[0],
              135+mouseX/200,
              210+mouseY/200,
              130,
              120);
    }
    
    textSize(50);
    fill(0);
    text(Gem_counter,182,280);
    textSize(30);
    fill(255,200,0);
    text("Add Gems - 50 Zeni",280,280);
}

//////////////////////////////////Level Complete///////////////////////////////////////
function LEVEL_COMPLETE()
{
    // This is the level complete screen
    fill(0,200,255,100);
    image(Level_Complete,
          0, 0, width+15, height+10);

    stroke(0);
    strokeWeight(5);
    fill(255,255,255);
    textSize(52/576*height);
    text("Level Complete",
         30, 380);

    textSize(32/576*height);
    text("Press Enter To Continue",
         30, 420);
    
    DBZ_game_Menu_song.stop();
    DBZ_game_Kai_song.stop();
    DBZ_game_Earth_song.stop();
    DBZ_game_Namek_song.stop();
    DBZ_game_Extra_song.stop();
    
    if (Planets[0].Namek && 
        flagpole.isReached)
    {
        Namek_Complete = true;
    }
    
    else if (Planets[1].Earth &&
             flagpole.isReached)
    {
        Earth_Complete = true;
    }
    
    else if (Planets[2].King_Kai_World &&
             flagpole.isReached)
    {
        King_Kai_World_Complete = true;
    }
}

function checkLEVEL_COMPLETE()
{
    fill(0,0,0,100);
    stroke(0);
    strokeWeight(5);
    rect(0,0,width+14,height+8); 

    fill(255,200,0);
    textSize(30);
    text("Continue? Y/N",450,300);

    if (LC == false)
    {
        if (keyCode == 121)
        {
            LC = true;
            Level_Complete_song.play();
        }
    }

    if (keyCode == 110)
    {
        flagpole.isReached = false;
        gameChar_x = gameChar_world_x - 500;
    }
}

//////////////////////////////////Game Over///////////////////////////////////////
function GAME_OVER()
{
    // This is the game over screen
    fill(255,0,0,100);
    image(Game_Over,
          0, 0, width+15, height+10);

    stroke(0);
    strokeWeight(5);
    fill(255,255,255);
    textSize(52/576*height);
    text("Mission Failed",
         300, 500);

    textSize(32/576*height);
    text("Press Enter To Continue",
         290, 540);
    
    DBZ_game_Menu_song.stop();
    DBZ_game_Kai_song.stop();
    DBZ_game_Earth_song.stop();
    DBZ_game_Namek_song.stop();
    DBZ_game_Extra_song.stop();
}

function checkGAME_OVER()
{
    fill(0,0,0,100);
    stroke(0);
    strokeWeight(5);
    rect(0,0,width+14,height+8); 

    fill(255,200,0);
    textSize(20);
    text("Your Zeni: "+
         Zeni_coins_counter,
         gameChar_x-100,
         gameChar_y-200);
    
    text("Revive Cost 50 Zeni",
         gameChar_x-100,
         gameChar_y-150);
    
    text("Revive? Y / N",
         gameChar_x-100,
         gameChar_y-100);

    if (GO == false)
    {
        if (keyCode == 110)
        {
            GO = true;
            Game_Over_song.play();
        } 
    }

    if (Zeni_coins_counter >= 50)
    {
        if (keyCode == 121 &&
            Zeni_coins_counter >= 50)
        {
            isDead = false;
            Zeni_coins_counter -= 50
            lives = 1;
        }
    }
}

/////////////////////////////////////////Carry over Data/////////////////////////////
function CarryOverData()
{
    if (flagpole.isReached)
    {
        CarryZeni = Zeni_coins_counter;
        CarryEnergy = game_score;
        CarryGems = Gem_counter;
    }
}

/////////////////////////////////////////////////Tips Screen///////////////////////////////////////////////
function Tips_Screen()
{
    fill(255,255,255,100);
    ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);
    
    if (Planets[0].Namek)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,120);
            
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,120);

            fill(255);
            text("Dr. Brief",50,480);
            text("Welcome to Namek, Player",50,515);
            text("Collect those Dragon balls!",50,540);
            text("This Planet is Dangerous stay safe!",580,525);
        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(DR_Brief_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);  

        text("---TIPS---",465,537); 
        
        for (var i = 0; i < collectablesDBNamek.length; i++)
        {
            if (collectablesDBNamek[i].isFound)
            {
                if(dist(width/2,
                        width/2,
                        mouseX,
                        mouseX) < 90 &&
                dist(510/576*height,
                     510/576*height,
                     mouseY,
                     mouseY) < 90)
                {
                    image(Dialogue_box_right,
                          width/2,
                          floorPos_y+20,
                          500,
                          120);
                    image(Dialogue_box_left,
                          20/1024*width,
                          floorPos_y+20,
                          500,120);

                    fill(255);
                    text("Dende",50,480);
                    text("You've found " + 
                         Dragon_ball_Counter + 
                         " Dragon balls!", 50, 515);
                    text("Check if there are any left!",50,540);
                    text("Watch out for the Frieza Force!",580,525);
                }

                ellipse(width/2,
                510/576*height,
                115/1024*width,
                115/576*height);

                image(Dende_Radar_img,
                454/1024*width,
                450/576*height,
                115/1024*width,
                115/576*height);  
                
                text("---TIPS---",465,537);
            }
        }
    }
    
    else if (Planets[1].Earth)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,120) ;

            fill(255);
            text("Dr. Brief",50,480);
            text("Welcome to Earth",50,515);
            text("Find them Dragon balls, will ya!",50,540);
            text("Safe? well I'm not sure here!",580,525);
        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(DR_Brief_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);  

        text("---TIPS---",465,537);
    }
    
    else if (Planets[2].King_Kai_World)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500, 
                  120);

            fill(255);
            text("King Kai",50,480);
            text("Welcome to My Planet",50,515);
            text("I'm King Kai! Catch Gregory",50,540);
            text("Remember Gravity is 10x of Earth!",580,525);
        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(King_Kai_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);  

        text("---TIPS---",465,537); 
    }
    
    else if (Planets[3].Default)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120) ;

            fill(255);
            text("Dr. Brief",50,480);
            text("The First iteration of the game",50,515);
            text("Go out and find the Dragon balls!",50,540);
            text("Becarful though, Danger lurks!",580,525);
        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(DR_Brief_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);  

        text("---TIPS---",465,537);
    }
    
    if (game_characters[0].Goku)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Goku",50,480);
            text("Yo,My Name's Goku,I'm from Earth",50,515);
            text("I'm Super strong!",50,540);
            text("I can jump very high!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Goku_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);  
        
        text("---TIPS---",465,537);
    } 
    
    if (game_characters[1].Krillin)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Krillin",50,480);
            text("I'll help in the fight",50,515);
            text("I'm the strongest human on Earth!",50,540);
            text("I can jump, high just like Goku!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Krillin_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",465,537);
    } 
    
    if (game_characters[2].Majin_Buu)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Majin Buu",50,480);
            text("You Need BUU ?!, You Help Buu find candies",50,515);
            text("Ha ha ha!!",50,540);
            text("Help Buu find Candies!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Majin_Buu_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height); 
        
        text("---TIPS---",465,537);
        
        if (Candy_rush)
        {
            text("TIME LEFT:",25,200);
            Time_score -=1;
            text(Time_score,25,225); 
        }
        
        if (Time_score == 0)
        {
            Candy_rush = false;
        }
        
        if (Candy_rush == false)
        {
            text("TIME:",25,200);
            text("Expired",25,225);
            
            game_characters[2].Majin_Buu = false;
            game_characters[2].Unlocked = false;
        }
    } 

    if (game_characters[3].Vegeta)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Vegeta",50,480);
            text("Finally, You are strong enough",50,515);
            text("to get my help,who needs kakarot!",50,540);
            text("I can jump just as high as him!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Vegeta_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",465,537);
    }
        
    if (Zeni_coins_counter < 10 && Zeni_coins_counter != 0)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Bulma",50,480);
            text("Hey, I'm Bulma",50,515);
            text("You found some Zeni Coins, cool!",50,540);
            text("Use them to unlock characters!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Bulma_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",465,537);
    }
    
    else if (Zeni_coins_counter >= 30 && 
             Zeni_coins_counter < 40)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Bulma",50,480);
            text("Wow",50,515);
            text("Your collecting a lot of coins!",50,540);
            text("You really want them characters!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Bulma_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",465,537);
    }
    
    else if (Zeni_coins_counter >= 70 && 
             Zeni_coins_counter < 100)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Bulma",50,480);
            text("oh my",50,515);
            text("Are you trying to impress me ?",50,540);
            text("Dont forget to use those coins!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Bulma_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",465,537);
    }
    
    else if (Zeni_coins_counter >= 100 &&
             Zeni_coins_counter < 110)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Bulma",50,480);
            text("hmm, Thats 1,2 woah",50,515);
            text(",Thats impressive!",50,540);
            text("Keep on collecting!",590,525); 

        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Bulma_Radar_img,
            454/1024*width,
            450/576*height,
            115/1024*width,
            115/576*height);   
        
        text("---TIPS---",462,537);
    }
    
    if (Shenron)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
          dist(510/576*height,
               510/576*height,
               mouseY,
               mouseY) < 90)
        {
            image(Dialogue_box_right,
                  width/2,
                  floorPos_y+20,
                  500,
                  120);
            image(Dialogue_box_left,
                  20/1024*width,
                  floorPos_y+20,
                  500,
                  120);

            fill(255);
            text("Shenron",50,480);
            text("I am the mighty SHENRON",50,515);
            text("YOU HAVE SUMMONED ME MORTAL",50,540);
            text("MAKE YOUR WISH",590,525); 
        }

        ellipse(width/2,
            510/576*height,
            115/1024*width,
            115/576*height);

        image(Shenron_button_img,
            454/1024*width,
            454/576*height,
            115/1024*width,
            115/576*height);   

        text("---TIPS---",465,537);

        image(Shenron_img,0,0,300,300);

        if (Wishes)
        {
            fill(50);
            stroke(0);
            strokeWeight(5);
            rect(0, 0,width+12, height+5);
            textSize(18);

            image(Shenron_wishes,
                  125,
                  5,
                  915/1.2,
                  749/1.2);

            image(Speech_bubble01,
                  600, 10, 200, 200);

            fill(0,200,0);
            text("Make your wish",615,100);

            textSize(15);
            fill(255,0,100);
            text("Unlock All Characters",55,530);
            text("Jump Higher",230,470);
            text("Regenerate Health",520,420);
            text("Regenerate Zeni",750,480);

            if (dist(312,520,mouseX,mouseY)< 40) // Unlock all characters
            {
                image(Dragon_balls_img[4],
                      312-45, 520-45, 90, 90);
            }

            if (dist(390,475,mouseX,mouseY)< 40) //Jump Higher
            {
                image(Dragon_balls_img[6],
                      390-45, 475-45, 90, 90);
            }

            if (dist(488,451,mouseX,mouseY)< 40) //Regen Health
            {
                image(Dragon_balls_img[2],
                      488-45, 451-45, 90, 90);
            }

            if (dist(697,475,mouseX,mouseY)< 40) // Regen money
            {
                image(Dragon_balls_img[5],
                      697-45, 475-45, 90, 90);
            }
        }
    }
}

//////////////////////////////mouse click interations////////////////////////
function mousePressed()
{
    if (GameStart == false)
    {
        /////////////////////Play Button/////////////////////////////////////////
        if (dist(55,230,mouseX,mouseY) < 30 &&
           credit_Button == false)
        {
            play_Button = true;   
            clickSound.play();
        }

        /////////////////////Buttons//////////////////////////////////////////

        ////////////////////////Difficulty Button//////////////////////////////////
        if (dist(55,330,mouseX,mouseY) < 30 &&
            credit_Button == false)
        {
            difficulty_Button = true;
            planet_Button = false;
            credit_Button = false;   
            clickSound.play();
        }

        if (difficulty_Button)
        {
            if (dist(540,330,mouseX,mouseY) < 30)
            {
                Difficulty[0].Dif_easy = true;
                Difficulty[1].Dif_medium = false;
                Difficulty[2].Dif_hard = false;
                clickSound.play();
            }

            if (dist(540,430,mouseX,mouseY) < 30)
            {
                Difficulty[0].Dif_easy = false;
                Difficulty[1].Dif_medium = true;
                Difficulty[2].Dif_hard = false;
                clickSound.play();
            }

            if (dist(540,530,mouseX,mouseY) < 30)
            {
                Difficulty[0].Dif_easy = false;
                Difficulty[1].Dif_medium = false;
                Difficulty[2].Dif_hard = true;
                clickSound.play();
            }
        }

        ////////////////////Planet Button////////////////////////////////////////
        if (dist(55,430,mouseX,mouseY) < 30 &&
            credit_Button == false)
        {
            planet_Button = true;
            difficulty_Button = false;
            credit_Button = false;
            clickSound.play();
        }

        if (planet_Button)
        {
            if (dist(535,330,mouseX,mouseY) < 30)
            {
                Planets[0].Namek = false;
                Planets[1].Earth = false;
                Planets[2].King_Kai_World = true;
                Planets[3].Default = false;
                clickSound.play();
            }

            if (dist(535,430,mouseX,mouseY) < 30)
            {
                Planets[0].Namek = true;
                Planets[1].Earth = false;
                Planets[2].King_Kai_World = false;
                Planets[3].Default = false;
                clickSound.play();
            }

            if (dist(535,530,mouseX,mouseY) < 30)
            {
                Planets[0].Namek = false;
                Planets[1].Earth = true;
                Planets[2].King_Kai_World = false;
                Planets[3].Default = false;
                clickSound.play();
            }
        }
        ////////////////////Credit Button////////////////////////////////////////
        if (dist(55,530,mouseX,mouseY) < 30)
        {
            credit_Button = true;
            difficulty_Button = false;
            planet_Button = false;
            clickSound.play();
        }
        
        if(credit_Button)
        {
            if (dist(147,535,mouseX,mouseY) < 35)
            {
                credit_Button = false;
                clickSound.play();
            }
        }
    }
    //////////////////////Pause menu
    if (GameStart == true && Pause_Menu == true)
    {
        if (dist(335,45,mouseX,mouseY) < 35)
        {
            Pause_Menu = false;
            charM = true;
            lootM = false;
            controlsM = false;
            extrasM = false;
            exitM = false;
            clickSound.play();
        }

        if (dist(365,145,mouseX,mouseY) < 35)
        {
            Pause_Menu = false;
            charM = false;
            lootM = true;
            controlsM = false;
            extrasM = false;
            exitM = false;
            clickSound.play();
        }

        if (dist(415,245,mouseX,mouseY) < 35)
        {
            Pause_Menu = false;
            charM = false;
            lootM = false;
            controlsM = true;
            extrasM = false;
            exitM = false;
            clickSound.play();
        }

        if (dist(485,345,mouseX,mouseY) < 35)
        {   
            Pause_Menu = false;
            charM = false;
            lootM = false;
            controlsM = false;
            extrasM = true;
            exitM = false;
            clickSound.play();
        }

        if (dist(605,445,mouseX,mouseY) < 35)
        {
            Pause_Menu = false;
            charM = false;
            lootM = false;
            controlsM = false;
            extrasM = false;
            exitM = true;
            clickSound.play();
        }
    }
    
    if(dist(147,535,mouseX,mouseY) < 35 && 
        charM ||
        dist(147,535,mouseX,mouseY) < 35 && 
        lootM ||
        dist(147,535,mouseX,mouseY) < 35 && 
        controlsM ||
        dist(147,535,mouseX,mouseY) < 35 &&
        extrasM)
    {
        Pause_Menu = true;
        charM = false;
        lootM = false;
        controlsM = false;
        extrasM = false;
        exitM = false;
        clickSound.play();
    }
    
    /////////////////////////////////Character Tokens///////////////////////// 
    if (GameStart)
    {
        //Goku token
        if((dist(157, 174,mouseX, mouseY)) < 80 && 
           charM == true)
        {
            if (game_characters[0].Unlocked)
            {
               game_characters[0].Goku = true;
               game_characters[1].Krillin = false;
               game_characters[2].Majin_Buu = false;
               game_characters[3].Vegeta = false; 
               game_characters[4].Android_18 = false;
               game_characters[5].Piccolo = false;
               game_characters[6].Gohan = false;
               game_characters[7].Gotenks = false;
               game_characters[8].Beerus = false;
               game_characters[9].Master_Roshi = false;
               game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 10 && 
                     Gem_counter >= 2 && 
                     game_characters[0].Unlocked == false)
            {
                Zeni_coins_counter -=10;
                Gem_counter -= 2;
                game_characters[0].Unlocked = true;
            }
            clickSound.play();
        }

        //Krillin token
        if((dist(357, 174,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[1].Unlocked)
            {
                game_characters[1].Krillin = true;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[3].Vegeta = false;
                game_characters[4].Android_18 = false;
                game_characters[5].Piccolo = false;
                game_characters[6].Gohan = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 10 && 
                     Gem_counter >= 1 && 
                     game_characters[1].Unlocked == false)
            {
                Zeni_coins_counter -=10;
                Gem_counter -= 1;
                game_characters[1].Unlocked = true;
            }
            clickSound.play();
        }

        //Majin Buu token
        if((dist(557, 174,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[2].Unlocked)
            {
                game_characters[2].Majin_Buu = true;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[3].Vegeta = false;
                game_characters[4].Android_18 = false;
                game_characters[5].Piccolo = false;
                game_characters[6].Gohan = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;

                Candy_rush = true;
            }

            else if (Zeni_coins_counter >= 30 && 
                     Gem_counter >= 3 && 
                     game_characters[2].Unlocked == false)
            {
                Zeni_coins_counter -=30;
                Gem_counter -= 3;
                game_characters[2].Unlocked = true;
            }
            clickSound.play();
        }

        //Vegeta token
        if((dist(757, 174,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[3].Unlocked)
            {
                game_characters[3].Vegeta = true;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[4].Android_18 = false;
                game_characters[5].Piccolo = false;
                game_characters[6].Gohan = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 15 && 
                     Gem_counter >= 3 && 
                     game_characters[3].Unlocked == false)
            {
                Zeni_coins_counter -=15;
                Gem_counter -= 3;
                game_characters[3].Unlocked = true;
            }
            clickSound.play();
        }

        //Android 18 token
        if((dist(224, 374,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[4].Unlocked)
            {
                game_characters[4].Android_18 = true;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[5].Piccolo = false;
                game_characters[6].Gohan = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 18 && 
                     Gem_counter >= 1 && 
                     game_characters[4].Unlocked == false)
            {
                Zeni_coins_counter -=15;
                Gem_counter -= 3;
                game_characters[4].Unlocked = true;
            }
            clickSound.play();
        }

        //Piccolo token
        if((dist(424, 374,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[5].Unlocked)
            {
                game_characters[5].Piccolo = true;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[6].Gohan = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 12 && 
                     Gem_counter >= 2 && 
                     game_characters[5].Unlocked == false)
            {
                Zeni_coins_counter -=12;
                Gem_counter -= 2;
                game_characters[5].Unlocked = true;
            }
            clickSound.play();
        }

        //Gohan token
        if((dist(624, 374,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[6].Unlocked)
            {
                game_characters[6].Gohan = true;
                game_characters[5].Piccolo = false;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[7].Gotenks = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 10 && 
                     Gem_counter >= 2 && 
                     game_characters[6].Unlocked == false)
            {
                Zeni_coins_counter -=10;
                Gem_counter -= 2;
                game_characters[6].Unlocked = true;
            }
            clickSound.play();
        }

        //Gotenks token
        if((dist(824, 374,mouseX, mouseY)) < 80 && 
           charM == true)
        {   
            if (game_characters[7].Unlocked)
            {
                game_characters[7].Gotenks = true;
                game_characters[6].Gohan = false;
                game_characters[5].Piccolo = false;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[8].Beerus = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (Zeni_coins_counter >= 20 && 
                     Gem_counter >= 2 && 
                     game_characters[7].Unlocked == false)
            {
                Zeni_coins_counter -=20;
                Gem_counter -= 2;
                game_characters[7].Unlocked = true;
            }
            clickSound.play();
        }

        //Beerus token
        if((dist(317,504,mouseX, mouseY)) < 55 && 
            charM == true)
        {   
            if (game_characters[8].Unlocked)
            {
                game_characters[8].Beerus = true;
                game_characters[7].Gotenks = false;
                game_characters[6].Gohan = false;
                game_characters[5].Piccolo = false;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[9].Master_Roshi = false;
                game_characters[10].Hercule = false;
            }

            else if (game_score >= 1000 && 
                     Beerus_Tokens == 3 &&
                     game_characters[8].Unlocked == false)
            {
                game_score -=1000;
                game_characters[8].Unlocked = true;
            }
            clickSound.play();
        }

        //Master Roshi token
        if((dist(517,504,mouseX, mouseY)) < 55 && 
            charM == true)
        {   
            if (game_characters[9].Unlocked)
            {
                game_characters[9].Master_Roshi = true;
                game_characters[8].Beerus = false;
                game_characters[7].Gotenks = false;
                game_characters[6].Gohan = false;
                game_characters[5].Piccolo = false;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
                game_characters[10].Hercule = false;
            }

            else if (game_score >= 500 && 
                     Master_Roshi_Tokens == 3 &&
                     game_characters[9].Unlocked == false)
            {
                game_score -=500;
                game_characters[9].Unlocked = true;
            }
            clickSound.play();
        }

        //Hercule token
        if((dist(717,504,mouseX, mouseY)) < 55 && 
            charM == true)
        {   
            if (game_characters[10].Unlocked)
            {
                game_characters[10].Hercule = true;
                game_characters[9].Master_Roshi = false;
                game_characters[8].Beerus = false;
                game_characters[7].Gotenks = false;
                game_characters[6].Gohan = false;
                game_characters[5].Piccolo = false;
                game_characters[4].Android_18 = false;
                game_characters[3].Vegeta = false;
                game_characters[1].Krillin = false;
                game_characters[0].Goku = false;
                game_characters[2].Majin_Buu = false;
            }

            else if (game_score >= 200 && 
                     Hercule_Tokens == 3 &&
                     game_characters[10].Unlocked == false)
            {
                game_score -=200;
                game_characters[10].Unlocked = true;
            }
            clickSound.play();
        }
    /////////////////////Extras menu//////////////////////
        if (dist(150,100,mouseX,mouseY) < 80 
            && extrasM)
        {
            if (lives < 5 && Zeni_coins_counter >= 100)
            {
                lives += 1;
                Zeni_coins_counter -=100;
            }
            clickSound.play();
        }
        
        if (dist(200,265,mouseX,mouseY) < 80
           && extrasM && Zeni_coins_counter >= 50)
        {
            Gem_counter += 1;
            Zeni_coins_counter -=50;
            clickSound.play();
        }
    }
    
    ////////////////////Shenron Wishes
    if (Shenron)
    {
        if(dist(width/2,
                width/2,
                mouseX,
                mouseX) < 90 &&
        dist(510/576*height,
             510/576*height,
             mouseY,
             mouseY) < 90)
        {
            Wishes = true;
        }

        if (Wishes)
        {
            if (dist(312,520,mouseX,mouseY) < 40) // Unlock all characters
            {
                game_characters[10].Unlocked = true;
                game_characters[9].Unlocked = true;
                game_characters[8].Unlocked = true;
                game_characters[7].Unlocked = true;
                game_characters[6].Unlocked = true;
                game_characters[5].Unlocked = true;
                game_characters[4].Unlocked = true;
                game_characters[3].Unlocked = true;
                game_characters[2].Unlocked = true;
                game_characters[1].Unlocked = true;
                game_characters[0].Unlocked = true;
                Shenron_sum = Shenron_sum + 1;
                Wishes = false;
                Shenron = false;
                clickSound.play();
            }

            else if (dist(390,475,mouseX,mouseY) < 40) //Jump Higher
            {
                Shenron_sum = Shenron_sum + 1;
                jump_Wish = true;
                Wishes = false;
                Shenron = false;
                clickSound.play();
            }

            else if (dist(488,451,mouseX,mouseY) < 40) //Regen Health
            {
                Shenron_sum = Shenron_sum + 1;
                lives_Wish = true
                Wishes = false;
                Shenron = false;
                clickSound.play();
            }

            else if (dist(697,475,mouseX,mouseY) < 40) // Regen money
            {
                Shenron_sum = Shenron_sum + 1;
                money_Wish = true;
                Wishes = false;
                Shenron = false;  
                clickSound.play();
            } 
        }  
    }
}

//////////////////////////////Start Game / Setup//////////////////////////////
function startGame() 
{
    gameChar_x = width/2;
    gameChar_y = floorPos_y;
    
    game_score = CarryEnergy;
    Dragon_ball_Counter = 0;
    Zeni_coins_counter = CarryZeni;
    Gem_counter = CarryGems;
    Red_chest_counter = 0;
    Blue_chest_counter = 0;
    Yellow_chest_counter = 0;
    
    // Variable to control the background scrolling.
    scrollPos = 0;
    scrollPos_y = 0;

    // Variable to store the real position of the gameChar in the game
    // world. Needed for collision detection.
    gameChar_world_x = gameChar_x - scrollPos;
    
    //Mouse cursor set to nothing
    noCursor();

    // Boolean variables to control the movement of the game character.
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    
    wasLeft = false;
    wasRight = true; 

    // Initialise arrays of scenery objects.
    //Trees Array//    
    trees_x = [150 + random(500),
               250 + random(500),
               550 + random(500), 
               650 + random(500),
               950 + random(500), 
               1150 + random(500), 
               1250 + random(500), 
               1350 + random(500), 
               1450 + random(500), 
               1750 + random(500), 
               1850 + random(500), 
               1950 + random(500), 
               2150 + random(500), 
               2250 + random(500), 
               2350 + random(500), 
               2550 + random(500), 
               2650 + random(500),
               2750 + random(500),
               2950 + random(500),
               3050 + random(500),
               3150 + random(500), 
               3250 + random(500), 
               3350 + random(500), 
               3450 + random(500), 
               3750 + random(500), 
               3850 + random(500), 
               3950 + random(500), 
               4150 + random(500),
               4250 + random(500), 
               4350 + random(500), 
               4450 + random(500), 
               4750 + random(500), 
               4850 + random(500), 
               4950 + random(500), 
               5150 + random(500),
              //Negative//
              -150 + random(-500), 
              -250 + random(-500),
              -550 + random(-500),
              -650 + random(-500), 
              -950 + random(-500), 
              -1150 + random(-500), 
              -1250 + random(-500),
              -1350 + random(-500), 
              -1450 + random(-500), 
              -1750 + random(-500),
              -1850 + random(-500),
              -1950 + random(-500),
              -2150 + random(-500), 
              -2250 + random(-500), 
              -2350 + random(-500),
              -2550 + random(-500), 
              -2650 + random(-500),
              -2750 + random(-500),
              -2950 + random(-500),
              -3050 + random(-500),
              -3150 + random(-500), 
              -3250 + random(-500),
              -3350 + random(-500), 
              -3450 + random(-500), 
              -3750 + random(-500),
              -3850 + random(-500),
              -3950 + random(-500),
              -4150 + random(-500),
              -4250 + random(-500), 
              -4350 + random(-500), 
              -4450 + random(-500), 
              -4750 + random(-500), 
              -4850 + random(-500), 
              -4950 + random(-500), 
              -5150 + random(-500)];
         
    trees_y = [100];
    
    tree_y = height/2;
    
    Ground_length = [10];
    
    //Cloud Array//
    clouds = [
         {cloud_X_pos:150 + random(500), cloud_Y_pos:50/576 * height, cloud_size:10}, 
         {cloud_X_pos:850 + random(500), cloud_Y_pos:30, cloud_size:20},
         {cloud_X_pos:1150 + random(500), cloud_Y_pos:0, cloud_size:0},
         {cloud_X_pos:1850 + random(500), cloud_Y_pos:10, cloud_size:5},
         {cloud_X_pos:2150 + random(500), cloud_Y_pos:20, cloud_size:15},
         {cloud_X_pos:2850 + random(500), cloud_Y_pos:30, cloud_size:15},
         {cloud_X_pos:3150 + random(500), cloud_Y_pos:0, cloud_size:15},
         {cloud_X_pos:3850 + random(500), cloud_Y_pos:10, cloud_size:15},
         {cloud_X_pos:4150 + random(500), cloud_Y_pos:20, cloud_size:15},
         {cloud_X_pos:4850 + random(500), cloud_Y_pos:30, cloud_size:15},
         //Negative off Screen//
         {cloud_X_pos:-150 + random(-500), cloud_Y_pos:50, cloud_size:10}, 
         {cloud_X_pos:-850 + random(-500), cloud_Y_pos:30, cloud_size:20},
         {cloud_X_pos:-1150 + random(-500), cloud_Y_pos:0, cloud_size:0},
         {cloud_X_pos:-1850 + random(-500), cloud_Y_pos:10, cloud_size:5},
         {cloud_X_pos:-2150 + random(-500), cloud_Y_pos:20, cloud_size:15},
         {cloud_X_pos:-2850 + random(500), cloud_Y_pos:30, cloud_size:15},
         {cloud_X_pos:-3150 + random(500), cloud_Y_pos:0, cloud_size:15},
         {cloud_X_pos:-3850 + random(500), cloud_Y_pos:10, cloud_size:15},
         {cloud_X_pos:-4150 + random(500), cloud_Y_pos:20, cloud_size:15},
         {cloud_X_pos:-4850 + random(500), cloud_Y_pos:30, cloud_size:15}];

    //Mountains Array//
    mountains = [
         {mountain_x_pos:200, mountain_y_pos:0, mountain_height:400},
         {mountain_x_pos:400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:1000, mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:1600, mountain_y_pos:0, mountain_height:200},     
         {mountain_x_pos:2000, mountain_y_pos:0, mountain_height:150},
         {mountain_x_pos:2200, mountain_y_pos:0, mountain_height:150},
         {mountain_x_pos:2400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:2600, mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:3000, mountain_y_pos:0, mountain_height:200}, 
         {mountain_x_pos:3200, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:3400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:3600, mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:4000, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:4200, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:4400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:4600, mountain_y_pos:0, mountain_height:100},
         //Negative off Screen//
         {mountain_x_pos:-200 , mountain_y_pos:0, mountain_height:300},
         {mountain_x_pos:-400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:-1000, mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:-1600, mountain_y_pos:0, mountain_height:200},     
         {mountain_x_pos:-2000, mountain_y_pos:0, mountain_height:150},
         {mountain_x_pos:-2200 , mountain_y_pos:0, mountain_height:150},
         {mountain_x_pos:-2400 , mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:-2600 , mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:-3000 , mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:-3200, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:-3400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:-3600, mountain_y_pos:0, mountain_height:100},
         {mountain_x_pos:-4000, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:-4200, mountain_y_pos:0, mountain_height:200},
         {mountain_x_pos:-4400, mountain_y_pos:0, mountain_height:100}, 
         {mountain_x_pos:-4600, mountain_y_pos:0, mountain_height:100}];

    //Canyons Array, position and width can be controlled//
    canyons = [
           {x_pos:1200 + random(100), width:80},
           {x_pos:1600 + random(100), width:70},
           {x_pos:2800 + random(100), width:90},
           {x_pos:3500 + random(100), width:90},
           {x_pos:3800 + random(100), width:90},
           //Negative off Screen//
           {x_pos:-300 + random(-200), width:100},
           {x_pos:-1200 + random(-200), width:80},
           {x_pos:-1600 + random(-200), width:70},
           {x_pos:-2800 + random(-200), width:90},
           {x_pos:-3500 + random(-200), width:90},
           {x_pos:-3800 + random(-200), width:90}];
    
    //Platforms
    platformsNamekDef = [];
    
    //Namek and Default
    //Dodoria plat
    platformsNamekDef.push(createPlatformsNamekDef(2000, floorPos_y -100, 100));
    platformsNamekDef.push(createPlatformsNamekDef(2150, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(2300, floorPos_y -180, 100));
    platformsNamekDef.push(createPlatformsNamekDef(2450, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(2600, floorPos_y -100, 100));
    
    //Zarbon plat
    platformsNamekDef.push(createPlatformsNamekDef(-2000, floorPos_y -100, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-2150, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-2300, floorPos_y -180, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-2450, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-2600, floorPos_y -100, 100));
    
    //Frieza
    platformsNamekDef.push(createPlatformsNamekDef(3800, floorPos_y -100, 100));
    platformsNamekDef.push(createPlatformsNamekDef(4000, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(3900, floorPos_y -180, 100));
    platformsNamekDef.push(createPlatformsNamekDef(3800, floorPos_y -220, 100));
    
    platformsNamekDef.push(createPlatformsNamekDef(4600, floorPos_y -100, 100));
    platformsNamekDef.push(createPlatformsNamekDef(4400, floorPos_y -140, 100));
    platformsNamekDef.push(createPlatformsNamekDef(4500, floorPos_y -180, 100));
    platformsNamekDef.push(createPlatformsNamekDef(4600, floorPos_y -220, 100));
    
    //Ginyu
    platformsNamekDef.push(createPlatformsNamekDef(-3800, floorPos_y -100, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-4000, floorPos_y -150, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-3900, floorPos_y -160, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-3800, floorPos_y -200, 100));
    
    platformsNamekDef.push(createPlatformsNamekDef(-4600, floorPos_y -200, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-4400, floorPos_y -160, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-4500, floorPos_y -150, 100));
    platformsNamekDef.push(createPlatformsNamekDef(-4600, floorPos_y -250, 100));
    
    platformsEarth = [];
    //Earth
    //Positive
    platformsEarth.push(createPlatformsEarth(1000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(1100, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(1200, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(1500, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(1600, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(1900, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(2000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(2200, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(2300, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(2600, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(2700, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(3000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(3100, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(3200, floorPos_y -100, 100));
    //Negative
    platformsEarth.push(createPlatformsEarth(-1000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-1100, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-1200, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-1500, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-1600, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-1900, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-2000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-2200, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-2300, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-2600, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-2700, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-3000, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-3100, floorPos_y -100, 100));
    platformsEarth.push(createPlatformsEarth(-3200, floorPos_y -100, 100));
    
    platformsKKW = [];
    //Earth
    //Positive
    platformsKKW.push(createPlatformsKKW(1000, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(1100, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(1200, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(1500, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(1600, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(1900, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(2000, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(2200, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(2300, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(2600, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(2700, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(3000, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(3100, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(3200, floorPos_y -75, 100));
    //Negative
    platformsKKW.push(createPlatformsKKW(-1000, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-1100, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-1200, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-1500, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-1600, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-1900, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-2000, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-2200, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-2300, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-2600, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-2700, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-3000, floorPos_y -75, 100));
    platformsKKW.push(createPlatformsKKW(-3100, floorPos_y -50, 100));
    platformsKKW.push(createPlatformsKKW(-3200, floorPos_y -75, 100));
    
    //Enemies
    enemies =[];
    enemies.push(new Enemy(2000, floorPos_y -10,100));
    enemies.push(new Enemy(-2500, floorPos_y -10,100));
    enemies.push(new Enemy(4000, floorPos_y -10,100));
    enemies.push(new Enemy(-4500, floorPos_y -10,100));
    enemies.push(new Enemy(random(-4000,4000), floorPos_y -100,100));
    enemies.push(new Enemy(random(1000,4000), floorPos_y -100,100));
    enemies.push(new Enemy(random(-4000,-1000), floorPos_y -100,100));

    //Collectables Array, x,y position and sizes// 
    //Main collectable//
    collectablesDBNamek = [
        //Zarbon
        {DB_num:1, x_pos: -2225, y_pos: 400, size: 50, isFound: false}, 
        //Dodoria
        {DB_num:2, x_pos: 2350, y_pos: 400, size: 50, isFound: false}, 
        //Ginyu
        {DB_num:3, x_pos: -4000, y_pos: 400, size: 50, isFound: false}, 
        //Dodoria
        {DB_num:4, x_pos: 2425, y_pos: 400, size: 50, isFound: false}, 
        //Frieza
        {DB_num:5, x_pos: 3950, y_pos: 240, size: 50, isFound: false}, 
        //Zarbon
        {DB_num:6, x_pos: -2425, y_pos: 400, size: 50, isFound: false}, 
        //Frieza
        {DB_num:7, x_pos: 4550, y_pos: 240, size: 50, isFound: false}];
    
    collectablesDBEarth = [
        {DB_num:1, x_pos: -4000, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:2, x_pos: 1000, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:3, x_pos: -100, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:4, x_pos: 2000, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:5, x_pos: -1000, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:6, x_pos: -2000, y_pos: 250, size: 25, isFound: false}, 
        {DB_num:7, x_pos: 3000, y_pos: 250, size: 25, isFound: false}];
    
    collectableZeni = [//Dodoria
                       {x:2035, y:290, size:30, isFound:false},
                       {x:2185, y:240, size:30, isFound:false},
                       {x:2485, y:240, size:30, isFound:false},
                       {x:2635, y:290, size:30, isFound:false},
                       //Zarbon
                       {x:-1960, y:290, size:30, isFound:false},
                       {x:-2110, y:240, size:30, isFound:false},
                       {x:-2410, y:240, size:30, isFound:false},
                       {x:-2560, y:290, size:30, isFound:false},
                       //Frieza
                       {x:3835, y:290, size:30, isFound:false},
                       {x:4035, y:240, size:30, isFound:false},
                       {x:4435, y:240, size:30, isFound:false},
                       {x:4635, y:290, size:30, isFound:false},
                       //Extra Zeni
                       //Negative
                       {x:-100, y:400, size:30, isFound:false},
                       {x:-100, y:300, size:30, isFound:false},
                       {x:-100, y:350, size:30, isFound:false},
                       {x:-200, y:400, size:30, isFound:false},
                       {x:-200, y:300, size:30, isFound:false},
                       {x:-200, y:350, size:30, isFound:false},
                       {x:-300, y:400, size:30, isFound:false},
                       {x:-300, y:300, size:30, isFound:false},
                       {x:-300, y:350, size:30, isFound:false},
                       {x:-400, y:400, size:30, isFound:false},
                       {x:-400, y:300, size:30, isFound:false},
                       {x:-400, y:350, size:30, isFound:false},
                       {x:-1000, y:400, size:30, isFound:false},
                       {x:-1000, y:300, size:30, isFound:false},
                       {x:-1000, y:350, size:30, isFound:false},
                       {x:-1100, y:400, size:30, isFound:false},
                       {x:-1100, y:300, size:30, isFound:false},
                       {x:-1100, y:350, size:30, isFound:false},
                       {x:-1200, y:400, size:30, isFound:false},
                       {x:-1200, y:300, size:30, isFound:false},
                       {x:-1200, y:350, size:30, isFound:false},
                       {x:-1300, y:400, size:30, isFound:false},
                       {x:-1300, y:300, size:30, isFound:false},
                       {x:-1300, y:350, size:30, isFound:false},
                       {x:-1500, y:400, size:30, isFound:false},
                       {x:-1500, y:300, size:30, isFound:false},
                       {x:-1500, y:350, size:30, isFound:false},
                       {x:-1600, y:400, size:30, isFound:false},
                       {x:-1600, y:300, size:30, isFound:false},
                       {x:-1600, y:350, size:30, isFound:false},
                       {x:-1700, y:400, size:30, isFound:false},
                       {x:-1700, y:300, size:30, isFound:false},
                       {x:-1700, y:350, size:30, isFound:false},
                       {x:-3100, y:400, size:30, isFound:false},
                       {x:-3100, y:300, size:30, isFound:false},
                       {x:-3100, y:350, size:30, isFound:false},
                       {x:-3200, y:400, size:30, isFound:false},
                       {x:-3200, y:300, size:30, isFound:false},
                       {x:-3200, y:350, size:30, isFound:false},
                       {x:-3300, y:400, size:30, isFound:false},
                       {x:-3300, y:300, size:30, isFound:false},
                       {x:-3300, y:350, size:30, isFound:false},
                       {x:-3400, y:400, size:30, isFound:false},
                       {x:-3400, y:300, size:30, isFound:false},
                       {x:-3400, y:350, size:30, isFound:false},
                       {x:-3500, y:400, size:30, isFound:false},
                       {x:-3500, y:300, size:30, isFound:false},
                       {x:-3500, y:350, size:30, isFound:false},
                       {x:-4100, y:400, size:30, isFound:false},
                       {x:-4100, y:300, size:30, isFound:false},
                       {x:-4100, y:350, size:30, isFound:false},
                       {x:-4200, y:400, size:30, isFound:false},
                       {x:-4200, y:300, size:30, isFound:false},
                       {x:-4200, y:350, size:30, isFound:false},
                       {x:-4300, y:400, size:30, isFound:false},
                       {x:-4300, y:300, size:30, isFound:false},
                       {x:-4300, y:350, size:30, isFound:false},
                       {x:-4400, y:400, size:30, isFound:false},
                       {x:-4400, y:300, size:30, isFound:false},
                       {x:-4400, y:350, size:30, isFound:false},
                       {x:-4500, y:400, size:30, isFound:false},
                       {x:-4500, y:300, size:30, isFound:false},
                       {x:-4500, y:350, size:30, isFound:false},
                       //Positive
                       {x:100, y:400, size:30, isFound:false},
                       {x:100, y:300, size:30, isFound:false},
                       {x:100, y:350, size:30, isFound:false},
                       {x:200, y:400, size:30, isFound:false},
                       {x:200, y:300, size:30, isFound:false},
                       {x:200, y:350, size:30, isFound:false},
                       {x:300, y:400, size:30, isFound:false},
                       {x:300, y:300, size:30, isFound:false},
                       {x:300, y:350, size:30, isFound:false},
                       {x:400, y:400, size:30, isFound:false},
                       {x:400, y:300, size:30, isFound:false},
                       {x:400, y:350, size:30, isFound:false},
                       {x:1000, y:400, size:30, isFound:false},
                       {x:1000, y:300, size:30, isFound:false},
                       {x:1000, y:350, size:30, isFound:false},
                       {x:1100, y:400, size:30, isFound:false},
                       {x:1100, y:300, size:30, isFound:false},
                       {x:1100, y:350, size:30, isFound:false},
                       {x:1200, y:400, size:30, isFound:false},
                       {x:1200, y:300, size:30, isFound:false},
                       {x:1200, y:350, size:30, isFound:false},
                       {x:1300, y:400, size:30, isFound:false},
                       {x:1300, y:300, size:30, isFound:false},
                       {x:1300, y:350, size:30, isFound:false},
                       {x:1500, y:400, size:30, isFound:false},
                       {x:1500, y:300, size:30, isFound:false},
                       {x:1500, y:350, size:30, isFound:false},
                       {x:1600, y:400, size:30, isFound:false},
                       {x:1600, y:300, size:30, isFound:false},
                       {x:1600, y:350, size:30, isFound:false},
                       {x:1700, y:400, size:30, isFound:false},
                       {x:1700, y:300, size:30, isFound:false},
                       {x:1700, y:350, size:30, isFound:false},
                       {x:3100, y:400, size:30, isFound:false},
                       {x:3100, y:300, size:30, isFound:false},
                       {x:3100, y:350, size:30, isFound:false},
                       {x:3200, y:400, size:30, isFound:false},
                       {x:3200, y:300, size:30, isFound:false},
                       {x:3200, y:350, size:30, isFound:false},
                       {x:3300, y:400, size:30, isFound:false},
                       {x:3300, y:300, size:30, isFound:false},
                       {x:3300, y:350, size:30, isFound:false},
                       {x:3400, y:400, size:30, isFound:false},
                       {x:3400, y:300, size:30, isFound:false},
                       {x:3400, y:350, size:30, isFound:false},
                       {x:3500, y:400, size:30, isFound:false},
                       {x:3500, y:300, size:30, isFound:false},
                       {x:3500, y:350, size:30, isFound:false},
                       {x:4100, y:400, size:30, isFound:false},
                       {x:4100, y:300, size:30, isFound:false},
                       {x:4100, y:350, size:30, isFound:false},
                       {x:4200, y:400, size:30, isFound:false},
                       {x:4200, y:300, size:30, isFound:false},
                       {x:4200, y:350, size:30, isFound:false},
                       {x:4300, y:400, size:30, isFound:false},
                       {x:4300, y:300, size:30, isFound:false},
                       {x:4300, y:350, size:30, isFound:false},
                       {x:4400, y:400, size:30, isFound:false},
                       {x:4400, y:300, size:30, isFound:false},
                       {x:4400, y:350, size:30, isFound:false},
                       {x:4500, y:400, size:30, isFound:false},
                       {x:4500, y:300, size:30, isFound:false},
                       {x:4500, y:350, size:30, isFound:false},];
    
    collectableGem = [//Dodoria
                      {x:2345, y:200, size:30, isFound:false},
                      //Zarbon
                      {x:-2250, y:200, size:30, isFound:false},
                      //Frieza
                      {x:3840, y:160, size:30, isFound:false},
                      {x:4640, y:160, size:30, isFound:false},
                      //Other planet gems
                      //Positive
                      {x:1555, y:265, size:40, isFound:false},
                      {x:2555, y:265, size:40, isFound:false},
                      //Negative
                      {x:-1545, y:265, size:40, isFound:false},
                      {x:-2545, y:265, size:40, isFound:false}];
    
    collectableHearts = [//Positive
                        {x:900, y:330, size:40, isFound:false},
                        {x:2500, y:320, size:40, isFound:false},
                        {x:4000, y:330, size:40, isFound:false},
                        //Negative
                        {x:-900, y:330, size:40, isFound:false},
                        {x:-3500, y:320, size:40, isFound:false},
                        {x:-4000, y:330, size:40, isFound:false}];
    
    collectableCandy = [//Buus Candy
                       //Negative
                       {x:-100, y:290, size:5, isFound:false},
                       {x:-100, y:210, size:5, isFound:false},
                       {x:-100, y:250, size:5, isFound:false},
                       {x:-200, y:290, size:5, isFound:false},
                       {x:-200, y:210, size:5, isFound:false},
                       {x:-200, y:250, size:5, isFound:false},
                       {x:-300, y:290, size:5, isFound:false},
                       {x:-300, y:210, size:5, isFound:false},
                       {x:-300, y:250, size:5, isFound:false},
                       {x:-400, y:290, size:5, isFound:false},
                       {x:-400, y:210, size:5, isFound:false},
                       {x:-400, y:250, size:5, isFound:false},
                       {x:-1000, y:290, size:5, isFound:false},
                       {x:-1000, y:210, size:5, isFound:false},
                       {x:-1000, y:250, size:5, isFound:false},
                       {x:-1100, y:290, size:5, isFound:false},
                       {x:-1100, y:210, size:5, isFound:false},
                       {x:-1100, y:250, size:5, isFound:false},
                       {x:-1200, y:290, size:5, isFound:false},
                       {x:-1200, y:210, size:5, isFound:false},
                       {x:-1200, y:250, size:5, isFound:false},
                       {x:-1300, y:290, size:5, isFound:false},
                       {x:-1300, y:210, size:5, isFound:false},
                       {x:-1300, y:250, size:5, isFound:false},
                       {x:-1500, y:290, size:5, isFound:false},
                       {x:-1500, y:210, size:5, isFound:false},
                       {x:-1500, y:250, size:5, isFound:false},
                       {x:-1600, y:290, size:5, isFound:false},
                       {x:-1600, y:210, size:5, isFound:false},
                       {x:-1600, y:250, size:5, isFound:false},
                       {x:-1700, y:290, size:5, isFound:false},
                       {x:-1700, y:210, size:5, isFound:false},
                       {x:-1700, y:250, size:5, isFound:false},
                       {x:-3100, y:290, size:5, isFound:false},
                       {x:-3100, y:210, size:5, isFound:false},
                       {x:-3100, y:250, size:5, isFound:false},
                       {x:-3200, y:290, size:5, isFound:false},
                       {x:-3200, y:210, size:5, isFound:false},
                       {x:-3200, y:250, size:5, isFound:false},
                       {x:-3300, y:290, size:5, isFound:false},
                       {x:-3300, y:210, size:5, isFound:false},
                       {x:-3300, y:250, size:5, isFound:false},
                       {x:-3400, y:290, size:5, isFound:false},
                       {x:-3400, y:210, size:5, isFound:false},
                       {x:-3400, y:250, size:5, isFound:false},
                       {x:-3500, y:290, size:5, isFound:false},
                       {x:-3500, y:210, size:5, isFound:false},
                       {x:-3500, y:250, size:5, isFound:false},
                       //Positive
                       {x:100, y:290, size:5, isFound:false},
                       {x:100, y:210, size:5, isFound:false},
                       {x:100, y:250, size:5, isFound:false},
                       {x:200, y:290, size:5, isFound:false},
                       {x:200, y:210, size:5, isFound:false},
                       {x:200, y:250, size:5, isFound:false},
                       {x:300, y:290, size:5, isFound:false},
                       {x:300, y:210, size:5, isFound:false},
                       {x:300, y:250, size:5, isFound:false},
                       {x:400, y:290, size:5, isFound:false},
                       {x:400, y:210, size:5, isFound:false},
                       {x:400, y:250, size:5, isFound:false},
                       {x:1000, y:290, size:5, isFound:false},
                       {x:1000, y:210, size:5, isFound:false},
                       {x:1000, y:250, size:5, isFound:false},
                       {x:1100, y:290, size:5, isFound:false},
                       {x:1100, y:210, size:5, isFound:false},
                       {x:1100, y:250, size:5, isFound:false},
                       {x:1200, y:290, size:5, isFound:false},
                       {x:1200, y:210, size:5, isFound:false},
                       {x:1200, y:250, size:5, isFound:false},
                       {x:1300, y:290, size:5, isFound:false},
                       {x:1300, y:210, size:5, isFound:false},
                       {x:1300, y:250, size:5, isFound:false},
                       {x:1500, y:290, size:5, isFound:false},
                       {x:1500, y:210, size:5, isFound:false},
                       {x:1500, y:250, size:5, isFound:false},
                       {x:1600, y:290, size:5, isFound:false},
                       {x:1600, y:210, size:5, isFound:false},
                       {x:1600, y:250, size:5, isFound:false},
                       {x:1700, y:290, size:5, isFound:false},
                       {x:1700, y:210, size:5, isFound:false},
                       {x:1700, y:250, size:5, isFound:false},
                       {x:3100, y:290, size:5, isFound:false},
                       {x:3100, y:210, size:5, isFound:false},
                       {x:3100, y:250, size:5, isFound:false},
                       {x:3200, y:290, size:5, isFound:false},
                       {x:3200, y:210, size:5, isFound:false},
                       {x:3200, y:250, size:5, isFound:false},
                       {x:3300, y:290, size:5, isFound:false},
                       {x:3300, y:210, size:5, isFound:false},
                       {x:3300, y:250, size:5, isFound:false},
                       {x:3400, y:290, size:5, isFound:false},
                       {x:3400, y:210, size:5, isFound:false},
                       {x:3400, y:250, size:5, isFound:false},
                       {x:3500, y:290, size:5, isFound:false},
                       {x:3500, y:210, size:5, isFound:false},
                       {x:3500, y:250, size:5, isFound:false}];
    
    collectableBeerus = [
                       {x:random(-4000,4000), y:floorPos_y-200, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-200, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-200, size:50, isFound:false}];
    
    collectableMasterRoshi = [
                       {x:random(-4000,4000), y:floorPos_y-150, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-150, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-150, size:50, isFound:false}];
    
    collectableHercule = [
                       {x:random(-4000,4000), y:floorPos_y-100, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-100, size:50, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-100, size:50, isFound:false}];
    
    collectableChestRed = [
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false}];
    
    collectableChestBlue = [
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false}];
    
    collectableChestYellow = [
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false},
                       {x:random(-4000,4000), y:floorPos_y-10, size:40, isFound:false}];
    
    

    //Flagepole, mine represents a Rocket Ship
    flagpole = {x_pos:500, y_pos:0, isReached: false}; //can be placed anywhere   
    
    game_characters = [{Goku: false, Unlocked: false}, 
                       {Krillin: false, Unlocked: false}, 
                       {Majin_Buu: false, Unlocked: false},
                       {Vegeta: false, Unlocked: false},
                       {Android_18: false, Unlocked: false},
                       {Piccolo: false, Unlocked: false},
                       {Gohan: false, Unlocked: false},
                       {Gotenks: false, Unlocked: false},
                       {Beerus: false, Unlocked: false},
                       {Master_Roshi: false, Unlocked: false},
                       {Hercule: false, Unlocked: false}];
    
    Pause_Menu = false;
    charM = false;
    lootM = false;
    controlsM = false;
    extrasM = false;
    exitM = false;
    
    GameStart = false;
    
    play_Button = false;
    difficulty_Button = false;
    planet_Button = false;
    credit_Button = false;
    
    Planets = [{Namek: false},
               {Earth: false},
               {King_Kai_World: false},
               {Default: true}];
    
    Difficulty = [{Dif_easy:false}, 
                  {Dif_medium:true}, 
                  {Dif_hard:false}];
    
    Candy_rush = false;
    Time_score = 1000;
    Gregory_char = true;
    Beerus_Tokens = 0;
    Master_Roshi_Tokens = 0;
    Hercule_Tokens = 0;
    isDead = false;
    
    Shenron_sum = 0;
    Shenron = false;
    Wishes = false;
    
    jump_Wish = false;
    lives_Wish = false;
    money_Wish = false;
    
    LC = false;
    GO = false;

    // Music Switching Code * note .play doesnt work with long music files but .loop does
    //Music switches with every menu sequence
    
    DBZ_game_Menu_song.stop();
    DBZ_game_Kai_song.stop();
    DBZ_game_Earth_song.stop();
    DBZ_game_Namek_song.stop();
    DBZ_game_Extra_song.stop();
    Level_Complete_song.stop();
    Game_Over_song.stop();
    
    r1 = round(random(1,5));
    r2 = round(random(1,5));
    r3 = 0;
    
    if (r1 == 1)
    {
        DBZ_game_Menu_song.stop();
        DBZ_game_Menu_song.loop(); 
    }
    
    else if (r1 == 2)
    {
        DBZ_game_Kai_song.stop();
        DBZ_game_Kai_song.loop(); 
    }
    
    else if (r1 == 3)
    {
        DBZ_game_Earth_song.stop();
        DBZ_game_Earth_song.loop(); 

    }
    
    else if (r1 == 4)
    {
        DBZ_game_Namek_song.stop();
        DBZ_game_Namek_song.loop(); 
    }
    
    else if (r1 == 5)
    {
        DBZ_game_Extra_song.stop();
        DBZ_game_Extra_song.loop(); 
    }
}